angular.module("PerformanceDashboard")
	.constant("Constants", {

	    /*Server URLs */
		"API_URL": "http://localhost",
	   // "API_URL": "http://DIN80003720",
	    "USERID": "satheesh.kumar@hp.com",
	    "AUTHID": "",
	    "POST_VALIDATE_USER": "/PDAPI/api/UserDetails/ValidateAppUser",
        /* dashboard*/
	    "POST_SELECT_FILE": "/PDAPI/api/UserDetails/UserFileDetail",
	    "POST_WIPE_ALL_INFORMATION": "/PDAPI/api/Usage/PostWipeAllInformation",
	    /* invoice urls*/
	    "POST_AVAILABLE_DATA": "/PDAPI/api/Invoice/GetAvailableDataRange",
	    "POST_CURRENCY_DATA": "/PDAPI/api/Invoice/GetCurrencyData",
	    "POST_UPDATE_CURRENCY_CONVERSION": "/PDAPI/api/Invoice/PostUpdateCurrencyConversionTable",
	    "POST_UPLOAD_EXCEL": "/PDAPI/api/Invoice/PostUploadExcel",
	    "POST_UPLOAD_MULTIPLE_EXCEL": "/PDAPI/api/Invoice/PostUploadMultipleExcel",
	    "POST_DATA_ROW_SELECT": "/PDAPI/api/Invoice/PostDataRowSelect",
	    "POST_PAIRED_COLUMN": "/PDAPI/api/Invoice/GetPairedColumns",
	    "POST_PROCESS_INVOICE": "/PDAPI/api/Invoice/PostProcessInvoice",
	    "POST_UPDATE_DEVICE": "/PDAPI/api/Invoice/PostUpdateDeviceProcessInvoice",
	    "POST_SKIP_ALL_DEVICE": "/PDAPI/api/Invoice/PostSkipAllDeviceProcessInvoice",
	    "POST_ABORT_INVOICE_PROCESS": "/PDAPI/api/Invoice/PostAbortInvoiceProcess",
	    "POST_CURRENCY_CONVERSATION_VIEW": "/PDAPI/api/Invoice/GetCurrencyConversionTableData",
	    "POST_CURRENCY_CONVERSATION_UPDATE": "/PDAPI/api/Invoice/PostUpdateCurrencyConversionTable",
	    "POST_INVOICE_USAGE_FLAG_UPDATE": "/PDAPI/api/Usage/PostInvoiceUsageFlagUpdate",
	    /* usage urls*/
	    "POST_UPLOAD_EXCEL_USAGE": "/PDAPI/api/Usage/PostUploadExcel",
	    "POST_PROCESS_USAGE": "/PDAPI/api/Usage/PostProcessUsage",
	    "POST_SAVE_USAGE": "/PDAPI/api/Usage/PostUpdateDeviceProcessUsage",
	    "POST_SKIP_ALL_DEVICE_USAGE": "/PDAPI/api/Usage/PostSkipAllDeviceProcessUsage",
	    "GET_ABORT_INVOICE_PROCESS": "/PDAPI/api/Invoice/PostAbortInvoiceProcess",
	    "POST_PROCESS_USAGE_NOT_RECOMMENDED": "/PDAPI/api/Usage/PostProcessUsageNotRecommended",

	    /* SOW Information*/
	    "POST_SOW_INFORMATION": "/PDAPI/api/SowInformation/GetSowInformation",
	    "POST_CALCULATE_SOW_VOLUME": "/PDAPI/api/SowInformation/PostCalculateSowVolume",
	    "POST_CALCULATE_SOW_ALL_VOLUME": "/PDAPI/api/SowInformation/PostCalculateSowAllVolume",
	    "POST_GET_MONTH_SOW_DATA": "/PDAPI/api/SowInformation/GetUsageMonthData",
	    //"POST_GOTO_DATA_DESIGN_SOW": "/PDAPI/api/SowInformation/PostGenerateSBRReport",
	    "POST_GENERATE_SBR_SOW_DATA": "/PDAPI/api/SowInformation/PostCreateSBRReport",
	    "POST_SOW_COMPANYINFO": "/PDAPI/api/SowInformation/PostSowCompanyInfo",

	    /*process invoice table*/
	    "DELETE_LAST_MONTH_DATA": "/PDAPI/api/Usage/DeleteLastMonthData",
	    "POST_ADD_GROUP": "/PDAPI/api/Invoice/PostAddGroup",
	    "POST_CLEAR_GROUP": "/PDAPI/api/Invoice/PostClearGroup",
	    "POST_CLEAR_GROUP_ROW": "/PDAPI/api/Invoice/PostClearGroupByRow",
	    "POST_UPDATE_DEVICE_STATUS": "/PDAPI/api/Invoice/PostUpdateDeviceStatus",
	    "POST_DELETE_ONE_MONTH_DATA": "/PDAPI/api/Usage/PostWipeAllInformation",
	    "POST_NRD_STATUS_UPDATE": "/PDAPI/api/Usage/PostDeviceGroupStatus",
	    /* scrubb information*/
	    "GET_SCRUB_REPORT": "/PDAPI/api/ServiceScrubber/GetScrubberReportPPUData",
	    "POST_PPU_SHARE": "/PDAPI/api/ServiceScrubber/PostProcessPPUFileFromShare",
	    "POST_PPU_COMPUTER": "/PDAPI/api/ServiceScrubber/PostProcessPPUFileFromComputer",
	    "POST_PPU_FILE": "/PDAPI/api/ServiceScrubber/PostProcessPPUFile",
	    "GET_SCRUBB_DATA": "/PDAPI/api/ServiceScrubber/GetServiceReportScrubberData",
	    "POST_SLA_CHANGE": "/PDAPI/api/ServiceScrubber/PostOnlyOnsiteSLAs",
	    "POST_SERVICE_FLAG_CHANGE": "/PDAPI/api/ServiceScrubber/PostUpdateServiceFlag",
	    "POST_SLA_DATA": "/PDAPI/api/ScrubberSettings/GetServiceLevelAgreementData",
	    "POST_CC_DATA": "/PDAPI/api/ScrubberSettings/GetContractCoverageData",
	    "POST_SA_DATA": "/PDAPI/api/ScrubberSettings/GetServiceAnalysisData",
	    "POST_SA_UPDATE_DATA": "/PDAPI/api/ScrubberSettings/PostUpdateServiceAnlysisData",
	    "POST_UPDATE_SLA_DATA": "/PDAPI/api/ScrubberSettings/PostUpdateServiceLevelAgreement",
	    "POST_UPDATE_CC_DATA": "/PDAPI/api/ScrubberSettings/PostUpdateContractCoverageData",
	    "POST_SYMPTOMCODE_CHANGE": "/PDAPI/api/ServiceScrubber/PostSymptomCodeChange",
	    "POST_COMPONENTCODE_CHANGE": "/PDAPI/api/ServiceScrubber/PostComponentCodeChange",
	    "POST_FILTER_CASE": "/PDAPI/api/ServiceScrubber/PostScrubberFilterData",
	    "POST_CLEAR_ALL_DATA": "/PDAPI/api/ServiceScrubber/PostServiceReportScrubberClearData",
	    //"GET_OPEN_URL": "/PDAPI/api/ServiceScrubber/GetgotoLocation"

	    /*Data Design */
	    "POST_GOTO_DATA_DESIGN_SOW": "/PDAPI/api/DataDesign/PostGetDataDesign",
	    "POST_GET_GRAPH_DATA": "/PDAPI/api/DataDesign/PostGetGraphData",
	    "POST_SUGGESTED_DEVICE_DATA": "/PDAPI/api/DataDesign/PostGetSuggestedDevice",

	    /*optimization summary*/
	    "POST_OPTIMIZ_DATA": "/PDAPI/api/OptimizationSummary/GetOptimizationSummaryData",
	    "POST_POWER_CONSUMPTION_SETTINGS_DATA": "/PDAPI/api/OptimizationSummary/PostPowerConsumptionSettings",
	    "POST_GET_DEFAULT_SETTINGS": "/PDAPI/api/OptimizationSummary/GetDefaultPowerConsumptionSettings",
        
	    /* Performance Dashboard */
	    "POST_PD_INFO_DATA": "/PDAPI/api/PerformanceDashboard/GetPerformanceDashboardData",
	    "POST_PD_DATA_SAVE": "/PDAPI/api/PerformanceDashboard/PostPerformanceDashboardDataSave",
	    "POST_PD_UPDATE_VIEW": "/PDAPI/api/PerformanceDashboard/PerformanceDashboardUpdatePDView",
	    "POST_PD_SERVICE_SCRUBBER": "/PDAPI/api/PerformanceDashboard/PerformanceDashboardUpdateServiceScrubber",
	    "POST_PD_DELETE_SERVICE_DATA": "/PDAPI/api/PerformanceDashboard/PerformanceDashboardDeleteServiceData",
	    "POST_PD_SELECT_RANGE_DATA": "/PDAPI/api/PerformanceDashboard/PerformanceDashboardSelectRange",
	    "POST_PD_RESET_RANGE_DATA": "/PDAPI/api/PerformanceDashboard/PerformanceDashboardResetRange",
        //Market Vertical data export 
	    "POST_GET_MARKET_VERTICAL_DATA": "/PDAPI/api/PerformanceDashboard/GetMarketVerticalData",
	    "POST_EXPORT_MARKET_VERTICAL_DATA": "/PDAPI/api/PerformanceDashboard/PostExportMarketVericalData",
	    "POST_GET_MARKET_VERTICAL_CATEGORY_DATA": "/PDAPI/api/PerformanceDashboard/GetMarketVerticalCategoryData",
	    "POST_MARKET_VERTICAL_IMPORT_DATA": "/PDAPI/api/PerformanceDashboard/PostImportMarketVerticalData",
	    "POST_UPDATE_EXPORT_MV_DATA": "/PDAPI/api/PerformanceDashboard/PostUpdateExportMarketVericalData",
	    //SBR
	    "POST_CREATE_SBR_REPORT": "/PDAPI/api/PerformanceDashboard/PostCreateSBRReport",
	    /* Visual Dashboard */
	    "POST_GET_ALL_GRAPH_DATA": "/PDAPI/api/VisualDashBoard/GetVisualDashboardData",
	    /* Admin Access */
	    "GET_UNKNOWN_DEVICE_DATA": "/PDAPI/api/Usage/GetUnApprovedDeviceData",
	    "POST_UNKNOWN_DEVICES_UPDATE": "/PDAPI/api/Usage/PostApproveManuallyEnteredDevice" 
	})