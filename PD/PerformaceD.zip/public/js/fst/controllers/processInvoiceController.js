﻿'use strict'
angular.module('PerformanceDashboard')
    .filter('customfilter', function ($filter)
    {
        return function (input, searchFilter,displayProp)
        {
            var temparray = [];
            if (searchFilter !== undefined && searchFilter !== '') {
                for (var i = 0; i < input.length; i++) {
                    if (input[i][displayProp] !== '' && input[i][displayProp] !== null && input[i][displayProp].toLowerCase().indexOf(searchFilter.toLowerCase()) !==-1)
                        temparray.push(input[i]);
                }
                return temparray;
            } else {
                return input;
            }
        };
    })
    .controller('statusChangeController', ['$scope', '$state', '$uibModalInstance', 'shareUser', 'processInvoiceServices', 'dataService', function ($scope, $state, $uibModalInstance, shareUser, processInvoiceServices, dataService) {
        var self = this;
        self.ModelDescription = $scope.$parent.ModelDescription;
        self.DeviceStatusColumn = $scope.$parent.DeviceStatusColumn
        self.NRDStatus = 'Local';
        self.updateRow = 'device_group';
        self.includeSeries = false;
        self.saveData = function () {
            var param = {};
            param.ModelDescription = self.ModelDescription;
            param.NRDStatus = self.NRDStatus;
            param.updateRowSelected = self.updateRow;
            param.includeEntireSeries = self.includeSeries;
            param.Usg_DeviceStatusColumn = self.DeviceStatusColumn;
            param.PDUsers = shareUser.get();
            processInvoiceServices.postUpdateNRDStatusData(param).then(function (response) {
                //$state.go("main.ProcessInvoiceTable", {}, { reload: true })
                console.log(response.data);
                dataService.setMyData(response.data);
                $scope.loadDataInvoice(true);
                $uibModalInstance.dismiss('cancel');
            });
        }
        self.closePopup = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }])
    .controller('processInvoiceTableController', ['$scope', '$rootScope', 'filterFilter', '$http', '$filter','$uibModal', 'dataService', 'Constants', '$timeout', 'processInvoiceServices', '$window',
    function ($scope, $rootScope, filterFilter, $http, $filter, $modal, dataService, Constants, $timeout, processInvoiceServices, $window) {
        $scope.deletedkey = [];
        $scope.addgroupSelectedValue = [];
        $scope.monthArr = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        $scope.individualRowData = true;
        $scope.modified = false;
        $scope.status = 'OFF';
        $scope.filtermodel = {
            Loc_Area: [],
            Loc_Site: [],
            Loc_Building: [],
            Loc_Level: [],
            Loc_Grid: [],
            Loc_Business_Unit: [],
            Loc_Report_Groups:[],
            Device_ModelDescription: [],
            Device_ProductCode: [],
            Device_SerialNumber: [],
            Device_LeaseRenewalStratDate :[]
        };
        $scope.extraSettings = {
            scrollableHeight: '200px',
            scrollable: true,
            enableSearch: true
        };
        //Set the table height
        $scope.setTableHeight = $window.innerHeight / 100 * 65;
        
        $scope.switchTableView = function () {
            $scope.individualRowData = $scope.individualRowData === false ? true : false;
            calculateCountFilter();
            $scope.status = 'OFF';
            $scope.filterStatus($scope.status);
        };
        var filterStaususage = function (usgItem) {
            if ($scope.status === 'ARD') {
                if (usgItem.Usg_TotalPages !== null && usgItem.Usg_TotalPages > 0) {
                    return true;
                }
            } else if ($scope.status === 'IRD') {
                if ((usgItem.Usg_TotalPages !== null && usgItem.Usg_TotalPages > 0) && usgItem.Usg_Device_Status === "") {
                    return true;
                }
            } else if($scope.status === 'NRD'){
                if (usgItem.Usg_Device_Status.toLowerCase() === 'storage' ||
                        usgItem.Usg_Device_Status.toLowerCase() === 'local' ||
                        usgItem.Usg_Device_Status.toLowerCase() === 'other' ||
                        usgItem.Usg_Device_Status.includes("NRD")) {
                    return true;
                }
            } else if ($scope.status === 'NID') {
                if (usgItem.Usg_Device_Status.toLowerCase() === 'new' ||
                    usgItem.Usg_Device_Status.toLowerCase() === 'ignore' ||
                    usgItem.Usg_Device_Status.includes("NID")) {
                    return true;
                }            
            }
            return false;
        }
        /* Reset OFF filter*/
        $scope.resetFilter = function () {
            $scope.filterList = {};
            $scope.items = filter($scope.allItems, $scope.filterList);
            $scope.loadData();
            $scope.status = 'OFF';
        }
        var filterCalculation = function (usgItem) {            
            var usgDeviceStatus = usgItem.Usg_Device_Status;
            if (usgDeviceStatus.includes("NRD"))
                $scope.NRDCount++;
            else if (usgDeviceStatus.includes("Storage")) {
                $scope.storageCount++;
                $scope.NRDCount++;
            }else if (usgDeviceStatus.includes("Local")) {
                $scope.localCount++;
                $scope.NRDCount++;
            }else if (usgDeviceStatus.includes("Other")) {
                $scope.NRDCount++;
                $scope.otherCount++;
            }else if (usgDeviceStatus.includes("NID"))
                $scope.NIDCount++;
            else if (usgDeviceStatus.includes("Ignore")) {
                $scope.ignoreCount++;
                $scope.NIDCount++;
            }else if (usgDeviceStatus.includes("NEW")) {
                $scope.NIDCount++;
                $scope.newCount++;
            }if (usgItem.Usg_TotalPages !== null && usgItem.Usg_TotalPages > 0) {
                $scope.ARDCount++;
            } if ((usgItem.Usg_TotalPages !== null && usgItem.Usg_TotalPages > 0) && usgDeviceStatus === "") {
                $scope.IRDCount++;
            }
        }
        var calculateCountFilter = function () {
            $scope.NRDCount = 0;
            $scope.storageCount = 0;
            $scope.localCount = 0;
            $scope.otherCount = 0;
            $scope.NIDCount = 0;
            $scope.ignoreCount = 0;
            $scope.newCount = 0;
            $scope.offCount = 0;
            $scope.ARDCount = 0;
            $scope.IRDCount = 0;
           // var itemsdata = angular.copy($scope.allItems);
            angular.forEach($scope.allItems, function (item) {
                angular.forEach(item.Usg_Model, function (usgItem) {
                    if (usgItem.Usg_Device_Status.toLowerCase() === 'storage' ||
                       usgItem.Usg_Device_Status.toLowerCase() === 'local' ||
                       usgItem.Usg_Device_Status.toLowerCase() === 'other' ||
                       usgItem.Usg_Device_Status.includes("NRD")) {
                        usgItem.backup_device_Status = "NRD";
                    }
                    else if (usgItem.Usg_Device_Status.toLowerCase() === 'new' ||
                        usgItem.Usg_Device_Status.toLowerCase() === 'ignore' ||
                        usgItem.Usg_Device_Status.includes("NID")) {
                        usgItem.backup_device_Status = "NID";
                    } else {
                        usgItem.backup_device_Status = "";
                    }
                    if (!$scope.individualRowData) {
                        filterCalculation(usgItem);
                    } else {
                        if (usgItem.Month === $scope.firstMonthUsage && usgItem.Year == $scope.firstYearUsage) {
                            filterCalculation(usgItem);
                        }
                    }
                });
            });
        }
        /*Filter for device Status start*/
        $scope.filterStatus = function (status, count) {
            $scope.status = status;
            $scope.btnsResult = false;
            if (count === undefined) {
                switch (status) {
                    case 'ARD':
                        count = $scope.ARDCount;
                        break;
                    case 'IRD':
                        count = $scope.IRDCount;
                        break;
                    case 'NID':
                        count = $scope.NIDCount;
                        break;
                    case 'NRD':
                        count = $scope.NRDCount;
                        break;
                }
                if (count === 0)
                    $scope.status = "OFF";
            }
            if (count > 0) {
                if (status !== undefined && status !== null && status !== "OFF") {
                    $scope.items = [];
                    var itemsdata = angular.copy($scope.allItems);
                    angular.forEach(itemsdata, function (item) {
                        var Usg_Model = [];
                        angular.forEach(item.Usg_Model, function (usgItem) {
                            if (!$scope.individualRowData) {
                                if(filterStaususage(usgItem)){
                                    Usg_Model.push(usgItem);
                                }
                            } else {
                                if (usgItem.Month === $scope.firstMonthUsage && usgItem.Year == $scope.firstYearUsage) {
                                    if (filterStaususage(usgItem)) {
                                        Usg_Model.push(usgItem);
                                    }
                                }
                            }
                        });
                        if (Usg_Model.length > 0) {
                            item.Usg_Model = Usg_Model;
                            $scope.items.push(item);
                        }
                    });
                    $scope.loadData();
                } else {
                    $scope.resetFilter();
                }
            } else {
                if ($scope.status === "OFF") {
                    $scope.resetFilter();
                } else {
                    $scope.btnStatus = status;
                    $scope.btnsResult = true;
                    $timeout(function () {
                        $scope.btnsResult = false;
                    }, 3000);
                }
            }
        }
        /*Filter for device Status end*/
        $scope.loadDataInvoice = function (flag,deleteFlag) {
            $scope.invoiceFlag = false;
            if (dataService.myData.length && deleteFlag) {
                processInvoiceServices.postAvailableData().then(function (response) {
                    $scope.invoiceAvailableData = JSON.parse('{' + (response.data) + '}');
                    $scope.invoiceFlag = true;
                    if ($scope.invoiceAvailableData.IsUploadedUsage === 'True') {
                        $rootScope.disableSOW = false;
                        $rootScope.disableScrubber = false;
                    }
                    $scope.disableLeftArrow($scope.nowDateInv);
                    $scope.disableRightArrow($scope.nowDateInv);
                });
            }else if (dataService.myData.length && flag) {
                $scope.invoiceAvailableData = $rootScope.invoiceUsageNavData;
                $scope.invoiceFlag = true;
                if ($scope.invoiceAvailableData.IsUploadedUsage === 'True') {
                    $rootScope.disableSOW = false;
                    $rootScope.disableScrubber = false;
                }
                $scope.disableLeftArrow($scope.nowDateInv);
                $scope.disableRightArrow($scope.nowDateInv);
            }
            $scope.allItems = dataService.myData;
            $scope.itemsDate = angular.copy($scope.allItems);
            $scope.items = [];
            $scope.items = angular.copy($scope.allItems);
            $scope.monthwise();
            calculateCountFilter();
        }

        $scope.getDateFormat = function (timestamp) {
            if (timestamp !== '')
                return new Date(timestamp);
            return '';
        }      

        $scope.loadData = function () {
            $scope.usage = [];
            $scope.invoice = [];
            $scope.wipeUsgModel = [];
            $scope.wipeInvModel = [];
            $scope.firstMonthUsage = $scope.monthArr[$scope.nowDateUsage.getMonth()];
            $scope.firstYearUsage = $scope.nowDateUsage.getFullYear();
            $scope.firstMonthInv = $scope.monthArr[$scope.nowDateInv.getMonth()];
            $scope.firstYearInv = $scope.nowDateInv.getFullYear();
            if ($scope.items.length) {
                $scope.wipeUsgModel = $scope.items[0].Usg_Model;
                $scope.wipeInvModel = $scope.items[0].Inv_Model;
            }
            $scope.testArr = [];
            $scope.testArr = $scope.items;
            $scope.backupItems = angular.copy($scope.items);
            angular.forEach($scope.items, function (item) {
                angular.forEach(item.Usg_Model, function (usgItem) {
                    usgItem.device_Status = usgItem.Usg_Device_Status.split(" ")[0];
                    usgItem.Loc_DeviceID = item.Loc_DeviceID;
                    usgItem.Device_ModelDescription = item.Device_ModelDescription
                    if (usgItem.Month === $scope.firstMonthUsage && usgItem.Year == $scope.firstYearUsage)
                        $scope.usage.push(usgItem);
                });
                angular.forEach(item.Inv_Model, function (invItem) {
                    if (invItem.Month === $scope.firstMonthInv && invItem.Year == $scope.firstYearInv)
                        $scope.invoice.push(invItem);
                });
            })            
            
        }
        /* get month view data*/
        $scope.monthwise = function () {
            if ($scope.items.length) {
                var firstUsage = $scope.items[0].Usg_Model;
                var firstInv = $scope.items[0].Inv_Model;
                var firstMonthUsage = firstUsage[firstUsage.length-1].Month;
                var firstYearUsage = firstUsage[firstUsage.length - 1].Year;
                $scope.nowDateUsage = new Date(firstYearUsage, $scope.monthArr.indexOf(firstMonthUsage), 1);
                var firstMonthInv = firstInv[firstInv.length -1].Month;
                var firstYearInv = firstInv[firstInv.length - 1].Year;
                $scope.nowDateInv = new Date(firstYearInv, $scope.monthArr.indexOf(firstMonthInv), 1);
            }
            $scope.loadData();
        }
        
        var checkDate = function (check) {
            var fDate = "01/" + $scope.invoiceAvailableData.startMonth + "/" + $scope.invoiceAvailableData.startYear;
            var lDate = "30/" + $scope.invoiceAvailableData.endMonth + "/" + $scope.invoiceAvailableData.endYear;
            var cDate = new Date(check);
            fDate = Date.parse(fDate);
            lDate = Date.parse(lDate);
            cDate = Date.parse(cDate);
            if ((cDate <= lDate && cDate >= fDate)) {
                return true;
            }else{
                return false;
            }
        }
        /* prev month data*/
        $scope.prev = function () {
            $scope.items = angular.copy($scope.allItems);            
            var usgDate = angular.copy($scope.nowDateUsage);
            var invDate = angular.copy($scope.nowDateInv);
            if (checkDate(invDate.setMonth(invDate.getMonth() - 1, 1))) {
                $scope.nowDateUsage.setMonth($scope.nowDateUsage.getMonth() - 1, 1);
                $scope.nowDateInv.setMonth($scope.nowDateInv.getMonth() - 1, 1);
                $scope.loadData();
                $scope.disableLeftArrow($scope.nowDateInv);
                $scope.disableRightArrow($scope.nowDateInv);
            }
            calculateCountFilter();
            $scope.filterStatus($scope.status);
        }
        /* next month data*/
        $scope.next = function () {
            $scope.items = angular.copy($scope.allItems);
            var usgDate = angular.copy($scope.nowDateUsage);
            var invDate = angular.copy($scope.nowDateInv);
            if (checkDate(invDate.setMonth(invDate.getMonth() + 1, 1))) {
                $scope.nowDateUsage.setMonth($scope.nowDateUsage.getMonth() + 1, 1);
                $scope.nowDateInv.setMonth($scope.nowDateInv.getMonth() + 1, 1);
                $scope.loadData();
                $scope.disableRightArrow($scope.nowDateInv);
                $scope.disableLeftArrow($scope.nowDateInv);
            }
            calculateCountFilter();
            $scope.filterStatus($scope.status);
        }
        /*Disabling next and prev month buttons*/
        $scope.disableLeftArrow = function (date) {
            var check = angular.copy(date);
            var fDate = "01/" + $scope.invoiceAvailableData.startMonth + "/" + $scope.invoiceAvailableData.startYear;
            var cDate = new Date(check);
            fDate = Date.parse(fDate);
            cDate = Date.parse(cDate);
            if (fDate === cDate || fDate > cDate) {
                $scope.disableLeftBtn = true;
            } else {
                $scope.disableLeftBtn = false;
            }
        }
        $scope.disableRightArrow = function (date) {
            var check = angular.copy(date);
            var lDate = "01/" + $scope.invoiceAvailableData.endMonth + "/" + $scope.invoiceAvailableData.endYear;
            var cDate = new Date(check);
            lDate = Date.parse(lDate);
            cDate = Date.parse(cDate);
            if (lDate === cDate || lDate < cDate) {
                $scope.disableRightBtn = true;
            } else {
                $scope.disableRightBtn = false;
            }
        }
        
        /*Filter header row */
        $scope.filterInvoiceData = function () {
            var filteritems = angular.copy($scope.allItems); 
            var itemsTemp = [];
            if (filteritems.length > 0) {
                angular.forEach($scope.filtermodel, function (fltrValue, fltrKey) { //filters from header                    
                    if (fltrValue.length > 0) {
                        itemsTemp = [];
                        angular.forEach(filteritems, function (item) { // all row data
                            if (fltrValue.indexOf(item[fltrKey]) !== -1) {
                                itemsTemp.push(item);
                            } else if (fltrKey.toLowerCase() === 'device_leaserenewalstratdate') {
                                var newDate = $filter('date')(new Date(item[fltrKey]), "MM-dd-yyyy");
                                if (fltrValue.indexOf(newDate) !== -1) {
                                    itemsTemp.push(item);
                                }
                            }
                        });
                        console.log(itemsTemp);
                        filteritems = itemsTemp;
                    }
                });
                $scope.items = filteritems;
            }
            $scope.monthwise();
        }
        $scope.rowNumber = 0;
        $scope.selectRow = function (item, index) {
            $scope.rowNumber = index;
            $scope.wipeUsgModel = item.Usg_Model;
            $scope.wipeInvModel = item.Inv_Model;
        }
        $scope.selectedDeviceData = [];
        $scope.DeviceStatusChange = function (row) {
            var newStatus = row.device_Status;
            var oldStatus = row.Usg_Device_Status;
            $scope.modified = true;
            row.Usg_Device_Status = row.device_Status;

            if (newStatus.includes("Storage"))
                $scope.storageCount++;
            else if (newStatus.includes("Local"))
                $scope.localCount++;
            else if (newStatus.includes("Other"))
                $scope.otherCount++;
            else if (newStatus.includes("Ignore"))
                $scope.ignoreCount++;
            else if (newStatus.includes("NEW"))
                $scope.newCount++;

            if (oldStatus.includes("Storage"))
                $scope.storageCount--;
            else if (oldStatus.includes("Local"))
                $scope.localCount--;
            else if (oldStatus.includes("Other"))
                $scope.otherCount--;
            else if (oldStatus.includes("Ignore"))
                $scope.ignoreCount--;
            else if (oldStatus.includes("NEW"))
                $scope.newCount--;
        }
        /*save all changes start*/
        $scope.saveAllData = function () {
            $scope.modified = false;
            $scope.selectedDeviceData = [];
            angular.forEach($scope.items, function (item) {
                angular.forEach(item.Usg_Model, function (row) {
                    if (row.backup_device_Status !== row.device_Status) {
                        var rowData = {};
                        rowData.DeviceID = row.Usg_DeviceID;
                        rowData.DeviceStatusColumn = row.Usg_DeviceStatusColumn;
                        rowData.DeviceStatus = row.device_Status;
                        $scope.selectedDeviceData.push(rowData);
                    }
                })
            });
            var param = {
                "DeviceStatus": $scope.selectedDeviceData
            };
            processInvoiceServices.PostUpdateDeviceStatus(param).then(function (response) {
                $scope.invoiceResponse = response.data;
                dataService.setMyData($scope.invoiceResponse);

                $scope.filterList = {};
                $scope.loadDataInvoice(false);
                $scope.resetFilter();
            });
            /* call service once ready*/
        }
        /* save all changes end*/
       
        /*Process Invoice Table Add Group Starts*/
        $scope.addGroup = function () {
            $scope.groupList = [];
            $scope.groupNames = '';
            $scope.selectedProcessInvoiceRow = [];
            $scope.adjustedRowCounter = 0;
            $scope.errormes = false;
            $scope.items.forEach(function (item) {
                if (item.selected) {
                    if (item.Loc_Report_Groups === "") {
                        $scope.selectedProcessInvoiceRow.push(item);
                    } else {
                        $scope.adjustedRowCounter++;
                        if ($scope.adjustedRowCounter >= 1) {
                            $scope.errormes = true
                        }
                    }
                }
            })
        };

        $scope.saveAddGroup = function () {
            $scope.userInputvalueResult = $scope.grpName;
            $scope.selectedProcessInvoiceRowModal = [];
            $scope.groupList = [];
            angular.forEach($scope.selectedProcessInvoiceRow, function (row) {
                var rowData = {};
                if (row.selected) {
                    rowData.DeviceID = row.Loc_DeviceID;
                    rowData.GroupName = $scope.grpName;
                    $scope.selectedProcessInvoiceRowModal.push(rowData);
                }
            });
            angular.forEach($scope.allItems, function (rowDeselect) {
                rowDeselect.selected = false;
            });
            $scope.grpName = "";
            $scope.selectAll = false;
            $('#myModal').modal('hide');
            var addgroupUrl = Constants.API_URL + Constants.POST_ADD_GROUP;
            var param = {
                "PDFileName": $rootScope.fileused.UserAccFileName,
                "Groups": $scope.selectedProcessInvoiceRowModal
            };
            $http({
                method: 'POST',
                url: addgroupUrl,
                data: param,
                headers: {
                    "Content-Type": "application/json"
                }
            }).then(function successCallback(response) {
                $scope.invoiceResponse = response.data;
                dataService.setMyData($scope.invoiceResponse);
                $scope.filterList = {};

                $scope.loadDataInvoice(false);
                $scope.resetFilter();
                $('#myModal').modal('hide');
            },
            function errorCallback(response) {
                console.log("Add group error");
                $scope.resetFilter();
                $('#myModal').modal('hide');
            });
        };

        $scope.groupNameFilter = function () {
            $scope.groupList = [];
            if ($scope.groupNames !== undefined && $scope.groupNames !== null && $scope.groupNames !== "") {
                angular.forEach($scope.allItems, function (item) {
                    if (item.Loc_Report_Groups === $scope.groupNames) {
                        $scope.groupList.push(item);
                    }
                });
            }
        }

        /*Clear Selected Group Starts*/
        $scope.clearGroup = function () {
            var confirmClear = confirm("Are you sure, you want to clear this group?")
            if (confirmClear) {
                $('#myModal').modal('hide');
                var clearGroupData = {
                    "GroupName": $scope.groupNames
                };
                processInvoiceServices.cleargroup(clearGroupData).then(function (response) {
                    $scope.invoiceResponse = response.data;
                    dataService.setMyData($scope.invoiceResponse);

                    $scope.loadDataInvoice(false);
                    $scope.resetFilter();
                });
            }
        }
        $scope.deleteSelectedRow = function () {
            var confirmClear = confirm("Are you sure, you want to delete these row(s)?")
            if (confirmClear) {
                var deleteRowData = [];
                angular.forEach($scope.groupList, function (row) {
                    var rowData = {};
                    if (row.selected) {
                        rowData.DeviceID = row.Loc_DeviceID;
                        rowData.GroupName = $scope.groupNames;
                        deleteRowData.push(rowData);
                        row.selected = false;
                    }
                });
                $('#myModal').modal('hide');
                var param = {
                    "Groups": deleteRowData
                };
                processInvoiceServices.cleargroupRow(param).then(function (response) {
                    $scope.invoiceResponse = response.data;
                    dataService.setMyData($scope.invoiceResponse);

                    $scope.loadDataInvoice(false);
                    $scope.resetFilter();
                    $scope.groupNameFilter();
                    $('#myModal').modal('show');
                });
            }
        }
        //Select All 
        var filter = $filter('filter');
        $scope.selectAllFilteredItems = function () {
            var filteritems = $scope.items;
            var itemsTemp = [];
            if (filteritems.length > 0) {
                angular.forEach($scope.filterList, function (fltrValue, fltrKey) { //filters from header
                    itemsTemp = [];
                    angular.forEach(filteritems, function (item) { // all row data
                        if (item[fltrKey] === fltrValue || fltrValue === '') {
                            itemsTemp.push(item);
                        } else if (fltrKey === 'Device_LeaseRenewalStratDate') {
                            item[fltrKey] = $filter('date')(new Date(item[fltrKey]), "MM-dd-yyyy");
                            if (item[fltrKey].indexOf(fltrValue) > -1) {
                                itemsTemp.push(item);
                            }
                        }
                    });
                    filteritems = itemsTemp;
                });
            }
            if ($scope.selectAll) {
                angular.forEach(filteritems, function (item) {
                    item.selected = true;
                });
            }else {
                angular.forEach(filteritems, function (item) {
                    item.selected = false;
                });
            }
        };
        $scope.openNRDForm = function (DeviceStatusColumn, ModelDescription) {
            $scope.ModelDescription = ModelDescription;
            $scope.DeviceStatusColumn = DeviceStatusColumn;
            var modalInstance1 = $modal.open({
                templateUrl: 'public/templates/modal/nrd-groups-status.html',
                controller: "statusChangeController",
                controllerAs: "statusChangeCtrl",
                scope: $scope,
                windowClass: 'nrd-groups-status-change',
                backdrop: 'static',
                keyboard: false
            });
        }
        $scope.getInvoiceReport = function () {
            processInvoiceServices.abortInvoiceProcess().then(function (response) {
                $scope.invoiceResponse = response.data;
                dataService.setMyData($scope.invoiceResponse);
                $scope.loadDataInvoice(true);
            });
        }
        $scope.deleteLastMonthData = function () {
            if (confirm('Are you sure you want to delete the data for the month of ' + $scope.invoiceAvailableData.endMonth + ' - ' + $scope.invoiceAvailableData.endYear + ' ?')) {
                if (($scope.invoiceAvailableData.endMonth === $scope.invoiceAvailableData.startMonth) &&
                    ($scope.invoiceAvailableData.endYear === $scope.invoiceAvailableData.startYear)) {
                    processInvoiceServices.deleteOneMonthData().then(function (response) {
                        $scope.getInvoiceReport();
                        $rootScope.disableSOW = true;
                        $rootScope.disableNavLinksDOP = true;
                        $rootScope.disableScrubber = true;
                    })
                } else {
                    processInvoiceServices.deleteLastMonthData().then(function (response) {
                        dataService.setMyData(response.data);
                        $scope.loadDataInvoice(true,true);
                    });
                }
            }
        }
        $scope.$on("$stateChangeStart", function (event) {
            if ($scope.modified && confirm('You have unsaved changes, click OK and press "Save All" to save data or click "Cancel" to leave the page'))
                event.preventDefault();
        });

    }]);