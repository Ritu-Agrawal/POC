﻿(function () {
    "use strict";
    angular.module('PerformanceDashboard')    
    .controller('scrubberSettingCtrl', ['$scope', 'scrubServices', function ($scope, scrubServices) {
        var self = this;
        $scope.modified = false;

        $scope.scrubberSettingsData = function () {
            scrubServices.postSLAData()
                .then(function successCallback(response) {
                    if ((response.success !== undefined && response.success == false) || response.data == "No data") {
                        $scope.serviceLevelData = [{ 'SLAName': "", 'Zone0': "", 'Zone1': "", 'Zone2': "", 'Zone3': "", 'Zone4': "", 'Zone5': "", 'Zone6': "", 'Zone7': "", 'Zone8': "", 'Zone9': "", 'Zone10': "", 'Zone11': "" }]
                        console.log('Service Level Agreement Error');
                    } else {
                        $scope.serviceLevelData = response.data;
                            scrubServices.postCCData()
                                .then(function successCallback(response) {
                                    if ((response.success !== undefined && response.success == false) || response.data == "No data") {
                                        $scope.contractCoverageData = [{ 'ContractName': "", 'MonStart': "", 'MonEnd': "", 'TueStart': "", 'TueEnd': "", 'WedStart': "", 'WedEnd': "", 'ThuStart': "", 'ThuEnd': "", 'FriStart': "", 'FriEnd': "", 'SatStart': "", 'SatEnd': "", 'SunStart': "", 'SunEnd': "" }];
                                        console.log('contract Coverage data Error');
                                    } else {
                                        $scope.contractCoverageData = response.data;
                                        scrubServices.postSAData()
                                            .then(function successCallback(response) {
                                                if ((response.success !== undefined && response.success == false) || response.data == "No data") {
                                                    $scope.serviceAnalysisData = [{ 'Country': "", 'Area': "", 'City': "", 'PostalCode': "", 'Address': "", 'DeviceGroup': "", 'SerialNumber': "", 'ContractCoverage': $scope.contractCoverageData[0].ContractName, 'SLA': $scope.serviceLevelData[0].SLAName }];
                                                    //$scope.serviceAnalysisData[0].ContractCoverage = $scope.contractCoverageData[0].ContractName;
                                                    //$scope.serviceAnalysisData[0].SLA = $scope.serviceLevelData[0].SLAName;
                                                    console.log('service Analysis Data Error');
                                                } else {
                                                    $scope.serviceAnalysisData = response.data;
                                                }
                                                
                                            });
                                    }
                                })
                    }
                })
        }
        $scope.dataChange = function () {
            $scope.modified = true;
        }

        //service analysis
        $scope.removeServiceAnalysisRow = function (index) {
            if (confirm("Are you sure ? You want to delete this row ?")) {
                $scope.dataChange();
                $scope.serviceAnalysisData.splice(index, 1);
            }
        };        
        $scope.addServiceAnalysisRow = function (stdata) {
            $scope.serviceAnalysisData.push({ 'Country': "", 'Area': "", 'City': "", 'PostalCode': "", 'Address': "", 'DeviceGroup': "", 'SerialNumber': "", 'ContractCoverage': $scope.contractCoverageData[0].ContractName, 'SLA': $scope.serviceLevelData[0].SLAName });
        };
        $scope.saveServiceAnalysisData = function () {
            $scope.errorMsgMandatory = false;
            $scope.savedServiceAnalysisList = [];
            $scope.serviceAnalysisData.forEach(function (soa) {
                console.log(soa);
                if ((soa.Country === "" || soa.Country === null)
                    && (soa.Area === "" || soa.Area === null)
                    && (soa.City === "" || soa.City === null)
                    && (soa.PostalCode === "" || soa.PostalCode === null)
                    && (soa.Address === "" || soa.Address === null)
                    && (soa.DeviceGroup === "" || soa.DeviceGroup === null)
                    && (soa.SerialNumber === "" || soa.SerialNumber === null)) {
                    $scope.errorMsgMandatory = true;
                }
                $scope.savedServiceAnalysisList.push(soa);
            });
            $scope.modified = false;
            console.log($scope.savedServiceAnalysisList);
            if (!$scope.errorMsgMandatory) {
                scrubServices.postUpdateSAData($scope.savedServiceAnalysisList)
                    .then(function successCallback(response) {
                        console.log('service analysis success')
                    });
            }
        }
        
        //service level agreement
        $scope.removeServiceLevelRow = function (index) {
            if (confirm("Are you sure ? You want to delete this row ?")) {
                $scope.dataChange();
                $scope.serviceLevelData.splice(index, 1);
            }
        };
        $scope.addServiceLevelRow = function (sla) {
            $scope.serviceLevelData.push({ 'SLAName': "", 'Zone0': "", 'Zone1': "", 'Zone2': "", 'Zone3': "", 'Zone4': "", 'Zone5': "",
                        'Zone6': "", 'Zone7': "", 'Zone8': "", 'Zone9': "", 'Zone10': "", 'Zone11': "" });
        };
        $scope.saveServiceLevelData = function () {
            $scope.savedServiceLevelList = [];
            $scope.serviceLevelData.forEach(function (sla) {
                $scope.savedServiceLevelList.push(sla);
            });
            $scope.modified = false;
            scrubServices.postUpdateSLAData($scope.savedServiceLevelList)
                .then(function successCallback(response) {
                    console.log('sla success')
            });
        }

        //contract coverage        
        $scope.removeContractCoverageRow = function (index) {
            if (confirm("Are you sure ? You want to delete this row ?")) {
                $scope.dataChange();
                $scope.contractCoverageData.splice(index, 1);
            }
        };
        $scope.addContractCoverageRow = function (cct) {
            $scope.contractCoverageData.push({ 'ContractName': "", 'MonStart': "", 'MonEnd': "", 'TueStart': "", 'TueEnd': "", 'WedStart': "", 'WedEnd': "", 'ThuStart': "", 'ThuEnd': "", 'FriStart': "", 'FriEnd': "", 'SatStart': "", 'SatEnd': "", 'SunStart': "", 'SunEnd': "" });
        };
        $scope.saveContractCoverageData = function () {
            $scope.savedContractCoverageList = [];
            $scope.contractCoverageData.forEach(function (cct) {
                $scope.savedContractCoverageList.push(cct);
            });
            $scope.modified = false;
            scrubServices.postUpdateCCData($scope.savedContractCoverageList)
                .then(function successCallback(response) {
                console.log('cct success')
            });
        }
    }])
}());