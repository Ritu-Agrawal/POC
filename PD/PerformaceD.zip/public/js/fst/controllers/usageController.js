﻿'use Strict'
//Usage controller begins
angular.module('PerformanceDashboard').controller("usageController", function ($scope, $rootScope, $http, $state, $timeout, dataService, BaseHTTPService, Constants, processInvoiceServices, shareUser) {
    $scope.fileUploadedMsgUsage = false;
    $scope.usage_inputs = true;
    $scope.notClicked = true;

    //select a excel file and store its info
    var formdataUsage = new FormData();
    $scope.getTheFiles = function ($files) {
        angular.forEach($files, function (value, key) {
            formdataUsage.set('fileExcel', value);
            formdataUsage.set("PDFileName", $rootScope.fileused.UserAccFileName);
        });
    }

    //upload the selected file 
    $scope.usageUploadFiles = function () {
        var url = Constants.API_URL + Constants.POST_UPLOAD_EXCEL_USAGE;
        $http({
            method: 'POST',
            url: url,
            data: formdataUsage,
            headers: {
                'Content-Type': undefined
            }
        }).then(function successCallback(response) {         
            //console.log(response.data);
            $scope.usageDataResponse = response.data.split(";");
            console.log($scope.usageDataResponse);
            $scope.fileUploadedMsgUsage = $scope.usageDataResponse[1];
            $timeout(function () {
                $scope.fileUploadedMsgUsage = false;
            }, 2000)
        }, function errorCallback(response) {
            console.log("upload file error in Usage")
        });
    }

    //disabling upload btn based on imported file
    $scope.disableBtns = function () {
        if (event.target.name === "uploaderInvoiceFiles")
            $('#uploadInvoiceFile').prop('disabled', true);
        else
            $('#usageProcessBtn').prop('disabled', true);
    }

    $scope.overwriteLocInfo = true;
    $scope.overwriteLocation = function () {
        $scope.overwriteLocInfo = !$scope.overwriteLocInfo ? false : true;
        //console.log($scope.overwriteLocInfo);
    }

    //Processing usage file function
    $scope.usageProcess = function () {
            var param = {
                "PDFileName": $rootScope.fileused.UserAccFileName,
                "IsOverRideLocation": $scope.overwriteLocInfo,
                "InputFileName": $scope.usageDataResponse[0]
            };
            BaseHTTPService.httpPost(Constants.POST_PROCESS_USAGE, param)
                .then(function successCallback(response) {
                    $scope.processUsageResponseData = response.data;
                    if (typeof ($scope.processUsageResponseData) == "string") {
                        //checking for specific alert msg from PD
                        if ($scope.processUsageResponseData.search("Installation") > 0) {
                            if (confirm($scope.processUsageResponseData)) {
                                BaseHTTPService.httpPost(Constants.POST_PROCESS_USAGE_NOT_RECOMMENDED, param)
                                   .then(function successCallback(response) {
                                       $scope.processUsageResponseDataNotRecommend = response.data;
                                       if (typeof ($scope.processUsageResponseDataNotRecommend) == "string") {
                                           alert($scope.processUsageResponseDataNotRecommend);
                                           $scope.resetFile();
                                           $scope.disableBtns();
                                       }
                                       else {
                                           dataService.setMyData($scope.processUsageResponseDataNotRecommend);
                                           processInvoiceServices.postUpdateFlagData(shareUser.get()).then(function (response) { })
                                           $state.go('main.ProcessInvoiceTable');
                                       }
                                   })
                            }
                            else {
                                $scope.resetFile();
                                $scope.disableBtns();
                            }
                        }
                        else {
                            alert($scope.processUsageResponseData);
                            $scope.resetFile();
                            $scope.disableBtns();
                        }
                    }
                    else if ($scope.processUsageResponseData[0].hasOwnProperty("Product_Number")) {
                        $scope.usageUnknownDevices = $scope.processUsageResponseData;
                        angular.forEach($scope.usageUnknownDevices, function (device) {
                            device.Minimum = "";
                            device.Maximum = "";
                            device.MultiFunctionDevice = false;
                            device.SupportsColorPrints = false;
                            device.Supprots11x17Prints = false;
                        })
                        $scope.usage_unknown_devices = true;
                        $scope.usage_inputs = false;
                        $("#invoiceReportTab").hide();
                    }
                    else {
                        dataService.setMyData($scope.processUsageResponseData);
                        processInvoiceServices.postUpdateFlagData(shareUser.get()).then(function (response) { })
                        $state.go('main.ProcessInvoiceTable');
                    }
                }, function errorCallback(response) {
                    $scope.resetFile();
                    $scope.disableBtns();
                    console.log("Process Usage Data Error");
                });
    }

    $scope.resetFile = function () {
        $("input#file2").val("");
    }
//deleting unknown device row
    $scope.removeRow = function (index) {
        $scope.usageUnknownDevices.splice(index, 1);
    };

    $scope.saveUsageDevice = function () {
        $scope.savedUsageDevicesList = [];
        $scope.usageUnknownDevices.forEach(function (device) {
            $scope.savedUsageDevicesList.push(device);
        });
        //console.log($scope.savedUsageDevicesList);
        var saveUsage = {
            "UnknownDevices": $scope.savedUsageDevicesList,
            "PDFileName": $rootScope.fileused.UserAccFileName,
            "InputFileName": $scope.usageDataResponse[0]
        };
        BaseHTTPService.httpPost(Constants.POST_SAVE_USAGE, saveUsage)
            .then(function successCallback(response) {
                $scope.processUsageResponseData = response.data;
                $scope.notClicked = false;
                if (typeof $scope.processUsageResponseData === "string"){
                    alert($scope.processUsageResponseData);
                    $state.reload();
                }
                else {
                    dataService.setMyData($scope.processUsageResponseData);
                    processInvoiceServices.postUpdateFlagData(shareUser.get()).then(function (response) { })
                    $state.go('main.ProcessInvoiceTable');
                }
            },
            function errorCallback(response) {
                console.log("update usage unknown device error")
            });        
    }
  
    $scope.skipAllUsageDevice = function () {
        $scope.savedUsageDevicesList = [];
        $scope.usageUnknownDevices.forEach(function (device) {
            $scope.savedUsageDevicesList.push(device);
        });
        var param = {
            "UnknownDevices": $scope.savedUsageDevicesList,
            "PDFileName": $rootScope.fileused.UserAccFileName,
            "InputFileName": $scope.usageDataResponse[0]
        };
        BaseHTTPService.httpPost(Constants.POST_SKIP_ALL_DEVICE_USAGE, param)
            .then(function successCallback(response) {
                $scope.skipAllResponse = response.data;
                $scope.notClicked = false;
                if (typeof $scope.skipAllResponse === "string") {
                    alert($scope.skipAllResponse);
                    $state.reload();
                }
                else {
                    dataService.setMyData($scope.skipAllResponse);
                    processInvoiceServices.postUpdateFlagData(shareUser.get()).then(function (response) { })
                    $state.go('main.ProcessInvoiceTable');
                }
            },
            function errorCallback(response) {
                console.log("skip all usage unknown devices error")
            });
    }

    $scope.abortUsageDevice = function () {
        var param = {           
            "PDFileName": $rootScope.fileused.UserAccFileName
        };
        BaseHTTPService.httpPost(Constants.POST_ABORT_INVOICE_PROCESS, param)
            .then(function successCallback(response) {
                $scope.abortResponse = response.data;
                $scope.notClicked = false;
                dataService.setMyData($scope.abortResponse);
                processInvoiceServices.postUpdateFlagData(shareUser.get()).then(function (response) { })
                $state.go('main.ProcessInvoiceTable');
            },
            function errorCallback(response) {
                console.log("Abort usage unknown devices error")
            });
    }
    $scope.$on("$stateChangeStart", function (event) {
        if ($scope.usage_unknown_devices && $scope.notClicked && confirm('Please click on Update/Skip All/Abort button to Process the uploaded usage file or "Cancel" to skip this file'))
            event.preventDefault();
    });

});