﻿/* Angular Service for All curd operation */
angular.module('SBRUI')
    .factory('BaseHTTPService', ['$http', '$rootScope', 'Constants', function ($http, $rootScope, Constants) {

        var baseHTTPService = {};
        baseHTTPService.httpGet = httpGet;
        baseHTTPService.httpPost = httpPost;
        baseHTTPService.httpDelete = httpDelete;

        return baseHTTPService;

        function httpGet(urlId) {
            var serviceUrl = Constants.API_URL + urlId;
            var httpRequest = {
                method: 'GET',
                url: serviceUrl,
                headers: {
                    'Content-Type': 'application/json'
                }
            }
            return $http(httpRequest);
        };

        function httpPost(urlId, postData, PDfile) {
            var serviceUrl = Constants.API_URL + urlId;
            // if PDfile is true then we will add selected account file in param 
            if (PDfile)
                postData =  constructPDFile(postData);
            var httpRequest = {
                method: 'POST',
                url: serviceUrl,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: postData
            }
            return $http(httpRequest);
        };

        function httpDelete(urlId) {
            var serviceUrl = Constants.API_URL + urlId;
            var httpRequest = {
                method: 'DELETE',
                url: serviceUrl,
                headers: {
                    'Content-Type': 'application/json'
                }
            }
            return $http(httpRequest);
        };

        function constructPDFile(jsonData) {
            if ($rootScope.fileused)
                jsonData.PDFileName = $rootScope.fileused.UserAccFileName;
            return jsonData;
        }

    }]);