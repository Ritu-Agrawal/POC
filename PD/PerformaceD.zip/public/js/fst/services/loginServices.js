﻿angular.module('PerformanceDashboard')
      .factory('loginServices', ['Constants', 'BaseHTTPService', '$rootScope', 'shareUser', function (Constants, BaseHTTPService, $rootScope, shareUser) {
          var loginServices = {
              getValiduser: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_VALIDATE_USER, param)
                  .then(this.handleSuccess, this.handleError('Error while getting user details'));
              },
              handleSuccess: function (response) { 
                  shareUser.store('UserEmail', response.config.data.UserEmail);
                  return response.data;
              },
              handleError: function (error) {
                  return function () {
                      console.log(error);
                      return { success: false, message: error };
                  };
              }
          };
          return loginServices;
      }])