﻿angular.module('PerformanceDashboard').factory('TokenInterceptor', ["$q", "$rootScope", "$injector",
function ($q, $rootScope, $injector) {
    var $http;
    return {
        request: function (config) {
            $rootScope.serverError = false;
            $rootScope.clientError = false;
            if (config.url.indexOf($rootScope.ServiceUrl) >= 0) {
                if ($rootScope.token != undefined) {
                    config.headers['Bearer'] = $rootScope.token;
                }
            }
            return config;
        },

        response: function (resp) {
            if (resp.headers('Bearer') != undefined) {
                if (resp.config.url.indexOf($rootScope.ServiceUrl) >= 0) {
                    $rootScope.token = resp.headers('Bearer');
                }        
            }
            return resp;
        },

        responseError: function (rejection) {
            var param = {
                //"appUser": $rootScope.appUser,
                //"appPwd": $rootScope.appPwd,
                "emailId": $rootScope.userId,
                "empId": $rootScope.authId
                //"refresh": true
            };
            var deferred = $q.defer();
            if (rejection.headers('Bearer') === "Bad token") {
                var rootUrl, loginUrl;
                if (rejection.config.url.indexOf($rootScope.ServiceUrl) >= 0) {
                    rootUrl = $rootScope.ServiceUrl;
                    loginUrl = $rootScope.loginUrl;
                }
                var url = rootUrl + loginUrl;
                $rootScope.token = undefined;
                $http = $http || $injector.get('$http');
                $http({
                    method: 'POST',
                    url: url,
                    data: param,
                    headers: {
                        "Content-Type": "application/json"
                    }
                })
                .success(function (data, status, headers, config) {
                    ////$rootScope.token = headers('Bearer');
                    $http(rejection.config).then(function (response) {
                        deferred.resolve(response);
                        //return deferred.promise;
                    },
                    function (response) {
                        deferred.reject(response);
                    });
                    return deferred.promise;
                })
                .error(function (data, status) {
                    deferred.reject(status);
                });
            }
            else {
                // if hhtp request is having error in reponse other then unauthorized  
                var $state = $injector.get('$state');
                switch (rejection.status) {
                    case 404:
                        $rootScope.clientError = true;
                        $('#dataDesignModel').modal('hide');
                        $('#myModal').modal('hide');
                        $('#dataDesignModel').modal('hide');
                        break;
                    case 500:
                        $rootScope.serverError = true;
                        $('#dataDesignModel').modal('hide');
                        $('#myModal').modal('hide');
                        $('#dataDesignModel').modal('hide');
                        break;
                    case 503:
                        $rootScope.serverError = true;
                        $('#dataDesignModel').modal('hide');
                        $('#myModal').modal('hide');
                        $('#dataDesignModel').modal('hide');
                        break;
                    default:
                        $rootScope.serverError = true;
                        $('#dataDesignModel').modal('hide');
                        $('#myModal').modal('hide');
                        $('#dataDesignModel').modal('hide');
                }
            }
            return deferred.promise;
        }
    };
}
]);