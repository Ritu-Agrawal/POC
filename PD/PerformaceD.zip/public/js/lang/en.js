App.lang = {
address: {
    single: "Address"
},
menus: {
    promotions:"Promotions",
    users : "Users",
    settings : "settings"
},
admin: {
    single: "Admin"
},

ad_type: {
    multi: "Ad Types",
    single: "Ad Type"
},

appear: {
    noun: "Appearance"
},

apply: {
    single: "Apply"
},

asset: {
    multi: "Assets",
    single: "Asset"
},


App.patterns = {

email: /^\w+(\.\w+)*@[a-zA-Z]+\.[a-zA-Z]{2,6}$/,
// password: /^.{8,20}$/,
password:/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])[0-9a-zA-Z]{8,20}$/,
url: /^(https:\/\/){1}(\w+\.iviereach\.com)(\/\w+)*$/
    
};