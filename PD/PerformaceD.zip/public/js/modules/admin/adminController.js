angular.module('SBRUI.SBR2ndPhase')
    .factory('AdminAccessServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
        var AdminAccessServices = {
            getDeviceData: function (param) {
                return BaseHTTPService.httpPost(Constants.GET_UNKNOWN_DEVICE_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            updateUnknownDevices: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_UNKNOWN_DEVICES_UPDATE, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            handleSuccess: function (response) {
                return response;
            },
            handleError: function (error) {
                return function () {
                    console.log(error);
                    return {
                        success: false,
                        message: error
                    };
                };
            }
        };
        return AdminAccessServices;
    }])
    .controller('adminController', ['$scope', '$http', '$timeout', 'shareUser', 'AdminAccessServices',
        function ($scope, $http, $timeout, shareUser, AdminAccessServices) {
            var self = this;
            self.errorMessageBlock = false;
            self.errorMessage = "Unknown Device Data Updated Successfully!!!";
            console.log("Admin Ctrl");
            /**
             * Loading total data of Unknown Device Data
             */
            self.loadUnknownDeviceData = function () {
                AdminAccessServices.getDeviceData(shareUser.get()).then(function (response) {
                    console.log(response);
                    self.unknownDevices = response.data;
                });
            }
            self.loadUnknownDeviceData();
            /**
             * When Click on Update, Sending Updated Unknown Device Data along with User details to Backend
             */
            self.updateUnknownDevices = function () {
                self.updateDeviceParam = [];
                self.updateDeviceParam.push({"UserDetails":shareUser.get()});
                self.updateDeviceParam.push({"unknownDevice":self.unknownDevices});
                console.log(self.updateDeviceParam);
                AdminAccessServices.updateUnknownDevices(self.updateDeviceParam).then(function (response) {
                    console.log(response);
                    self.errorMessageBlock = true;
                    $timeout(function () {
                        self.errorMessageBlock = false;
                        self.loadUnknownDeviceData();
                    }, 3000);
                });
            }
     }])
