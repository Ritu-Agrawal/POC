angular.module('SBRUI.SBR2ndPhase')
    .factory('dataDesignServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
        var dataDesignServices = {
            ddUpdateSuggestedDeviceData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_SUGGESTED_DEVICE_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            ddGetRowGraphData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_GET_GRAPH_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },

            handleSuccess: function (response) {
                return response;
            },
            handleError: function (error) {
                return function () {
                    console.log(error);
                    return {
                        success: false,
                        message: error
                    };
                };
            }
        };
        return dataDesignServices;
    }])
    //Storing User Details
    .factory('shareUser', ['$rootScope', '$http', function ($rootScope, $http) {
        var shareUser = {};
        return {
            store: function (key, value) {
                //$rootScope.$emit('scope.stored', key);
                shareUser[key] = value;
            },
            get: function (key) {
                return shareUser;
            }
        };
    }])
    //Filtering date
    .filter('cmdate', ['$filter', function ($filter) {
        return function (input, format) {
            //console.log("input -" + input + ", format-" + format);
            if (angular.isUndefined(input) || input === null || input === '') {
                return input;
            }
            return $filter('date')(new Date(input), format);
        };
    }])
    .filter("checkNagitiveVal", function () {
        return function (input) {
            if (input < 0) {
                return Math.abs(input);
            } else {
                return input;
            }
        }
    })
    .controller('dataDesignController', ['$scope', '$http', '$uibModal', 'sowServices', 'shareUser', '$rootScope',
        function ($scope, $http, $modal, sowServices, shareUser, $rootScope) {
            var self = this;
            console.log(shareUser.get($scope.sowStartEndData));
            //$scope.sowStartEndData getting Start and End date from SOW 
            //$scope.sowStartEndData = {
            //    "EndMonthIndex": 11,
            //    "InvoiceCount":12,
            //    "StartMonthIndex": 0
            //}
            self.userDetails = {};
            angular.merge(self.userDetails, $scope.sowStartEndData, shareUser.get());
            console.log(self.userDetails);
            /**
             * Calling API with sending User Details and Start End date   
             */
            sowServices.postGotoDataDesignSow(self.userDetails).then(function (response) {
                //console.log(response);                
                self.dataDesignData = response.data;
                //angular.forEach(self.dataDesignData, function (change) {
                //    change.editable = false;
                //});
                self.dataDesignDataTotal = response.data.length - 1;
                self.hdMonthTitle = self.dataDesignData[0].D_Caption.split("/");
                self.ddMonthsNo = self.hdMonthTitle[1].substr(self.hdMonthTitle[1].length - 9);
                self.getNumberfrmstr = /\d+/.exec(self.hdMonthTitle[1]);
                //var match = /\d+/.exec("one two 100");
                //console.log(self.getNumberfrmstr[0]);
                //$('#dataDesignModel').modal('hide');
            });
            //Getting data by calling local Json file
            //$http.get('public/js/json/datadesign/dynamic-data.json').success(function (response) {
            //    console.log(self.userDetails);
            //    self.datadesigndata = response;
            //    self.hdmonthtitle = self.datadesigndata[0].d_caption.split("/");
            //    self.ddmonthsno = self.hdmonthtitle[1].substr(self.hdmonthtitle[1].length - 9);
            //    $scope.totalitems = self.datadesigndata.length;
            //});
            //$http.get('public/js/json/datadesign/proposed-changes.json').success(function (response) {
            //    self.proposedChangesInfo = response;          
            //    angular.forEach(self.proposedChangesInfo, function (change) {
            //        change.editable = false;
            //    });
            //});
            /**
             * Proposed Changes - New Action Code Starts 
             */
            self.pcNewAction = function (val, cbox, row) {
                console.log(cbox.pcaction[val]);
                cbox.editable = true;
                angular.forEach(cbox.pcaction, function (chkbox, index) {
                    if (val != index) {
                        chkbox.checked = false;
                        if (!cbox.pcaction[val].checked) {
                            chkbox.disabled = false;
                            cbox.editable = false;
                        } else {
                            chkbox.disabled = true;
                        }
                    }
                });
                /**
                 * Featured Device New, Move and Delete
                 */
                //if (cbox.editable = false) {
                if (row.name === "new") {
                    cbox.send2device = true;
                    cbox.send2volume = true;
                    cbox.send2futureDevice = false;
                    //pchange.proposedChangesSource ="New"
                } else if (row.name === "move") {
                    cbox.send2device = false;
                    cbox.send2volume = false;
                    cbox.send2futureDevice = true;
                } else if (row.name === "delete") {
                    cbox.send2device = false;
                    cbox.send2volume = true;
                    cbox.send2futureDevice = true;
                }
                //}                
            }
            /**
             * Pagination for Total Data Table Section
             */
            //$scope.viewby = 5;
            //$scope.currentPage = 4;
            //$scope.itemsPerPage = $scope.viewby;
            //$scope.maxSize = 5; //Number of pager buttons to show
            //$scope.setPage = function (pageNo) {
            //    $scope.currentPage = pageNo;
            //};
            //$scope.setItemsPerPage = function (num) {
            //    $scope.itemsPerPage = num;
            //    $scope.currentPage = 1; //reset to first page
            //}
            //Save the each row Data in Proposed Changes Section
            self.updateProposedChangesRow = function () {
                //console.log("Save the each row data");
            }
            //Save ALL the Data in Proposed Changes Section
            //self.updateAllProposedChangesRows = function () {
            //    console.log("Save All the data");
            //}
            /**
             * Showing currency modal popup when click on currency button
             */
            self.showCurrencyModal = function (item) {
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/currency-conversion.html',
                    controller: 'currencyConversionController',
                    controllerAs: 'currencyConverstCtrl'
                    //resolve: {
                    //    item: function () {
                    //        return item || {};
                    //    }
                    //}
                });
            }
            /**
             * Device Mismatch modal popup when click on currency button
             */
            self.deviceMismatchModal = function (item) {
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/device-mismatch.html',
                    //controller: 'currencyConversionController',
                    //controllerAs: 'currencyConvertCtrl'
                });
            }
            /**
             * Showing grpah modal popup when click left side row
             * Sharing few details like User details and few of values of Main data to another Controller
             */
            self.showGraphs = function (graph) {
                if (graph.D_DeviceID != 0) {
                    var passtoGraph = {};
                    angular.merge(passtoGraph, graph, shareUser.get());
                    var modalInstance = $modal.open({
                        templateUrl: 'public/templates/modal/data-design-graph.html',
                        size: 'lg',
                        animation: true,
                        windowClass: 'data-design-modal',
                        controller: 'dataDesignGraphController',
                        controllerAs: 'dgraphCtrl',
                        resolve: {
                            passtoGraph: function () {
                                return passtoGraph || {};
                            }
                        }
                    });
                }
            }
            /**
             * Set Suggested Device modal popup
             */
            self.setSuggestedDevice = function () {
                //var passtoGraph = {};
                //angular.merge(passtoGraph, graph, shareUser.get());
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/suggested-device.html',
                    size: 'md',
                    animation: true,
                    //windowClass: 'data-design-modal',
                    controller: 'dataDesignSuggestDeviceController',
                    controllerAs: 'sugestDevCtrl',
                    //resolve: {
                    //    passtoGraph: function () {
                    //        return passtoGraph || {};
                    //    }
                    //}
                });
            }
        }])
    .controller('dataDesignSuggestDeviceController', ['$scope', '$http', '$uibModal', 'Constants', 'shareUser', 'dataDesignServices',
        function ($scope, $http, $modal, Constants, shareUser, dataDesignServices) {
            var self = this;
            console.log(shareUser.get());
            self.sugestDevice = {
                'colorPages': 10,
                'faxRecievePages': 10,
                'largeFormatPages': 10,
                'maxSuggestPages': 200,
                'minSuggestPages': 75
            }
            /**
             * Calling API to Update Suggested Device  
             */
            self.updateSuggestedValue = function (sugest) {
                console.log(sugest);
                var SugestDeviceParam = {};
                angular.merge(SugestDeviceParam, sugest, shareUser.get());

                dataDesignServices.ddUpdateSuggestedDeviceData(SugestDeviceParam).then(function (response) {
                    console.log(response);
                });
                //$http({
                //    method: 'POST',
                //    url: Constants.POST_SUGGESTED_DEVICE_DATA,
                //    data: SugestDeviceParam
                //}).then(function successCallback(response) {
                //    console.log(response);
                //}, function errorCallback(response) {
                //    console.log(response);
                //});
            }
            /**
             * Reset suggested Device values
             */
            self.resetSuggestedValue = function () {
                self.getBackSugestDevice = {
                    'colorPages': "10",
                    'faxRecievePages': "10",
                    'largeFormatPages': "10",
                    'maxSuggestPages': "200",
                    'minSuggestPages': "75"
                }
                self.sugestDevice = angular.copy(self.getBackSugestDevice);
            }
        }])
    .filter('makePositive', function () {
        return function (num) { return Math.abs(num); }
    })
    .controller('dataDesignGraphController', ['$scope', '$http', '$uibModalInstance', '$uibModal', 'passtoGraph', 'Constants', 'shareUser', 'dataDesignServices',
        function ($scope, $http, $modalInstance, $modal, passtoGraph, Constants, shareUser, dataDesignServices) {
            var self = this;
            //self.shareUser.get();
            //self.graphparam = {};
            //angular.merge(self.graphparam, passtoGraph, shareUser.get());
            //console.log(shareUser.get()); 
            //console.log(self.graphparam);
            //Closing modal here
            self.closeModal = function () {
                $modalInstance.dismiss('cancel');
            };
            self.modalData = passtoGraph;
            self.hdMonthTitle = passtoGraph.D_Caption.split("/");
            self.getNumberfrmstr = /\d+/.exec(self.hdMonthTitle[1]);
            /**
             * Calling API to load all the data 
             */
            dataDesignServices.ddGetRowGraphData(passtoGraph).then(function (response) {
                console.log(response); 
                self.dataDesignTable = response.data.Data[0];
                self.dataDesignGraphs = response.data.Graphs;
                self.ddBarChartData = self.dataDesignGraphs[0].ChartData;
                self.ddBar2ChartData = self.dataDesignGraphs[1].ChartData;
                self.ddBar3ChartData = self.dataDesignGraphs[2].ChartData;
                self.ddLineChartData = self.dataDesignGraphs[3].ChartData;
                console.log(self.ddLineChartData);
            });
            //$http({
            //    method: 'POST',
            //    url: Constants.POST_GET_GRAPH_DATA,
            //    data: passtoGraph
            //}).then(function successCallback(response) {
            //    console.log(response);
            //    self.dataDesignTable = response.data.Data[0];
            //    self.dataDesignGraphs = response.data.Graphs;
            //    self.ddBarChartData = self.dataDesignGraphs[0].ChartData;
            //    self.ddBar2ChartData = self.dataDesignGraphs[1].ChartData;
            //    self.ddBar3ChartData = self.dataDesignGraphs[2].ChartData;
            //    self.ddLineChartData = self.dataDesignGraphs[3].ChartData;
            //    console.log(self.ddLineChartData);
            //}, function errorCallback(response) {
            //    console.log(response);
            //});
            /**
             * Setting Revenue Chart Options  
             */
            self.ddBarChartOptions = {
                chart: {
                    type: 'discreteBarChart',
                    height: 250,
                    margin: {
                        top: 20,
                        right: 20,
                        bottom: 60,
                        left: 100
                    },
                    x: function (d) { return d.key; },
                    y: function (d) { return d.value; },
                    showValues: true,
                    valueFormat: function (d) {
                        return self.ddBarChartData[0].Currency + d3.format(',f')(d);
                    },
                    transitionDuration: 500,
                    xAxis: {
                        axisLabel: '',
                        rotateLabels: 30
                    },
                    yAxis: {
                        axisLabel: '',
                        axisLabelDistance: 10,
                        tickFormat: function (d) {
                            return self.ddBarChartData[0].Currency + d3.format(',f')(d);
                        }
                    },
                    tooltip: {
                        contentGenerator: function (d) {
                            //console.log(d);
                            return 'Series "' + d.data.key + '" Point "' + " " + '" <br> Value: ' + d.data.value;
                        }
                    }
                    //yDomain: [1, 30000]
                }
            };
            /**
             * Setting Usage Color Chart Options  
             */
            self.ddBar2ChartOptions = {
                chart: {
                    type: 'discreteBarChart',
                    height: 300,
                    margin: {
                        top: 20,
                        right: 100,
                        bottom: 100,
                        left: 100
                    },
                    x: function (d) { return d.key; },
                    y: function (d) { return d.value; },
                    showValues: true,
                    valueFormat: function (d) {
                        return d3.format(',f')(d);
                    },
                    transitionDuration: 500,
                    xAxis: {
                        axisLabel: '',
                        rotateLabels: 30
                    },
                    yAxis: {
                        axisLabel: 'Pages',
                        axisLabelDistance: 10
                    },
                    tooltip: {
                        contentGenerator: function (d) {
                            //console.log(d);
                            return 'Series "' + d.data.key + '" Point "' + " " + '" <br> Value: ' + d.data.value;
                        }
                    }
                }
            };
            /**
             * Setting Engine Life Chart Options  
             */
            self.ddBar3ChartOptions = {
                chart: {
                    type: 'discreteBarChart',
                    height: 300,
                    margin: {
                        top: 20,
                        right: 50,
                        bottom: 100,
                        left: 100
                    },
                    x: function (d) { return d.key; },
                    y: function (d) { return d.value; },
                    showValues: true,
                    valueFormat: function (d) {
                        return d3.format(',f')(d);
                    },
                    transitionDuration: 500,
                    xAxis: {
                        axisLabel: '',
                        rotateLabels: 30
                    },
                    yAxis: {
                        axisLabel: 'Pages',
                        axisLabelDistance: 10
                    },
                    tooltip: {
                        contentGenerator: function (d) {
                            //console.log(d);
                            return 'Series "' + d.data.key + '" Point "' + " " + '" <br> Value: ' + d.data.value;
                        }
                    }
                }
            };
            /**
             * Setting Usage Chart Options
             */
            self.ddLineChartOptions = {
                chart: {
                    type: 'lineChart',
                    height: 400,
                    margin: {
                        top: 20,
                        right: 50,
                        bottom: 100,
                        left: 55
                    },
                    x: function (d) { date = new Date(d.x); return date; },
                    y: function (d) { return d.y; },
                    useInteractiveGuideline: false,
                    xScale: d3.time.scale(), // <-- explicitly set time scale
                    dispatch: {
                        stateChange: function (e) { console.log("stateChange"); },
                        changeState: function (e) { console.log("changeState"); },
                        tooltipShow: function (e) { console.log("tooltipShow"); },
                        tooltipHide: function (e) { console.log("tooltipHide"); }
                    },
                    xAxis: {
                        ticks: d3.time.months, // <-- add formatter for the ticks
                        axisLabel: 'Usage Month - Year',
                        tickFormat: function (d) {
                            return d3.time.format('%b-%y')(new Date(d));
                        },
                        showMaxMin: true,
                        rotateLabels: 30
                    },
                    yAxis: {
                        axisLabel: 'Pages',
                        tickFormat: function (d) {
                            return d3.format('f')(d);
                        },
                        axisLabelDistance: -10
                    },
                    lines: { //options for basic line model; main chart
                        forceY: 0
                    },
                    tooltip: {
                        contentGenerator: function (d) {
                            return 'Series "' + d.series[0].key + '" Point "' + d3.time.format('%b-%y')(new Date(d.point.x)) + '" <br> Value: ' + d.point.y;
                        }
                    }
                },
                title: {
                    enable: true,
                    text: 'Usage Chart'
                },
            };
        }])
    .directive('numbersOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    });
