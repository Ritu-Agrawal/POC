﻿//service to set data from one controller and to use them in another controller
angular.module('PerformanceDashboard')

//invoice controller begins
.controller('multipleController', function ($scope, $rootScope, $window, $http, $filter, $state, $timeout, dataService, Constants, BaseHTTPService, $uibModal, shareUser) {
    $scope.invoice_inputs = true;
    $scope.fileUploadedMsg = false;
    angular.element(document.querySelector('.must-pairing')).prop('hidden', true);
    angular.element(document.querySelector('.additional-pairing')).prop('hidden', true);
    $scope.notClicked = true;
    var noOfInvoice = 0;
    $scope.invoiceData = [1,2,3,4,5,6,7,8,9,10,11,12];
    $scope.invoiceFlag = false;
    $scope.paymentFlag = false;
    $scope.currencyFlag = false;
    $scope.disbleFileUpload = true;
    $scope.disableSingleInvoice = true;
    $scope.uploadInvoiceFile = true;
    $scope.fileVal = 'load';
    $scope.invoiceLoadedMonths = [];
    //Termp
    $(function () {
        var newHeight = $("#column_link").height();
        $("#prev_height").height(newHeight);
        $("#inv_height").height(newHeight);
       // $('.chooseBtn').width($(".inputfile").width()) //inputfile
    });
    
    $scope.onDrop = function (srcList, srcIndex, targetList, targetIndex) {
        targetList.splice(targetIndex, 0, srcList[srcIndex]);
        if (srcList == targetList && targetIndex <= srcIndex) srcIndex++;
        srcList.splice(srcIndex, 1);
        return true;
    };

    function generateList() {
        return $scope.files.map(function (letter) {
            return {
                labelFunc: function (index) {
                    return letter;
                }
            };
        });
    }
    $scope.files = [];
    $scope.MonthArr = [];
    $scope.yearArr = [];
    $scope.selectedRowData = 0;
    $scope.selectedRowSheet = 0;
    $scope.selectedRowFile = 0;
    var month = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    function tempDATA() {
        $scope.fullDetails = $scope.filesData[$scope.selectedRowFile].SheetDetails;
        $scope.invoiceDetail = $scope.fullDetails[$scope.selectedRowSheet].sheetValue;
        var data = $scope.invoiceDetail[$scope.selectedRowData].RowValues;
        $scope.headingRowData = [];
        for (var i = 0; i < data.length; i++) {
            $scope.headingRowData.push({ ColumnName: data[i] })
        }
    }
    var setMonthRange = function () {
        $scope.MonthArr = [];
        $scope.yearArr = [];
        if ($scope.mergeMonth !== undefined && $scope.mergeMonth !== null && $scope.mergeMonth !== "Select Month") {
            var selectedMon = month.indexOf($scope.mergeMonth.split("-")[0]);
            var selectedYear = $scope.mergeMonth.split("-")[1];
        }else {
            var selectedMon = $scope.Months.indexOf($scope.monthVal);
            var selectedYear = $scope.yearVal;
        }
        angular.forEach($scope.files, function (value, key) {
            $scope.MonthArr.push(month[selectedMon]);
            $scope.yearArr.push(selectedYear);
            if (selectedMon < 11)
                selectedMon++;
            else {
                selectedYear++;
                selectedMon = 0;
            }
        });
    }
    $scope.mergeMonthSelected = function () {
            setMonthRange();
    }
    $scope.setClickedRowData = function (index) {
        $scope.selectedRowData = index;
        tempDATA();
    }
    $scope.setClickedRowSheet = function (index) {
        $scope.selectedRowSheet = index;
        $scope.selectedRowData = 0;
        tempDATA();
    }
    $scope.setClickedRowFile = function (index) {
        $scope.selectedRowFile = index;
        $scope.selectedRowSheet = 0;
        $scope.selectedRowData = 0;
        tempDATA();
    }
    $scope.loadSingleInvoice = function () {
        var copy = $scope.files[0];
        $scope.files = [];
        for (i = 0; i < $scope.selectedInvoiceCopies ; i++) {
            $scope.files.push(copy);
        }
        $scope.list = generateList($scope.files);
        setMonthRange();
    }
    $scope.clearAllFiles = function () {
        $scope.disbleFileUpload = false;
        $scope.files = [];
        $scope.MonthArr = [];
        $scope.yearArr = [];
        $scope.list = generateList($scope.files);
        angular.element("input[type='file']").val(null);
        $scope.fullDetails = [];
        $scope.invoiceDetail = [];
        $scope.fileUploadFlag = false;
    }
    //Termp
    //gets available data range on  page load
    $scope.invoiceUsageNav = function () {
        var param = {
            "PDFileName": $rootScope.fileused.UserAccFileName
        };
        BaseHTTPService.httpPost(Constants.POST_AVAILABLE_DATA, param)
            .then(function successCallback(response) {
                //select month year invoice copies and payment model based on available data
                $rootScope.invoiceUsageNavData = JSON.parse('{' + (response.data) + '}');
                if ($scope.invoiceUsageNavData.startMonth === undefined) {
                    //$scope.monthVal = $scope.Months[0];
                    //$scope.yearVal = $scope.years[$scope.years.length - 1];
                    $("#usageReportTab").hide();
                    //$("#usageReportTab").removeAttr("data-toggle").attr("disabled", "disabled");
                }
                if ($scope.invoiceUsageNavData.IsUploadedUsage === 'True') {
                    $rootScope.disableSOW = false;
                    $rootScope.disableScrubber = false;
                }
                else {
                    $rootScope.disableSOW = true;
                    $rootScope.disableNavLinksDOP = true;
                    $rootScope.disableScrubber = true;
                }
                if ($scope.invoiceUsageNavData.endMonth !== undefined && $scope.invoiceUsageNavData.endMonth !== "") {
                    $scope.lastMonthVal = $scope.invoiceUsageNavData.endMonth;
                    $scope.lastYearVal = parseInt($scope.invoiceUsageNavData.endYear);
                    var months;
                    months = (parseInt($scope.invoiceUsageNavData.endYear) - parseInt($scope.invoiceUsageNavData.startYear)) * 12;
                    months -= parseInt($scope.Months.indexOf($scope.invoiceUsageNavData.startMonth));
                    months += parseInt($scope.Months.indexOf($scope.invoiceUsageNavData.endMonth)) + 1;
                    noOfInvoice = months;
                    $scope.invoiceFlag = true;
                } else if ($scope.invoiceUsageNavData.startMonth !== undefined && $scope.invoiceUsageNavData.startMonth !== "") {
                    // only one month data  available
                    $scope.lastMonthVal = $scope.invoiceUsageNavData.startMonth;
                    $scope.lastYearVal = parseInt($scope.invoiceUsageNavData.startYear);
                    noOfInvoice = 1;
                    $scope.invoiceFlag = true;
                }

                if ($scope.invoiceUsageNavData.startMonth) {
                    $scope.invoiceLoadedMonths = ["Select Month"];
                    var startDate = moment(new Date("01-" + $scope.invoiceUsageNavData.startMonth + "-" + $scope.invoiceUsageNavData.startYear));
                    var endDate = moment(new Date("01-" + $scope.invoiceUsageNavData.endMonth + "-" + $scope.invoiceUsageNavData.endYear)).add(1, 'M');
                    var currentDate = startDate.clone();
                    while (currentDate.isBefore(endDate)) {
                        $scope.invoiceLoadedMonths.push(moment(currentDate, 'DD/MM/YYYY').format("MMMM-YYYY"));
                        currentDate.add(1, 'month');
                    }
                    $scope.mergeMonth = $scope.invoiceLoadedMonths[0];
                    $scope.replaceMonth = $scope.invoiceLoadedMonths[0];
                }
                if ($scope.lastMonthVal !== undefined && $scope.lastMonthVal !== "") {
                    //check for payment Model
                    if ($scope.invoiceUsageNavData.PaymentModel !== undefined) {
                        if ($scope.invoiceUsageNavData.PaymentModel == "TRUE") {
                            $scope.changedVal = "True"
                        }
                        else {
                            $scope.changedVal = "False"
                        }
                        $scope.paymentFlag = true;
                    }
                    //select month and year dropdown
                    var lastMonthIndex = parseInt($scope.Months.indexOf($scope.lastMonthVal));
                    if (lastMonthIndex === 11) {
                        $scope.yearVal = $scope.lastYearVal + 1;
                        lastMonthIndex = 0;
                    } else {
                        $scope.yearVal = $scope.lastYearVal;
                        lastMonthIndex = lastMonthIndex + 1;
                    }
                    $scope.monthVal = $scope.Months[lastMonthIndex];
                }
                $scope.disbleFileUpload = !($scope.paymentFlag && $scope.invoiceFlag);
            },
            function errorCallback(response) {
                console.log('data range error');
            });
        BaseHTTPService.httpPost(Constants.POST_CURRENCY_DATA, param)
                .then(function successCallback(response) {
                    $scope.currencyData = JSON.parse(response.data);
                    //console.log($scope.currencyData.RowData[1]);
                    //auto populate source, target currency from 2nd invoice
                    if ($scope.invoiceUsageNavData.TargetCurrency !== "" && $scope.invoiceUsageNavData.TargetCurrency !== undefined) {
                        var trgCurr = $scope.invoiceUsageNavData.TargetCurrency.split(" ")[0];
                        for (var i = 0; i < $scope.currencyData.CurrencyDetails.length; i++) {
                            if ($scope.currencyData.CurrencyDetails[i].Currency_Listing.split(" ")[0].match(trgCurr)) {
                                prevTrgCurr = $scope.currencyData.CurrencyDetails[i];
                                $scope.targetCurrencyData = prevTrgCurr;
                                $scope.currencyFlag = true;
                            }
                        }
                        var srcCurr = $scope.invoiceUsageNavData.SourceCurrency.split(" ")[0];
                        for (var j = 0; j < $scope.currencyData.CurrencyDetails.length; j++) {
                            if ($scope.currencyData.CurrencyDetails[j].Currency_Listing.split(" ")[0].match(srcCurr)) {
                                prevSrcCurr = $scope.currencyData.CurrencyDetails[j];
                                $scope.sourceCurrencyData = prevSrcCurr;
                            }
                        }
                    }
                        //selecting USD currency available values in dropdown
                    else {
                        for (var i = 0; i < $scope.currencyData.CurrencyDetails.length; i++) {
                            if ($scope.currencyData.CurrencyDetails[i].Currency_Listing.split(" ")[0].match("USD")) {
                                var selectedCurr = $scope.currencyData.CurrencyDetails[i];
                                $scope.targetCurrencyData = selectedCurr;//$scope.currencyData.CurrencyDetails[0];
                                $scope.sourceCurrencyData = selectedCurr; //$scope.currencyData.CurrencyDetails[0];
                            }
                        }
                    }
                    $scope.selectedInvoiceCopies = $scope.invoiceData[0];
                    $scope.selectedSheet = $scope.sheetData[0];
                    $scope.selectedItem = $scope.currencyData.RowData[0][0];
                    $scope.getselectvalue();
                    angular.element(document.querySelector('.must-pairing')).prop('hidden', false);
                    angular.element(document.querySelector('.additional-pairing')).prop('hidden', true);
                    $scope.fileUploadedMsg = true;
                    $scope.uploadInvoiceFile = true;
                    //file uploaded message displays for 6sec
                    $timeout(function () {
                        $scope.fileUploadedMsg = false;
                    }, 6000)
                },
                function errorCallback(response) {
                    console.log("Get currency error")
                });
    }

    //select a excel file and store its info
    var formdata = new FormData();
    $scope.getTheFiles = function ($files) {
        $scope.files = [];
        angular.forEach($files, function (value, key) {
            formdata.set('fileExcel' + key, value);
            formdata.set("PDFileName", $rootScope.fileused.UserAccFileName);
            $scope.files.push(value.name);
        });
        $scope.list = generateList($scope.files);
        angular.element("#uploadInvoiceFile").click()
        //$scope.loadInputFiles();
    };
    $scope.loadInputFiles = function () {
        setMonthRange();
        $scope.uploadInvoiceFile = true;
        $scope.disbleFileUpload = true;
        $scope.disableReplaceInvoice = true;
        $scope.disableSingleInvoice = true;
        if ($scope.files.length === 1) {
            $scope.disableSingleInvoice = false;
        }
    }
    //upload the selected file 
    $scope.uploadFiles = function () {
        //API to post uploaded excel data
        if ($scope.fileUploadFlag) {
            var url = Constants.API_URL + Constants.POST_UPLOAD_MULTIPLE_EXCEL;
            $http({
                method: 'POST',
                url: url,
                data: formdata,
                headers: {
                    'Content-Type': undefined
                }
            }).then(function successCallback(response) {
                $scope.filesData = response.data;
                angular.forEach($scope.filesData,function(file){
                    angular.forEach(file.SheetDetails, function (sheet) {
                        angular.forEach(sheet.sheetValue, function (row) {
                            row.RowValues = row.RowValues[0].split(";");
                        })
                    })
                })
                tempDATA();
            }, function errorCallback(response) {
                console.log("upload file error")
            });
        }
    }

    //to select Heading row and Data row function
    $scope.getselectvalue = function () {
        $scope.selectedHeadingRow = $scope.selectedItem;
        var SelectedParam = {};
        //console.log($scope.selectedSheet);
        SelectedParam.TableName = $scope.selectedSheet.TABLE_NAME;
        SelectedParam.HeadingRow = $scope.selectedHeadingRow;
        SelectedParam.InputFileName = $scope.selectedSheet.InputFileName;
        //API to fetch heading row data on change of dropdown values
        BaseHTTPService.httpPost(Constants.POST_DATA_ROW_SELECT, SelectedParam)
            .then(function successCallback(response) {
               // $scope.headingRowData = response.data;
                var parsedResult = parseInt($scope.selectedHeadingRow);
                parsedResult += 1;
                $scope.dataRow = parsedResult;
                $scope.resetBtnEnable = true;
                var param = {
                    "PDFileName": $rootScope.fileused.UserAccFileName
                };
                //API to get previous paired columns data
                BaseHTTPService.httpPost(Constants.POST_PAIRED_COLUMN, param)
                    .then(function successCallback(response) {
                        $scope.PairedColumns = response.data;
                        pairedArray = [];
                        pairedIndex = 0;
                        for (var i = 0; i < $scope.PairedColumns.length; i++) {
                            var dcText_brac = $scope.PairedColumns[i].split('-->')[0].split('(')[0];
                            var scText = $scope.PairedColumns[i].split('-->')[1].split('×')[0];
                            var dcLi = $('#def-col li');
                            var scLi = $('#src-col li');
                            for (var j = 0; j < scLi.length; j++) {
                                var scLiNode = $('#src-col li')[j];
                                if (scLiNode.textContent.match(scText)) {
                                    var scID = $('#src-col li')[j].id;
                                    for (var k = 0; k < dcLi.length; k++) {
                                        var dcLiNode = $('#def-col li')[k];
                                        if (dcLiNode.textContent.match(dcText_brac)) {
                                            var dcID = $('#def-col li')[k].id;
                                            var pairedElement = '<li id="i' + dcID + '"><span id="' + scID + '">' + $scope.PairedColumns[i] + '</span><span class="delete" id="paired-' + pairedIndex + '">×</span></li>';
                                            pairedArray.push(pairedElement);
                                            pairedElementText = $(pairedElement).text().split('×')[0];
                                            pairedIndex++;

                                            $('#paired').html(pairedArray);
                                            $scope.validateProcessBtn();
                                            for (var l = 0; l < pairedArray.length; l++) {
                                                var getid = $('#paired li')[l].id.slice(1);
                                                $("#" + getid).addClass('paired');
                                                $("#" + scID).addClass('paired');
                                                var getText = $('#paired li')[l].innerText.split('×')[0];
                                                $("#" + getid).text(getText);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        //close btn on paired columns
                        $('#paired li span').click(function () {
                            event.preventDefault();
                            var parentUL = $(this).closest('li')[0].outerHTML;
                            var getElementId = $(this).closest('li').attr('id');
                            var idElement = getElementId.substr(1, getElementId.length);
                            var unPairInnerText = $('#' + idElement).text().trim().split("-->")[0].trim();
                            var unPair = $('#' + idElement).html(unPairInnerText).removeClass('paired');
                            var unpairSourceId = $(this).closest('li').children()[0].id;
                            $('#' + unpairSourceId).removeClass('paired');
                            $(this).closest('li').remove();
                            var index = pairedArray.indexOf(parentUL);
                            if (index > -1) {
                                pairedArray.splice(index, 1);
                            }
                            $scope.validateProcessBtn();
                        });
                    },
                function errorCallback(response) {
                    console.log("Paired column data error")
                });
            },
            function errorCallback(response) {
                console.log("column data error")
            });
    }
    //PaymentSelected
    $scope.PaymentSelected = function () {
        $scope.disbleFileUpload = !($scope.changedVal !== undefined && $scope.monthVal !== undefined && $scope.yearVal !== undefined && $scope.changedVal !== '' && $scope.monthVal !== '' && $scope.yearVal !== '');
    }

    //Month Selection
    $scope.Months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    $scope.selectMonth = function () {
        $scope.selectedMonth = $scope.Months.indexOf($scope.monthVal) + 1;
        $scope.disbleFileUpload = !($scope.changedVal !== undefined && $scope.monthVal !== undefined && $scope.yearVal !== undefined && $scope.changedVal !== '' && $scope.monthVal !== '' && $scope.yearVal !== '')
    }
    //Year Selection
    $scope.year = new Date().getFullYear();
    $scope.years = [];
    for (var i = 2010; i < $scope.year + 1; i++) {
        $scope.years.push(i);
    }
    $scope.selectYear = function () {
        $scope.selectedYears = $scope.yearVal;
        $scope.disbleFileUpload = !($scope.changedVal !== undefined && $scope.monthVal !== undefined && $scope.yearVal !== undefined && $scope.changedVal !== '' && $scope.monthVal !== '' && $scope.yearVal !== '')
    }
    //Datepicker
    $scope.options = {
        maxDate: new Date()
    }
    $scope.processDate = function (currencyDate) {
        $scope.formattedDate = $filter('date')(currencyDate, 'MMMM dd, yyyy');
    }
    //Currency btn
    $scope.dateCurrency = function () {
        $scope.UpdateCurrency = {};
        $scope.UpdateCurrency.Currency = $scope.targetCurrencyData.Currency_Listing;
        $scope.UpdateCurrency.DateTime = $scope.formattedDate;
        $scope.UpdateCurrency.PDFileName = $rootScope.fileused.UserAccFileName;
        BaseHTTPService.httpPost(Constants.POST_UPDATE_CURRENCY_CONVERSION, $scope.UpdateCurrency)
            .then(function successCallback(response) {
                //console.log(response);
            }, function errorCallback(response) {
                //console.log("selected date-currency error")
            });
    }

    $scope.setDefaultColumn = function () {
        $scope.defaultcolumn = [{ ColumnName: "Area (Recommended)" }, { ColumnName: "Site (Recommended)" }, { ColumnName: "Building" }, { ColumnName: "Level" }, { ColumnName: "Grid" }, { ColumnName: "Business Unit" }, { ColumnName: "Model Name (Req'd)" },
             { ColumnName: "Serial Number (Req'd)" }, { ColumnName: "Product Code (Req'd)" }, { ColumnName: "Base Charge (1 Req'd)" },
             { ColumnName: "Mono Click Rate (1 Req'd)" }, { ColumnName: "Color Click Rate (1 Req'd)" },
             { ColumnName: "Color Pro Click Rate (1 Req'd)" }];
    }
    $scope.setDefaultColumn();

    //Reset all paired data
    $scope.resetPairedColumn = function () {
        pairedArray_close = [];
        pairedArray = [];
        pairedIndex = 0;
        $("#paired").empty();
        $('#src-col li').removeClass('paired');
        $scope.setDefaultColumn();
        $scope.validateProcessBtn();
        var newHeight = $("#column_link").height();
        $("#prev_height").height(newHeight);
        $("#inv_height").height(newHeight);
    }

    //enabling ProcessInvoice btn validations
    $scope.validateProcessBtn = function () {
        if (pairedArray.length > 3 && $('#dc-6,#dc-7,#dc-8').not('.paired').length == 0 && $('#dc-9,#dc-10,#dc-11,#dc-12').is('.paired')) {
            angular.element(document.querySelector('#processInvoiceBtn')).prop('disabled', false);
            angular.element(document.querySelector('.must-pairing')).prop('hidden', true);
            angular.element(document.querySelector('.additional-pairing')).prop('hidden', false);
        }
        else {
            angular.element(document.querySelector('#processInvoiceBtn')).prop('disabled', true);
            if (angular.element(document.querySelector("#src-col li")).length > 0) {
                angular.element(document.querySelector('.must-pairing')).prop('hidden', false);
                angular.element(document.querySelector('.additional-pairing')).prop('hidden', true);
            }
        }
        var newHeight = $("#column_link").height();
        $("#prev_height").height(newHeight);
        $("#inv_height").height(newHeight);
        
    }
    $scope.validateProcessBtn();

    //process invoice function      
    $scope.processInvoiceData = function () {
        if ($scope.monthVal == undefined || $scope.yearVal == undefined)
            alert("Please ensure Month and Year is selected !")
        else if ($scope.changedVal == undefined)
            alert("Please select Payment Model");
        else {
            $scope.textPairedArray = [];
            $scope.pairedArray_close = [];

            for (var i = 0; i < pairedArray.length; i++) {
                $scope.pairedArray_close.push($(pairedArray[i]).text().split('×')[0]);
            }
            for (var j = 0; j < $scope.pairedArray_close.length; j++) {
                $scope.textPairedArray.push({ ColumnName: $scope.pairedArray_close[j] });
            }
            $scope.selectedMonth = $scope.Months.indexOf($scope.monthVal) + 1;
            $scope.selectedYears = $scope.yearVal;

            $scope.ProcessInvoice = {};
            $scope.ProcessInvoice.FileName = file_name;
            $scope.ProcessInvoice.Month = $scope.selectedMonth;
            $scope.ProcessInvoice.Year = $scope.selectedYears;
            $scope.ProcessInvoice.InvoiceCopies = $scope.selectedInvoiceCopies;
            $scope.ProcessInvoice.PaymentModel = $scope.changedVal;
            $scope.ProcessInvoice.SourceCurrency = $scope.sourceCurrencyData.Currency_Listing;
            $scope.ProcessInvoice.TargetCurrency = $scope.targetCurrencyData.Currency_Listing;
            $scope.ProcessInvoice.TableName = $scope.selectedSheet.TABLE_NAME;
            $scope.ProcessInvoice.InputFileName = $scope.selectedSheet.InputFileName;
            $scope.ProcessInvoice.HeadingRow = $scope.selectedHeadingRow;
            $scope.ProcessInvoice.DataRow = $scope.dataRow;
            $scope.ProcessInvoice.PairedColumns = $scope.textPairedArray;
            $scope.ProcessInvoice.PDFileName = $rootScope.fileused.UserAccFileName;
            console.log($scope.ProcessInvoice)
            BaseHTTPService.httpPost(Constants.POST_PROCESS_INVOICE, $scope.ProcessInvoice)
            .then(function successCallback(response) {
                $scope.processInvoiceResponseData = response.data;
                //alert msg from PD if any
                if (typeof ($scope.processInvoiceResponseData) == "string") {
                    alert($scope.processInvoiceResponseData);
                    $scope.notClicked = false;
                    $state.reload();
                }
                    //checking for unknown devices if any
                else if ($scope.processInvoiceResponseData[0].hasOwnProperty("Product_Number")) {
                    $scope.invoiceUnknownDevices = $scope.processInvoiceResponseData;
                    angular.forEach($scope.invoiceUnknownDevices, function (device) {
                        device.Minimum = "";
                        device.Maximum = "";
                        device.MultiFunctionDevice = false;
                        device.SupportsColorPrints = false;
                        device.Supprots11x17Prints = false;
                    })
                    //disabling usage tab in unknown devices screen
                    $scope.invoice_inputs = false;
                    $scope.invoice_unknown_devices = true;
                    $("#usageReportTab").hide();
                    //$("#usageReportTab").removeAttr("data-toggle").attr("disabled", "disabled");
                }
                else {
                    getDataRange();
                    dataService.setMyData($scope.processInvoiceResponseData);
                }
            },
            function errorCallback(response) {
                console.log("process invoice data error")
            });
        }
    }
    var getDataRange = function () {
        var param = {
            "PDFileName": $rootScope.fileused.UserAccFileName
        };
        BaseHTTPService.httpPost(Constants.POST_AVAILABLE_DATA, param)
            .then(function successCallback(response) {
                $rootScope.invoiceUsageNavData = JSON.parse('{' + (response.data) + '}');
                $state.go('main.ProcessInvoiceTable');
         });
    }
    //deleting unknown device row
    $scope.removeRow = function (index) {
        $scope.invoiceUnknownDevices.splice(index, 1);
    };
    //save unknown invoice devices
    $scope.saveInvoiceDevice = function () {
        $scope.savedInvoiceDevicesList = [];
        $scope.invoiceUnknownDevices.forEach(function (device) {
            $scope.savedInvoiceDevicesList.push(device);
        });
        $scope.ProcessInvoice.PDFileName = $rootScope.fileused.UserAccFileName;
        $scope.ProcessInvoice.UnknownDevices = $scope.savedInvoiceDevicesList;
        $scope.ProcessInvoice.InputFileName = $scope.selectedSheet.InputFileName;
        BaseHTTPService.httpPost(Constants.POST_UPDATE_DEVICE, $scope.ProcessInvoice)
            .then(function successCallback(response) {
                $scope.processInvoiceResponseData = response.data;
                $scope.notClicked = false;
                if (typeof ($scope.processInvoiceResponseData) == "string" && $scope.processInvoiceResponseData.search("[a-zA-Z]")) {
                    alert($scope.processInvoiceResponseData);
                    $state.reload();
                }
                else {
                    getDataRange();
                    dataService.setMyData($scope.processInvoiceResponseData);

                }
            },
            function errorCallback(response) {
                console.log("update invoice unknown device error")
            });
    }
    //Skip All Unknown devices
    $scope.skipAllInvoiceDevice = function () {
        $scope.savedInvoiceDevicesList = [];
        $scope.invoiceUnknownDevices.forEach(function (device) {
            $scope.savedInvoiceDevicesList.push(device);
        });
        $scope.ProcessInvoice.PDFileName = $rootScope.fileused.UserAccFileName;
        $scope.ProcessInvoice.UnknownDevices = $scope.savedInvoiceDevicesList;
        $scope.ProcessInvoice.InputFileName = $scope.selectedSheet.InputFileName;
        BaseHTTPService.httpPost(Constants.POST_SKIP_ALL_DEVICE, $scope.ProcessInvoice)
            .then(function successCallback(response) {
                $scope.skipAllResponse = response.data;
                $scope.notClicked = false;
                if (typeof ($scope.skipAllResponse) == "string" && $scope.skipAllResponse.search("[a-zA-Z]")) {
                    alert($scope.skipAllResponse);
                    $state.reload();
                }
                else {
                    getDataRange();
                    dataService.setMyData($scope.skipAllResponse);

                }
            },
            function errorCallback(response) {
                console.log("skip all invoice unknown devices error")
            });
    }
    //Abort the process which skip the uploaded file
    $scope.abortInvoiceDevice = function () {
        var param = {
            "PDFileName": $rootScope.fileused.UserAccFileName
        };
        param.InputFileName = $scope.selectedSheet.InputFileName;
        BaseHTTPService.httpPost(Constants.POST_ABORT_INVOICE_PROCESS, param)
            .then(function successCallback(response) {
                $scope.abortResponse = response.data;
                $scope.notClicked = false;
                getDataRange();
                dataService.setMyData($scope.abortResponse);

            },
            function errorCallback(response) {
                console.log("Abort invoice unknown devices error")
            });
    }
    //On navigating to other URL from Unknown devices
    $scope.$on("$stateChangeStart", function (event) {
        if ($scope.invoice_unknown_devices && $scope.notClicked && confirm('Please click on Update/Skip All/Abort button to Process the uploaded invoice file or "Cancel" to skip this file'))
            event.preventDefault();
    });
    var self = this;
    //Showing currency view click on button
    $scope.showCurrencyModal = function (curInfo) {
        //var curdate = {'DateTime':curInfo};
        var currencyParam = {};
        angular.merge(currencyParam, shareUser.get());
        var modalInstance = $uibModal.open({
            templateUrl: 'public/templates/modal/currency-conversion.html',
            controller: 'currencyConversionController',
            controllerAs: 'curConvertCtrl',
            resolve: {
                currencyParam: function () {
                    return currencyParam || {};
                }
            }
        });
    }
    //Updating currency while click on Update Curency button
    $scope.updateCurrencyModal = function (updateCur) {
        var updateCurrency = $filter('date')(updateCur, "MM/dd/yyyy");
        var curdate = { 'DateTime': updateCurrency };
        var UpdatecurrencyParam = {};
        angular.merge(UpdatecurrencyParam, curdate, shareUser.get());
        $http({
            method: 'POST',
            url: Constants.POST_CURRENCY_CONVERSATION_UPDATE,
            data: UpdatecurrencyParam
        }).then(function successCallback(response) {
            //console.log(response);
            //self.currencyConversionData = JSON.parse(response.data);
        });
    }
})
    .controller('currencyConversionController', ['$scope', '$http', '$uibModal', 'Constants', 'currencyParam',
        function ($scope, $http, $modal, Constants, currencyParam) {
            var self = this;
            //Currency Conversion Model Starts 
            $http({
                method: 'POST',
                url: Constants.POST_CURRENCY_CONVERSATION_VIEW,
                data: currencyParam
            }).then(function successCallback(response) {
                console.log(response);
                self.currencyConversionData = JSON.parse(response.data);
            });

            self.currencyConversionDatastatic = [
                {
                    "CurrencyCode": "CAD",
                    "CurrencyUnit": "Canadian Dollar",
                    "UnitsPerCAD": 1,
                    "CADsperUnit": 1
                },
                {
                    "CurrencyCode": "USD",
                    "CurrencyUnit": "US Dollar",
                    "UnitsPerCAD": 0.764564,
                    "CADsperUnit": 1.3145646
                },
                {
                    "CurrencyCode": "EUR",
                    "CurrencyUnit": "EURO",
                    "UnitsPerCAD": 0.7145564,
                    "CADsperUnit": 1.464654
                },
                {
                    "CurrencyCode": "CAD",
                    "CurrencyUnit": "Canadian Dollar",
                    "UnitsPerCAD": 1,
                    "CADsperUnit": 1
                },
                {
                    "CurrencyCode": "GBP",
                    "CurrencyUnit": "British Pound",
                    "UnitsPerCAD": 0.6145664,
                    "CADsperUnit": 1.625646
                }
            ]
        }])

.controller('invoiceUsageController', function ($scope) {
    $scope.invoiceTab = {
        isSelected: true
    }
});