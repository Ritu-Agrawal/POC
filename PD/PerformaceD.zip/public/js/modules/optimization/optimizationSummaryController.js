angular.module('SBRUI.SBR2ndPhase')     
    .filter("checkForGainOrLoss", function () { 
        return function (input) {
            if (input < 0) { 
                return Math.abs(input);
            } else {
                return input;
            }
        }
    })
     .factory('optimizeServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
         var optimizeServices = {
             postOptimizeData: function (optparam) { 
                 return BaseHTTPService.httpPost(Constants.POST_OPTIMIZ_DATA, optparam, true)
                 .then(this.handleSuccess, this.handleError('Error while getting optimize details'));
             },
             handleSuccess: function (response) {
                 return response;
             },
             handleError: function (error) {
                 return function () {
                     console.log(error);
                     return { success: false, message: error };
                 };
             }
         }
         return optimizeServices;
     }])
    .factory('defaultSettingsContinue', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
        var defaultSettingsContinue = {
            postDefaultSettingsData: function (PowerConsumptionSettings) {              
                return BaseHTTPService.httpPost(Constants.POST_POWER_CONSUMPTION_SETTINGS_DATA, PowerConsumptionSettings, true)
                .then(this.handleSuccess, this.handleError('Error while getting optimize details'));
            },
            OSGetDefaultSettingsData: function (PowerConsumptionSettings) {
                return BaseHTTPService.httpPost(Constants.POST_GET_DEFAULT_SETTINGS, PowerConsumptionSettings, true)
                .then(this.handleSuccess, this.handleError('Error while getting optimize details'));
            },
            handleSuccess: function (response) {
                return response;
            },
            handleError: function (error) {
                return function () {
                    console.log(error);
                    return { success: false, message: error };
                };
            }
        }
        return defaultSettingsContinue;
    }])
    .directive('numberOnly', function () {
        return {
            require: 'ngModel',
            link: function (scope, element, attr, ngModelCtrl) {
                function fromUser(text) {
                    if (text) {
                        var transformedInput = text.replace(/[^0-9.]/g, '');

                        if (transformedInput !== text) {
                            ngModelCtrl.$setViewValue(transformedInput);
                            ngModelCtrl.$render();
                        }
                        return transformedInput;
                    }
                    return undefined;
                }
                ngModelCtrl.$parsers.push(fromUser);
            }
        };
    })
    .controller('optimizationSummaryController', ['$scope', '$rootScope', '$http', '$uibModal', 'optimizeServices', 'shareUser', function ($scope, $rootScope, $http, $modal, optimizeServices, shareUser) {
        var self = this;
        self.poerConsCount = 0;
        self.defaultSettingBtn = true;
        /**
         * Calling API to load total Optimization Data by load the page itself
         */
        optimizeServices.postOptimizeData(shareUser.get()).then(function (response) {
             console.log(response);
             $rootScope.optimizeData = response;
             $rootScope.currentCustomerFleet = $rootScope.optimizeData.data.CurrentCustomer;
             $rootScope.proposedCustomerFleet = $rootScope.optimizeData.data.ProposedCustomer;
             $rootScope.customerFleetCostSummary = $rootScope.optimizeData.data.CostSummary;
             $rootScope.HPRevenueSummary = $rootScope.optimizeData.data.RevenueSummary;
             $rootScope.proposedFleetDeviceGroupSummary = $rootScope.optimizeData.data.GroupSummary;
             $rootScope.companyName = $rootScope.optimizeData.data.CompanyName[0].CompanyName;
             $rootScope.optCurrency = $rootScope.optimizeData.data.Currency[0].Currency;
        });
        /**
         * Enabling Default Setting button
         */
        self.poweConsumtionTab = function () {
            self.poerConsCount ++;
            if (self.poerConsCount > 0) {
                self.defaultSettingBtn = false;
            }
        }
        /**
         * Opening Default Setting modal popup 
         */
        self.defaultSettingsModal = function () {
            var modalInstance = $modal.open({
                templateUrl: 'public/templates/modal/default-settings.html',
                controller: "OSDefaultSettingsController",
                controllerAs: "defaultSetingCtrl",
                backdrop: 'static',
                keyboard: false             
            });
        }
    }])
    .controller('OSDefaultSettingsController', ['$scope', '$http', '$rootScope', '$uibModalInstance', 'defaultSettingsContinue', 'shareUser', 'Constants',
        function ($scope, $http, $rootScope, $uibModalInstance, defaultSettingsContinue, shareUser, Constants) {
        var self = this;   
        //self.defaultSettingDigit = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24];
        self.defaultSettingDigit = [{ "item": 1, id: 1 }, { "item": 2, id: 2 }, { "item": 3, id: 3 }, { "item": 4, id: 4 }, { "item": 5, id: 5 }, { "item": 6, id: 6 }, { "item": 7, id: 7 }, { "item": 8, id: 8 }, { "item": 9, id: 9 }, { "item": 10, id: 10 }, { "item": 11, id: 11 }, { "item": 12, id: 12 }, { "item": 13, id: 13 }, { "item": 14, id: 14 }, { "item": 15, id: 15 }, { "item": 16, id: 16 }, { "item": 17, id: 17 }, { "item": 18, id: 18 }, { "item": 19, id: 19 }, { "item": 20, id: 20 }, { "item": 21, id: 21 }, { "item": 22, id: 22 }, { "item": 23, id: 23 }, { "item": 24, id: 24 }];
        self.defaultHours = self.defaultSettingDigit[8].item;
        self.defaultDays = self.defaultSettingDigit[20].item;
        self.defaultPowerCost = 0.12;
        /**
         * Getting values of hour, days and power cost if these values are exsited
         */ 
        self.DSParam = shareUser.get();

        defaultSettingsContinue.OSGetDefaultSettingsData(self.DSParam).then(function (response) {
            console.log(response); 
            if (response.data.length > 0) {
                self.defaultHours = response.data[0].HoursPerDay;
                self.defaultDays = response.data[0].DaysPerMonth;
                self.defaultPowerCost = response.data[0].PowerCost;
            }
        });
        //$http({
        //    method: 'POST',
        //    url: Constants.POST_GET_DEFAULT_SETTINGS,
        //    data: self.DSParam
        //}).then(function successCallback(response) {
        //    console.log(response);
        //    if (response.data.length > 0) {
        //        self.defaultHours = response.data[0].HoursPerDay;
        //        self.defaultDays = response.data[0].DaysPerMonth;
        //        self.defaultPowerCost = response.data[0].PowerCost;
        //    }
        //    //else {
        //    //    self.defaultHours = self.defaultSettingDigit[8];
        //    //    self.defaultDays = self.defaultSettingDigit[20];
        //    //    self.defaultPowerCost = 0.12;
        //    //}
        //}, function errorCallback(response) {
        //    console.log(response);
        //});
        //Closing modal
        self.closeOSDefSetModal = function () {
            $uibModalInstance.dismiss('cancel');
        };
        /**
         * When Click on Continue button Sending Details to Backend
         */
        self.defaultSettingsContinue = function () {
            $uibModalInstance.dismiss('cancel');
            var PowerConsumptionSettings = {}; 
            PowerConsumptionSettings.HoursOfOperationDay = self.defaultHours;
            PowerConsumptionSettings.AverageWorkingDaysMonth = self.defaultDays;
            PowerConsumptionSettings.LocalPowerCostkwh = self.defaultPowerCost;
            console.log(PowerConsumptionSettings);
            angular.merge(PowerConsumptionSettings, shareUser.get());
            defaultSettingsContinue.postDefaultSettingsData(PowerConsumptionSettings).then(function (response) {
                console.log(response);
                $rootScope.optimizeData = response;
                $rootScope.currentCustomerFleet = $rootScope.optimizeData.data.CurrentCustomer;
                $rootScope.proposedCustomerFleet = $rootScope.optimizeData.data.ProposedCustomer;
                $rootScope.customerFleetCostSummary = $rootScope.optimizeData.data.CostSummary;
                $rootScope.HPRevenueSummary = $rootScope.optimizeData.data.RevenueSummary;
                $rootScope.proposedFleetDeviceGroupSummary = $rootScope.optimizeData.data.GroupSummary;
                $rootScope.companyName = $rootScope.optimizeData.data.CompanyName[0].CompanyName;
                $rootScope.currency = $rootScope.optimizeData.data.Currency[0].Currency;
            });
        }
    }]);