﻿// Code goes here
angular.module('SBRUI.SBR2ndPhase')
  .factory('performanceDashboardServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
      var performanceDashboardServices = {
          postPDInfoData: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_INFO_DATA, param, true)
                .then(this.handleSuccess, this.handleError('Error while getting PD details'));
          },
          postPDDataSave: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_DATA_SAVE, param, true)
                .then(this.handleSuccess, this.handleError('Error while saving PD details'));
          },
          postPDUpdateView: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_UPDATE_VIEW, param, true)
                .then(this.handleSuccess, this.handleError('Error while change slider view'));
          },
          postPDUpdateServiceScrubber: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_SERVICE_SCRUBBER, param, true)
                .then(this.handleSuccess, this.handleError('Error while change Service scrubber'));
          },
          postPDClearServiceData: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_DELETE_SERVICE_DATA, param, true)
                .then(this.handleSuccess, this.handleError('Error while change Service scrubber'));
          },
          postPDSelectRangeData: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_SELECT_RANGE_DATA, param, true)
                .then(this.handleSuccess, this.handleError('Error while change Service scrubber'));
          },
          postPDResetRangeData: function (param) {
              return BaseHTTPService.httpPost(Constants.POST_PD_RESET_RANGE_DATA, param, true)
                .then(this.handleSuccess, this.handleError('Error while change Service scrubber'));
          },
          handleSuccess: function (response) {
              return response;
          },
          handleError: function (error) {
              return function () {
                  console.log(error);
                  return {
                      success: false,
                      message: error
                  };
              };
          }
      };
      return performanceDashboardServices;
  }])
    .factory('marketVerticalServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
        var marketVerticalServices = {
            mvfstModalGetData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_GET_MARKET_VERTICAL_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            mvExportModalGetData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_GET_MARKET_VERTICAL_CATEGORY_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            mvExportModalPostSelectedData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_EXPORT_MARKET_VERTICAL_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            mvImportModalGetTableData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_UPDATE_EXPORT_MV_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            mvImportModalGetTableDataLoad: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_MARKET_VERTICAL_IMPORT_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },
            mvCreateSBRModalPostData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_CREATE_SBR_REPORT, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            },

            handleSuccess: function (response) {
                return response;
            },
            handleError: function (error) {
                return function () {
                    console.log(error);
                    return {
                        success: false,
                        message: error
                    };
                };
            }
        };
        return marketVerticalServices;
    }])
  .factory('marketVerticalAverage', ['$http', function ($http) {
      var marketVerticalAverage = {};
      return {
          set: function (data) {
              marketVerticalAverage = data;
          },
          get: function (data) {
              return marketVerticalAverage;
          }
      };
  }])
.controller('performanceDashboardController', ['$scope', '$rootScope', '$filter', '$http', '$uibModal', '$timeout', 'performanceDashboardServices', 'shareUser', 'marketVerticalAverage', '$window', '$anchorScroll',
    function ($scope, $rootScope, $filter, $http, $modal, $timeout, performanceDashboardServices, shareUser, marketVerticalAverage, $window, $anchorScroll) {
        var self = this;
        $scope.scrollTo = function (id) {
            console.log($window);
            $scope.showTopButton = false;
            $anchorScroll(id);
            if ($window.scrollY > 125) {
                $scope.showTopButton = true;
            }
        }
        $scope.$watch(function () {
            return $window.scrollY;
        }, function (scrollY) {
            $scope.showTopButton = false;
            if (scrollY > 125) {
                $scope.showTopButton = true;
            }
        });
        /* DEFAULT CHECKBOX SELECTION*/
        self.displaySection = [true, false, false, false, false, false, false, false, false, false, false, false, false];
        self.evntChk = true;
        self.selected1 = '';
        self.selected2 = '';
        self.setSelected = false;
        self.pageLoad = true;
        self.disableSBR = true;
        var customTooltips = function (tooltip) {
            // Tooltip Element
            var tooltipEl = document.getElementById('chartjs-tooltip');

            if (!tooltipEl) {
                tooltipEl = document.createElement('div');
                tooltipEl.id = 'chartjs-tooltip';
                tooltipEl.innerHTML = "<table></table>"
                this._chart.canvas.parentNode.appendChild(tooltipEl);
            }

            // Hide if no tooltip
            if (tooltip.opacity === 0) {
                tooltipEl.style.opacity = 0;
                return;
            }

            // Set caret Position
            tooltipEl.classList.remove('above', 'below', 'no-transform');
            if (tooltip.yAlign) {
                tooltipEl.classList.add(tooltip.yAlign);
            } else {
                tooltipEl.classList.add('no-transform');
            }

            function getBody(bodyItem) {
                return bodyItem.lines;
            }

            // Set Text
            if (tooltip.body) {
                console.log(tooltip);
                var title = tooltip.title[0];
                var bodyLines = tooltip.body.map(getBody);
                var body = bodyLines[0][0].split(":");
                var innerHtml = '<tbody>';

                innerHtml += '<tr><td nowrap> Series "' + body[0] + '" Point "' + title + '"</td></tr>';
                innerHtml += '<tr><td nowrap> value: ' + body[1] + '</td></tr>';
                innerHtml += '</tbody>';

                var tableRoot = tooltipEl.querySelector('table');
                tableRoot.innerHTML = innerHtml;
            }
            var positionY = this._chart.canvas.offsetTop;
            var positionX = this._chart.canvas.offsetLeft;

            // Display, position, and set styles for font
            tooltipEl.style.opacity = 1;
            tooltipEl.style.left = positionX + tooltip.caretX + 'px';
            tooltipEl.style.top = positionY + tooltip.caretY + 'px';
            //tooltipEl.style.fontFamily = tooltip.fontFamily;
            tooltipEl.style.fontSize = '12px';
            tooltipEl.style.fontStyle = tooltip._fontStyle;
            tooltipEl.style.padding = tooltip.yPadding + 'px ' + tooltip.xPadding + 'px';
        };
        /* ----------------------------------------------- */
        /* CHECKBOX SELECTION FOR DISPLAY SECTIONS */
        /* ----------------------------------------------- */
        self.displayTables = function (ID, value) {
            self.tableInfo[ID].enable = value;
            self.displaySection[ID] = value;
            //self.highlightTable();
        };
        self.selectAll = function () {
            angular.forEach(self.tableInfo, function (value, key) {
                self.tableInfo[key].enable = true;
                self.displaySection[key] = true;
            });
            //self.highlightTable();
        };
        self.deSelectAll = function () {
            angular.forEach(self.tableInfo, function (value, key) {
                self.tableInfo[key].enable = false;
                self.displaySection[key] = false;
            });
        };

        self.SBRData = [];
        var displayGraphs = function (displayRangeEnable) {
            self.disableSBR = true;
            self.dataCUpie = [];
            self.CUDataStacked = [];
            self.averageDataBar = [];
            self.dataDCpie = [];
            self.graphMonthDataDC = [];
            self.dataDCMonoPrint = [];
            self.dataDCColorPrint = [];
            self.dataDCMonoMFP = [];
            self.dataDCColorMFP = [];
            self.dataDCHorizontalBar = [];
            self.dataDUHorizontalBar = [];
            self.dataCDpie1 = [];
            self.dataCDpie2 = [];
            self.dataDUpie = [];
            self.dataSLpie = [];
            self.valueSLarr = [];
            self.dataColorUsageCD = [];
            self.dataMonoUsageMD = [];
            self.dataDuplexDU = [];
            self.NIDDataBar = [];
            self.currentAvgArrDU = [];
            self.NRDMonthDataBar = [];
            self.NRDExceptionsDataBar = [];
            self.DeviceTrackingDataBar = [];
            self.totalPrintersCU = 0;
            self.totalDeviceDC = 0;
            var monototalCountDC = 0;
            var colortotalCountDC = 0;
            var monoMFPtotalCountDC = 0;
            var colorMFPtotalCountDC = 0;
            self.labelstrack = [];
            self.marketVerticalCU = {};
            self.marketVerticalDC = [];
            var showColorSummary = false;
            var showMonoSummary = false;
            var showDuplexSummary = false;
            self.showDuplexSummaryTable = false;
            self.showViewSummary = false;
            self.dplChk = "1";
            self.valueT283 = 0;
            self.valueTU103 = 0;
            self.reducedColorPrint = 0;
            self.reducedMonoColorPrint = 0;
            self.incDuplexPrint = 0;
            self.colorAvgArrCU = [];
            self.estimatedSavingXAxisCU = [];
            self.colorPageSlopeCU = [];
            self.extSaveSlopeCU = [];
            self.savingTarget = [];
            var U73 = 0;
            var U74 = 0;
            var U74org = 0;
            var U75 = 0;
            var U79 = 0;
            var T74 = 0;
            var xAxisZero = 0;
            var xAxisZeroMono = 0;
            var xAxisZeroDuplex = 0;
            var U90 = 0;
            var U94 = 0
            var T90 = 0;
            var U88 = 0;
            var U103 = 0;
            var U104 = 0;
            var T104 = 0;
            var U107 = 0;
            self.estimatedSavingXAxisMono = [];
            self.monoPageSlopeMPoCD = [];
            self.extSaveSlopeMPoCD = [];
            self.savingTargetMPoCD = [];
            self.estimatedSavingXAxisDuplex = [];
            self.duplexSlopeDuplex = [];
            self.extSaveSlopeDuplex = [];
            self.savingTargetDuplex = [];
            self.performanceUpTargetArr = [];
            self.SLAMetTagetArr = [];
            for (var i = 0; i < self.range1.length; i++)
                self.labelstrack.push(self.range1[i].MonthYear);
            if (self.selected1 !== '' && self.selected2 !== '') {
                self.startSelection = parseInt(self.selected1);
                self.endSelection = parseInt(self.selected2);
                self.startSBRrange = self.range1[self.startSelection].MonthYear;
                self.endSBRrange = self.range1[self.endSelection].MonthYear;
                self.graphMonth = self.endSelection;
            }
            else {
                self.startSelection = parseInt(self.sliderRange);
                self.startSBRrange = self.range1[self.startSelection + 1].MonthYear;
                self.endSBRrange = self.range1[self.startSelection + 1].MonthYear;
                self.graphMonth = self.startSelection;
                for (var i = parseInt(self.sliderRange) + 1; i < self.displayRange; i++) {
                    if (self.startSBRrange === '')
                        self.startSBRrange = self.range1[i + 1].MonthYear;
                    if (self.range1[i] !== undefined && self.range1[i].MonthYear !== '' && self.range1[i].MonthYear.indexOf("-") !== -1) {
                        self.graphMonth = i;
                        self.endSBRrange = self.range1[i].MonthYear;
                        self.endSelection = i + 1;
                    }
                }
            }
            self.SBRData.StartMonth = self.startSBRrange;
            self.SBRData.EndMonth = self.endSBRrange;
            var expression = "[" + self.currSymbol + ",%]";
            var rx = new RegExp(expression, 'g');
            angular.forEach(self.JSONData, function (tableInfo, key) {
                angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                    var monthTotal = 0;
                    var count = 0;
                    tabInfo.summaryData = [];
                    /* TOTAL COST OF OWNERSHIP RIGHT SECTION DATA */
                    if (tableInfo.RowHeader.toLowerCase() == 'Total Cost Of Ownership'.toLowerCase()) {
                        if (tabInfo.summary !== undefined)
                            var summaryArr = tabInfo.summary.split(";");
                        if (self.disableSBR) {
                            if (tabInfo.RowName === "Baseline (Blended CPP prior to HP Fleet)" || tabInfo.RowName === "Blended Cost Per Page (All Devices)" || tabInfo.RowName === "Blended Cost Per Page (Mono)" || tabInfo.RowName === "Blended Cost Per Page (Color)") {
                                var temp = summaryArr[2];
                                if (temp.replace(rx, '') !== '' && parseInt(temp.replace(rx, '')) !== 0) {
                                    self.disableSBR = false;
                                }
                            }
                        }
                        /* SET RIGHT SIDE DATA*/
                        tabInfo.summaryData.push({
                            "rowValue": (tabInfo.RowName !== 'Estimated Savings Delta') ? summaryArr[0].replace(rx, '') : summaryArr[1].replace(rx, ''),
                            "editable": false,
                            "class": (tabInfo.RowName === "Baseline (Blended CPP prior to HP Fleet)" || tabInfo.RowName === "TCO Percentage of Improvement" || tabInfo.RowName === "Blended Cost Per Page (All Devices)" || tabInfo.RowName === "Blended Cost Per Page (Mono)" || tabInfo.RowName === "Blended Cost Per Page (Color)") ? true : false,
                            "colspan": (tabInfo.RowName !== 'Estimated Savings Delta') ? 0 : 3,
                            "title": (tabInfo.RowName !== 'Estimated Savings Delta') ? '' : "Estimated Savings for the viewed range.",
                            "dataFormat": tabInfo.dataFormat
                        })
                        if (tabInfo.RowName !== 'Estimated Savings Delta') {
                            tabInfo.summaryData.push({
                                "rowValue": (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, ''),
                                "editable": false,
                                "dataFormat": tabInfo.dataFormat
                            })
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[2].replace(rx, ''),
                                "editable": false,
                                "class": (tabInfo.RowName !== "Baseline (Blended CPP prior to HP Fleet)" && tabInfo.RowName !== "Blended Cost Per Page (All Devices)" && tabInfo.RowName !== "Blended Cost Per Page (Mono)" && tabInfo.RowName !== "Blended Cost Per Page (Color)") ? true : false,
                                "dataFormat": tabInfo.dataFormat
                            })
                        }
                    }
                        /* CAPACITIES & UTILIZATION RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() == 'Capacities & Utilization'.toLowerCase()) {
                        /* SET RIGHT SIDE DATA*/
                        if (tabInfo.summary !== undefined)
                            var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');
                        if (self.disableSBR) {
                            if (tabInfo.RowName === "Mono Printers Utilization Percentage" || tabInfo.RowName === "Color Printers Utilization Percentage" || tabInfo.RowName === "Mono MFP Utilization Percentage" || tabInfo.RowName === "Color MFP Utilization Percentage" || tabInfo.RowName === "Fleet Target Volume (Pages)" || tabInfo.RowName === "Pages Printed on Mono MFPs") {
                                var temp = summaryArr[2];
                                if (temp !== '' && temp !== 0) {
                                    self.disableSBR = false;
                                }
                            }
                        }
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[0],
                            "editable": (tabInfo.RowName.trim() === "Reported Fleet Volume (Pages)" || tabInfo.RowName.trim() === "Additional Mono Volume (From NRDs)" || tabInfo.RowName.trim() === "Additional Color Volume (From NRDs)" || tabInfo.RowName.trim() === "Total Fleet Volume (Pages)" || tabInfo.RowName.trim() === "Fleet Target Volume (Pages)" || tabInfo.RowName.trim() === "Average Pages Per Device") ? false : true,
                            "class": (tabInfo.RowName.trim() === "Reported Fleet Volume (Pages)" || tabInfo.RowName.trim() === "Additional Mono Volume (From NRDs)" || tabInfo.RowName.trim() === "Additional Color Volume (From NRDs)" || tabInfo.RowName.trim() === "Total Fleet Volume (Pages)" || tabInfo.RowName.trim() === "Fleet Target Volume (Pages)" || tabInfo.RowName.trim() === "Average Pages Per Device") ? true : false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[1],
                            "editable": false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[2],
                            "editable": false,
                            "class": (tabInfo.RowName.trim() === "Reported Fleet Volume (Pages)" || tabInfo.RowName.trim() === "Additional Mono Volume (From NRDs)" || tabInfo.RowName.trim() === "Additional Color Volume (From NRDs)") ? true : false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        /* CALCULATE DATA TO DISPLAY IN GRAPH */
                        if (tabInfo.RowName === 'Pages Printed on Mono Printers') {
                            self.monoPrintCU = parseFloat(summaryArr[1] * 1);
                            self.totalPrintersCU += self.monoPrintCU;
                        } else if (tabInfo.RowName === 'Pages Printed on Color Printers') {
                            self.colorPrintCU = parseFloat(summaryArr[1] * 1);
                            self.totalPrintersCU += self.colorPrintCU;
                        } else if (tabInfo.RowName === 'Pages Printed on Mono MFPs') {
                            self.monoMFPCU = parseFloat(summaryArr[1] * 1);
                            self.totalPrintersCU += self.monoMFPCU;
                        } else if (tabInfo.RowName === 'Pages Printed on Color MFPs') {
                            self.colorMFPCU = parseFloat(summaryArr[1] * 1);
                            self.totalPrintersCU += self.colorMFPCU;
                        } else if (tabInfo.RowName === "Under Utilized Device Percentage") {
                            self.UDPCU = parseFloat(summaryArr[1] * 1);
                        } else if (tabInfo.RowName === "Over Utilized Device Percentage") {
                            self.ODPCU = parseFloat(summaryArr[1] * 1);
                        } else if (tabInfo.RowName === "Fleet Utilization Percentage") {
                            self.fleetUtilCU = parseFloat(summaryArr[1] * 1) * 100;
                            self.marketVerticalCU.fleetUtilCU = parseFloat(summaryArr[2] * 1) * 100;
                        } else if (tabInfo.RowName === "Mono Printers Utilization Percentage") {
                            self.monoPrintPCU = parseFloat(summaryArr[1] * 1) * 100;
                            self.marketVerticalCU.monoPrintPCU = parseFloat(summaryArr[2] * 1) * 100;
                        } else if (tabInfo.RowName === "Color Printers Utilization Percentage") {
                            self.colorPrintPCU = parseFloat(summaryArr[1] * 1) * 100;
                            self.marketVerticalCU.colorPrintPCU = parseFloat(summaryArr[2] * 1) * 100;
                        } else if (tabInfo.RowName === "Mono MFP Utilization Percentage") {
                            self.monoMFPPCU = parseFloat(summaryArr[1] * 1) * 100;
                            self.marketVerticalCU.monoMFPPCU = parseFloat(summaryArr[2] * 1) * 100;
                        } else if (tabInfo.RowName === "Color MFP Utilization Percentage") {
                            self.colorMFPPCU = parseFloat(summaryArr[1] * 1) * 100;
                            self.marketVerticalCU.colorMFPPCU = parseFloat(summaryArr[2] * 1) * 100;
                        }
                    }
                        /* DEVICE CATEGORY SUMMARY RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() == 'Device Category Summary'.toLowerCase()) {
                        self.graphMonthDataDC[tabInfo.RowID] = tabInfo.PDData[self.graphMonth].rowValue;
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        /* SET RIGHT SIDE DATA*/
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[0],
                            "editable": (tabInfo.RowName.trim() === "HP Devices" || tabInfo.RowName.trim() === "3rd Party Devices") ? false : true,
                            "class": (tabInfo.RowName.trim() === "HP Devices" || tabInfo.RowName.trim() === "3rd Party Devices") ? true : false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[1],
                            "editable": false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[2],
                            "editable": false,
                            "class": (tabInfo.RowName.trim() === "HP Devices" || tabInfo.RowName.trim() === "3rd Party Devices") ? true : false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        /* CALCULATE DATA TO DISPLAY IN GRAPH */
                        self.marketVerticalDC.push(summaryArr[2]);
                        if (tabInfo.RowName === 'Mono Printers (Total Count)') {
                            monototalCountDC = parseFloat(summaryArr[1] * 1);
                            self.totalDeviceDC = self.totalDeviceDC + monototalCountDC;
                        } else if (tabInfo.RowName === 'Color Printers (Total Count)') {
                            colortotalCountDC = parseFloat(summaryArr[1] * 1);
                            self.totalDeviceDC = self.totalDeviceDC + colortotalCountDC;
                        } else if (tabInfo.RowName === 'Color MFPs (Total Count)') {
                            colorMFPtotalCountDC = parseFloat(summaryArr[1] * 1);
                            self.totalDeviceDC = self.totalDeviceDC + colorMFPtotalCountDC;
                        } else if (tabInfo.RowName === 'Mono MFPs (Total Count)') {
                            monoMFPtotalCountDC = parseFloat(summaryArr[1] * 1);
                            self.totalDeviceDC = self.totalDeviceDC + monoMFPtotalCountDC;
                        }
                    }
                        /* COLOR USAGE RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() == 'Color Device Usage'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        if (tabInfo.RowName === 'Color Pages vs. Total Fleet Volume (%)') {
                            U74org = parseFloat(summaryArr[1] * 1);
                            var T74org = parseFloat(summaryArr[0] * 1);
                            U74 = parseFloat(summaryArr[1] * 100);
                            T74 = summaryArr[0] * 100;
                            if (summaryArr[0] !== '' && summaryArr[0] !== 0)
                                showColorSummary = true;
                            for (var i = 0; i < self.currUsageCUArr.length; i++)
                                self.colorAvgArrCU.push({
                                    x: i,
                                    y: U74
                                })
                            var cal = ((T74org - U74org.toFixed(2)) + 0.09) > 0 ? 0 : ((T74org - U74org.toFixed(2)) + 0.09); //Formula - MIN(0,(T74 - MROUND(U74,0.01) )+0.09)
                            //xAxisZero = parseFloat((T74org === 0) ? U74org : ((T74org > 0) ? (U74org.toFixed(2) + cal) : U74org));// formula - =IF(T74="",U74,IF(AND(T74>=0,ISNUMBER(T74)),MROUND(U74,0.01) + MIN(0,(T74 - MROUND(U74,0.01) )+0.09),U74))
                            if (T74org === "") {
                                xAxisZero = U74org
                            } else {
                                if (T74org >= 0 && !isNaN(T74org)) {
                                    xAxisZero = (parseFloat(U74org.toFixed(2)) + parseFloat(cal));
                                } else {
                                    xAxisZero = U74org
                                }
                            }
                        } else if (tabInfo.RowName === 'Total Color Pages') {
                            U73 = parseFloat(summaryArr[1] * 1);
                        } else if (tabInfo.RowName === 'Color Pages vs. TPoCD (%)') {
                            U75 = parseFloat(summaryArr[1]) * 100;
                        }
                        if (tabInfo.RowID === 77) {
                            summaryArr[0] = 'Color Page Count Change:';
                            tabInfo.dataFormat = 'noDecimal';
                        } else if (tabInfo.RowID === 78) {
                            summaryArr[0] = 'Color vs. Mono Cost Differece:';
                            U79 = summaryArr[1];
                            tabInfo.dataFormat = 'noDecimal';
                        } else if (tabInfo.RowID === 79) {
                            summaryArr[0] = 'Overall Potential Savings:';
                            self.reducedColorPrint = parseFloat(summaryArr[1] * 1);
                            tabInfo.dataFormat = 'noDecimal';
                        }
                        if (tabInfo.RowName.trim() == "" && showColorSummary)
                            tabInfo.summaryData.push({
                                "colspan": 11,
                                "noImg": true
                            })
                        if ((tabInfo.RowName.trim() === "" && showColorSummary) || tabInfo.RowName.trim() !== "")
                            tabInfo.summaryData.push({
                                "rowValue": (tabInfo.RowName.trim() === "Estimated Color Click Charges") ? 'Est. Charges:' : summaryArr[0],
                                "editable": (tabInfo.RowName.trim() === "Color Pages vs. Total Fleet Volume (%)") ? true : false,
                                "class": (tabInfo.RowName.trim() === "Average Color Click Charge") ? true : false,
                                "title": (tabInfo.RowName.trim() === "Estimated Color Click Charges") ? "Estimated Charges for the viewed range." : (tabInfo.RowName.trim() === "Color Pages vs. Total Fleet Volume (%)") ? 'Enter the proposed percentage to view the resulting data.' : '',
                                "dataFormat": (tabInfo.RowName.trim() === "Estimated Color Click Charges" || tabInfo.RowName.trim() === "") ? 'string' : tabInfo.dataFormat,
                                "colspan": (tabInfo.RowName.trim() === "" && showColorSummary) ? 3 : 0,
                            })
                        if ((tabInfo.RowName.trim() === "" && showColorSummary) || tabInfo.RowName.trim() !== "")
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[1],
                                "editable": false,
                                "colspan": (tabInfo.RowName.trim() === "Estimated Color Click Charges" || tabInfo.RowName.trim() === "") ? 2 : 0,
                                "dataFormat": tabInfo.dataFormat
                            })
                        if (tabInfo.RowName.trim() !== "Estimated Color Click Charges" && tabInfo.RowName.trim() !== "")
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[2],
                                "editable": false,
                                "class": (tabInfo.RowName.trim() === "Average Color Click Charge") ? true : false,
                                "dataFormat": tabInfo.dataFormat
                            })
                    }
                    else if (tableInfo.RowHeader.toLowerCase() == 'Mono Pages on Color Devices'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        if (tabInfo.RowName === 'Mono Pages on Color Devices (MPoCD)') {
                            U88 = parseFloat(summaryArr[1] * 1).toFixed(0);
                        } else if (tabInfo.RowName === 'Estimated Additional Expense') {
                            U94 = parseFloat(summaryArr[1] * 1);
                        } else if (tabInfo.RowName === 'MPoCD vs. Total Fleet Volume (%)') {
                            self.MPMonoTP = parseFloat(summaryArr[1] * 1) * 100;
                            if (summaryArr[0] !== '')
                                showMonoSummary = true;
                                
                            var T90Graph = parseFloat(summaryArr[0] * 1);
                            var U90Graph = parseFloat(summaryArr[1] * 1);
                            //ar cal = ((parseFloat(summaryArr[0] * 1) - parseFloat(summaryArr[1] * 1).toFixed(2)) + 0.04) > 0 ? 0 : ((parseFloat(summaryArr[0] * 1) - parseFloat(summaryArr[1] * 1).toFixed(2)) + 0.04)
                            //xAxisZeroMono = parseFloat((summaryArr[0] * 1 === 0) ? parseFloat(summaryArr[1] * 1) : ((parseFloat(summaryArr[0] * 1) > 0) ? (parseFloat(parseFloat(summaryArr[1] * 1).toFixed(2)) + cal) : parseFloat(summaryArr[1] * 1)));
                            var cal = (T90Graph - parseFloat(U90Graph.toFixed(2))) + 0.04
                            if (cal > 0) {
                                cal = 0;
                            }
                            if (summaryArr[0] === "") {
                                xAxisZeroMono = U90Graph
                            } else {
                                if (T90Graph >= 0 && !isNaN(T90Graph)) {
                                    xAxisZeroMono = (parseFloat(U90Graph.toFixed(2)) + parseFloat(cal));
                                } else {
                                    xAxisZeroMono = U90Graph
                                }
                            }
                            U90 = parseFloat(summaryArr[1] * 1).toFixed(3);
                            T90 = summaryArr[0] * 100;
                        }
                        if (tabInfo.RowID === 94) {
                            summaryArr[0] = 'Est. Expense at Target:';
                            tabInfo.dataFormat = 'noDecimal';
                        } else if (tabInfo.RowID === 95) {
                            summaryArr[0] = 'Overall Potential Savings:';
                            tabInfo.dataFormat = 'noDecimal';
                            self.reducedMonoColorPrint = parseFloat(summaryArr[1] * 1);
                        }
                        if (tabInfo.RowName.trim() == "" && showMonoSummary)
                            tabInfo.summaryData.push({
                                "colspan": 11,
                                "noImg": true
                            })
                        if ((tabInfo.RowName.trim() === "" && showMonoSummary) || tabInfo.RowName.trim() !== "")
                            tabInfo.summaryData.push({
                                "rowValue": (tabInfo.RowName.trim() === "Estimated Additional Expense") ? 'Est. Expense:' : summaryArr[0],
                                "editable": (tabInfo.RowName.trim() === "MPoCD vs. Total Fleet Volume (%)") ? true : false,
                                "class": (tabInfo.RowName.trim() === "Average Mono on Color Click Charge" || tabInfo.RowName.trim() === "Average Mono on Mono Click Charge" || tabInfo.RowName.trim() === "Average Mono Click Charge Differential") ? true : false,
                                "title": (tabInfo.RowName.trim() === "Estimated Additional Expense") ? "Estimated Expense for the viewed range." : (tabInfo.RowName.trim() === "MPoCD vs. Total Fleet Volume (%)") ? 'Enter the proposed percentage to view the resulting data.' : '',
                                "dataFormat": (tabInfo.RowName.trim() === "Estimated Additional Expense" || tabInfo.RowName.trim() === "") ? 'string' : tabInfo.dataFormat,
                                "colspan": (tabInfo.RowName.trim() === "" && showMonoSummary) ? 3 : 0,
                            })
                        if ((tabInfo.RowName.trim() === "" && showMonoSummary) || tabInfo.RowName.trim() !== "")
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[1],
                                "editable": false,
                                "colspan": (tabInfo.RowName.trim() === "Estimated Additional Expense" || tabInfo.RowName.trim() === "") ? 2 : 0,
                                "dataFormat": tabInfo.dataFormat
                            })
                        if (tabInfo.RowName.trim() !== "Estimated Additional Expense" && tabInfo.RowName.trim() !== "")
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[2],
                                "editable": false,
                                "class": (tabInfo.RowName.trim() === "Average Mono on Color Click Charge" || tabInfo.RowName.trim() === "Average Mono on Mono Click Charge" || tabInfo.RowName.trim() === "Average Mono Click Charge Differential") ? true : false,
                                "dataFormat": tabInfo.dataFormat
                            })
                    }
                    else if (tableInfo.RowHeader.toLowerCase() == 'Duplex Usage'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        if (tabInfo.RowName === 'Duplex Volume (Sheets)') {
                            self.valueTU103 = parseFloat(summaryArr[0].replace(/,/g, '') * 1) - parseFloat(summaryArr[1].replace(/,/g, '') * 1);
                            U103 = parseFloat(summaryArr[1] * 1).toFixed(3);
                        } else if (tabInfo.RowName === 'Duplex Percentage(Pages)') {
                            if (summaryArr[0] !== '') {
                                showDuplexSummary = true;
                                self.showDuplexSummaryTable = true;
                            }
                            for (var i = 0; i < self.currUsageCUArr.length; i++)
                                self.currentAvgArrDU.push({
                                    x: i,
                                    y: parseFloat(summaryArr[1] * 100)
                                })
                            self.dataDUpie.push({ value: "Simplex", y: parseFloat((100 - (summaryArr[0] !== '' ? parseFloat(summaryArr[0]) : 0))).toFixed(1), y1: (parseFloat((100 - (summaryArr[0] !== '' ? parseFloat(summaryArr[0]) : 0))) + parseFloat(parseFloat(summaryArr[1] * 1) * 100)) });
                            self.dataDUpie.push({ value: "Duplex", y: parseFloat(parseFloat(summaryArr[1] * 1) * 100).toFixed(1), y1: (parseFloat((100 - (summaryArr[0] !== '' ? parseFloat(summaryArr[0]) : 0))) + parseFloat(parseFloat(summaryArr[1] * 1) * 100)) });
                            var cal = (parseFloat(summaryArr[1]).toFixed(2) - (parseFloat(summaryArr[0] * 1) / 100).toFixed(2)) > 0 ? 0 : ((parseFloat(summaryArr[1]).toFixed(2) - (parseFloat(summaryArr[0]) / 100).toFixed(2)) + 0.09)
                            xAxisZeroDuplex = parseFloat((summaryArr[0] === '' || summaryArr[0] === 0) ? parseFloat(summaryArr[1]) : ((parseFloat(summaryArr[0]) > 0) ? (parseFloat((parseFloat(summaryArr[1])).toFixed(2)) - cal) : parseFloat(summaryArr[1])));
                            U104 = parseFloat(summaryArr[1] * 1).toFixed(3);
                            T104 = parseFloat(summaryArr[0] * 1);
                        } else if (tabInfo.RowName === 'Estimated Savings') {
                            U107 = parseFloat(summaryArr[1] * 1).toFixed(3);
                        }
                        if (tabInfo.RowID === 107) {
                            summaryArr[0] = 'Est. Savings at Target:';
                            tabInfo.dataFormat = 'noDecimal';
                        } else if (tabInfo.RowID === 108) {
                            summaryArr[0] = 'Est. Savings Difference:';
                            tabInfo.dataFormat = 'noDecimal';
                            self.incDuplexPrint = parseFloat(summaryArr[1].replace(/,/g, '') * 1);
                        }
                        if (self.disableSBR) {
                            if (tabInfo.RowName === "Duplex Volume (Sheets)" || tabInfo.RowName === "Duplex Percentage(Pages)" || tabInfo.RowName === "Paper Reduction Percentage(Sheets)" || tabInfo.RowName === "Paper Cost Multiplier (Cost of 1 Sheet)" || tabInfo.RowName === "Estimated Savings") {
                                var temp = summaryArr[2];
                                if (temp !== '' && parseInt(temp) !== 0) {
                                    self.disableSBR = false;
                                }
                            }
                        }
                        if (tabInfo.RowID !== 109) {
                            if (tabInfo.RowName.trim() == "" && showDuplexSummary)
                                tabInfo.summaryData.push({
                                    "colspan": 11,
                                    "noImg": true
                                })
                            if ((tabInfo.RowName.trim() === "" && showDuplexSummary) || tabInfo.RowName.trim() !== "")
                                tabInfo.summaryData.push({
                                    "rowValue": (tabInfo.RowName.trim() === "Estimated Savings") ? 'Est. Savings:' : summaryArr[0],
                                    "editable": (tabInfo.RowName.trim() === "Duplex Percentage(Pages)") ? true : false,
                                    "class": (tabInfo.RowName.trim() === "Paper Cost Multiplier (Cost of 1 Sheet)") ? true : false,
                                    "title": (tabInfo.RowName.trim() === "Estimated Savings") ? "Estimated Savings for the viewed range." : (tabInfo.RowName.trim() === "Duplex Percentage(Pages)") ? 'Enter the proposed percentage to view the resulting data.' : '',
                                    "dataFormat": (tabInfo.RowName.trim() === "Estimated Savings" || tabInfo.RowName.trim() === "") ? 'string' : tabInfo.dataFormat,
                                    "colspan": (tabInfo.RowName.trim() === "" && showDuplexSummary) ? 3 : 0,
                                })
                            if ((tabInfo.RowName.trim() === "" && showDuplexSummary) || tabInfo.RowName.trim() !== "")
                                tabInfo.summaryData.push({
                                    "rowValue": summaryArr[1],
                                    "editable": false,
                                    "colspan": (tabInfo.RowName.trim() === "Estimated Savings" || tabInfo.RowName.trim() === "") ? 2 : 0,
                                    "dataFormat": tabInfo.dataFormat,
                                    "class": false
                                })
                            if (tabInfo.RowName.trim() !== "Estimated Savings" && tabInfo.RowName.trim() !== "")
                                tabInfo.summaryData.push({
                                    "rowValue": summaryArr[2],
                                    "editable": (tabInfo.RowName.trim() === "Duplex Percentage(Pages)") ? true : false,
                                    "class": false,
                                    "dataFormat": tabInfo.dataFormat
                                })
                        }
                        tableInfo.duplexSummary = [];
                    }
                    else if (tableInfo.RowHeader.toLowerCase() == 'Service Level'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(",");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        if ([126, 127, 128, 129, 157, 165, 166].indexOf(tabInfo.RowID) === -1) {
                            if ([131, 132, 133, 134, 135, 136, 137, 138, 139, 140, 141, 142, 143, 144, 145, 146, 147, 148, 149, 150, 151, 152, 153, 154, 155, 156].indexOf(tabInfo.RowID) !== -1) {
                                if (isNaN(parseFloat(summaryArr[0])))
                                    self.valueSLarr.push(0);
                                else
                                    self.valueSLarr.push(summaryArr[0]);
                            } else if (tabInfo.RowName.trim() === "Performance Uptime %") {
                                for (var i = 0; i < self.performanceUpTArr.length; i++)
                                    self.performanceUpTargetArr.push({
                                        x: i,
                                        y: (summaryArr[0]) ? parseFloat(summaryArr[0] * 100).toFixed(2) : 0
                                    })
                            } else if (tabInfo.RowName.trim() === "Service Level Agreement MET") {
                                for (var i = 0; i < self.SLAMetArr.length; i++)
                                    self.SLAMetTagetArr.push({
                                        x: i,
                                        y: (summaryArr[0]) ? parseFloat(summaryArr[0] * 100).toFixed(2) : 0
                                    })
                            }

                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[0],
                                "editable": (tabInfo.RowName.trim() === "Performance Uptime %" || tabInfo.RowName.trim() === 'Service Level Agreement MET') ? true : false,
                                "colspan": (tabInfo.RowName !== 'Service Level Agreements (MISSED Count)') ? 0 : 3,
                                "class": tabInfo.RowName.trim() === 'Average "Call to Repair" Hours' ? true : false,
                                "dataFormat": tabInfo.dataFormat
                            })
                            if (tabInfo.RowName !== 'Service Level Agreements (MISSED Count)') {
                                tabInfo.summaryData.push({
                                    "rowValue": summaryArr[1],
                                    "editable": false,
                                    "class": false,
                                    "dataFormat": tabInfo.dataFormat
                                })
                                tabInfo.summaryData.push({
                                    "rowValue": summaryArr[2],
                                    "editable": false,
                                    "class": (tabInfo.RowName.trim() === "Performance Uptime %" || tabInfo.RowName.trim() === 'Average "Call to Repair" Hours' || tabInfo.RowName.trim() === 'Service Level Agreement MET' || tabInfo.RowName.trim() === 'Service Level Agreement MET') ? false : true,
                                    "dataFormat": tabInfo.dataFormat
                                })
                            }
                        }
                    }
                        /* TONER/INK TRACKING RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() === 'Toner/Ink Tracking'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[0],
                            "editable": (tabInfo.RowName.trim() === 'On Time Cartridge Replacement %') ? true : false,
                            "class": (tabInfo.RowName.trim() === 'On Time Cartridge Replacement %' || tabInfo.RowName.trim() === 'Total Estimated Wasted Toner Cost' || tabInfo.RowName.trim() === 'Total Cartridges Forecasted' || tabInfo.RowName.trim() === 'Cumulative Inventory Deviation' || tabInfo.RowName.trim() === 'Total Cartridges Returned' || tabInfo.RowName.trim() === 'Total Cartridges Ordered' || tabInfo.RowName.trim() === 'Total Cartridges Used') ? false : true,
                            "dataFormat": (tabInfo.RowName.trim() === 'On Time Cartridge Replacement %') ? 'percent' : 'customNumber',
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[1],
                            "editable": false,
                            "class": false,
                            "dataFormat": 'customNumberFloatOneDigit'
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[2],
                            "editable": false,
                            "class": true,
                            "dataFormat": 'customNumberFloatOneDigit'
                        })

                    }
                        /* OTHER CONSUMABLE TRACKING RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() === 'Other Consumable Tracking'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[0],
                            "editable": false,
                            "class": false,
                            "dataFormat": 'customNumber'
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[1],
                            "editable": false,
                            "class": false,
                            "dataFormat": 'customNumberFloatOneDigit'

                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[2],
                            "editable": false,
                            "class": true,
                            "dataFormat": 'customNumber'
                        })
                    }
                        /* DEVICE TRACKING & DEPLOYMENT RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() === 'Device Tracking & Deployment'.toLowerCase()) {
                        if ([248, 249].indexOf(tabInfo.RowID) === -1) {
                            var summaryArr = tabInfo.summary.split(";");
                            summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                            summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                            summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[0],
                                "editable": false,
                                "class": false,
                                "dataFormat": 'customNumber'
                            })
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[1],
                                "editable": false,
                                "class": false,
                                "dataFormat": 'customNumber'
                            })
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[2],
                                "editable": false,
                                "class": true,
                                "dataFormat": tabInfo.dataFormat
                            })
                        }
                    }
                        /* NRD RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() === 'NRD Summary'.toLowerCase()) {
                        if ([265, 266].indexOf(tabInfo.RowID) === -1) {
                            var summaryArr = tabInfo.summary.split(";");
                            summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                            summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                            summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');
                            if (self.disableSBR) {
                                if (tabInfo.RowName === "Non-Invoiced Devices Reporting %") {
                                    var temp = summaryArr[2];
                                    if (temp !== '' && temp !== 0) {
                                        self.disableSBR = false;
                                    }
                                }
                            }
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[0],
                                "editable": (tabInfo.RowName.trim() === "- Non-Networked Devices (Local)" || tabInfo.RowName.trim() === "- Devices in Storage") ? true : false,
                                "class": (tabInfo.RowName.trim() === "- Non-Networked Devices (Local)" || tabInfo.RowName.trim() === "- Devices in Storage") ? false : true,
                                "dataFormat": tabInfo.dataFormat
                            })
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[1],
                                "editable": false,
                                "dataFormat": tabInfo.dataFormat
                            })
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[2],
                                "editable": false,
                                "class": true,
                                "dataFormat": tabInfo.dataFormat
                            })
                        }
                    }
                        /* NID RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() === 'NID Summary'.toLowerCase()) {
                        if ([276, 277].indexOf(tabInfo.RowID) === -1) {
                            var summaryArr = tabInfo.summary.split(";");
                            summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                            summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                            summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');
                            if (self.disableSBR) {
                                if (tabInfo.RowName === "Non-Reporting Devices %") {
                                    var temp = summaryArr[2];
                                    if (temp !== '' && temp !== 0) {
                                        self.disableSBR = false;
                                    }
                                }
                            }
                            tabInfo.summaryData.push({
                                "rowValue": '',
                                "editable": false,
                                "class": true,
                                "dataFormat": tabInfo.dataFormat
                            })
                            tabInfo.summaryData.push({
                                "rowValue": summaryArr[1],
                                "editable": false,
                                "dataFormat": tabInfo.dataFormat
                            })
                            tabInfo.summaryData.push({
                                "rowValue": '',
                                "editable": false,
                                "class": true,
                                "dataFormat": tabInfo.dataFormat
                            })
                        }
                    }
                        /* INDUSTRY ANALYSIS DATA POINTS(RM REPORTED VALUES) RIGHT SECTION DATA */
                    else if (tableInfo.RowHeader.toLowerCase() == 'Industry Analysis Data Points(RM Reported Values)'.toLowerCase()) {
                        var summaryArr = tabInfo.summary.split(";");
                        summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                        summaryArr[1] = (summaryArr[1].indexOf('%') !== -1) ? summaryArr[1].replace(rx, '') / 100 : summaryArr[1].replace(rx, '');
                        summaryArr[2] = (summaryArr[2].indexOf('%') !== -1) ? summaryArr[2].replace(rx, '') / 100 : summaryArr[2].replace(rx, '');

                        if (tabInfo.RowName.trim() === "Total Fleet Pages") {
                            self.valueT283 = summaryArr[0];
                        }
                        if (self.disableSBR) {
                            if (tabInfo.RowName === "Avg. Mono Click Charge (All Devices)" || tabInfo.RowName === "Avg. Mono Click Charge (Mono Devices)" || tabInfo.RowName === "Avg. Mono Click Charge (Color Devices)" || tabInfo.RowName === "Avg. Color Click Charge") {
                                var temp = summaryArr[2];
                                if (temp !== '' && temp !== 0) {
                                    self.disableSBR = false;
                                }
                            }
                        }
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[0],
                            "editable": false,
                            "class": (tabInfo.RowName.trim() === "Avg. Mono Click Charge (All Devices)" || tabInfo.RowName.trim() === "Avg. Mono Click Charge (Mono Devices)" || tabInfo.RowName.trim() === "Avg. Mono Click Charge (Color Devices)" || tabInfo.RowName.trim() === "Avg. Color Click Charge" || tabInfo.RowName.trim() === "% Target Revenue Realized") ? true : false,
                            "dataFormat": tabInfo.dataFormat
                        })
                        tabInfo.summaryData.push({
                            "rowValue": (tabInfo.RowName.trim() === "Top Service Issue") ? 'Broken Part..' : summaryArr[1],
                            "editable": false,
                            "title": (tabInfo.RowName.trim() === "Top Service Issue") ? 'Broken Part or Component' : '',
                            "dataFormat": tabInfo.dataFormat
                        })
                        tabInfo.summaryData.push({
                            "rowValue": summaryArr[2],
                            "editable": false,
                            "class": (tabInfo.RowName.trim() === "Total Fleet Pages" || tabInfo.RowName.trim() === "Total Mono Pages (All Devices)" || tabInfo.RowName.trim() === "Total Mono Pages (Mono Devices)" || tabInfo.RowName.trim() === "Total Mono Pages (Color Devices)" || tabInfo.RowName.trim() === "Total Color Pages (Color Devices)" || tabInfo.RowName.trim() === "Total Pages (Color Devices)" || tabInfo.RowName.trim() === "Total Duplex Sheets" || tabInfo.RowName.trim() === "Total 11x17 / A3 Pages" || tabInfo.RowName.trim() === "Total Pages in Copy Mode" || tabInfo.RowName.trim() === "Total Pages in Print Mode" || tabInfo.RowName.trim() === "Total Faxes Received Pages" || tabInfo.RowName.trim() === "Total Scans (eMail, eFolder, Fax Send)" || tabInfo.RowName.trim() === "Avg. Mono Click Charge (All Devices)" || tabInfo.RowName.trim() === "Avg. Mono Click Charge (Mono Devices)" || tabInfo.RowName.trim() === "Avg. Mono Click Charge (Color Devices)" || tabInfo.RowName.trim() === "Avg. Color Click Charge" || tabInfo.RowName.trim() === "Target Revenue" || tabInfo.RowName.trim() === "% Target Revenue Realized") ? false : true,
                            "dataFormat": tabInfo.dataFormat
                        })
                    }

                })
                /* TOTAL COST OF OWNERSHIP SECTION CREATE GRAPH DATA */
                if (tableInfo.RowHeader.toLowerCase() == 'Total Cost Of Ownership'.toLowerCase()) {
                    self.dataTotalCostOwernership = [];
                    self.dataTotalCostOwernership.push({
                        key: "Estimated Invoice at Baseline",
                        yAxis: 1,
                        color: '#38D438',
                        type: "bar",
                        values: self.valueArrInvoiceBasline.slice(self.startSelection, self.endSelection)
                    });
                    self.dataTotalCostOwernership.push({
                        key: "Total Invoice Amount",
                        yAxis: 1,
                        color: "#B7FFB7",
                        type: "bar",
                        values: self.valueArrInvoiceCost.slice(self.startSelection, self.endSelection)
                    });
                    self.dataTotalCostOwernership.push({
                        key: "Baseline (Blended CPP prior to HP Fleet)",
                        yAxis: 2,
                        color: '#4B91B0',
                        classed: 'dashed',
                        type: "line",
                        values: self.valueArrHP.slice(self.startSelection, self.endSelection)
                    });
                    self.dataTotalCostOwernership.push({
                        key: "Blended Cost Per Page (All Devices)",
                        yAxis: 2,
                        color: '#0096D6',
                        type: "line",
                        values: self.valueArrBlendedCost.slice(self.startSelection, self.endSelection)
                    });
                }
                    /* CAPACITIES & UTILIZATION SECTION CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Capacities & Utilization'.toLowerCase()) {
                    self.dataCUpie.push({ value: "Mono Printers", y: self.monoPrintCU, key: self.totalPrintersCU });
                    self.dataCUpie.push({ value: "Color Printers", y: self.colorPrintCU, key: self.totalPrintersCU });
                    self.dataCUpie.push({ value: "Mono MFPs", y: self.monoMFPCU, key: self.totalPrintersCU });
                    self.dataCUpie.push({ value: "Color MFPs", y: self.colorMFPCU, key: self.totalPrintersCU });
                    self.CUDataStacked.push({ "key": "Under Utilized Devices", "values": [[0, self.UDPCU * 100]] })
                    self.CUDataStacked.push({ "key": "In Range Devices", "values": [[0, (1 - self.UDPCU - self.ODPCU) * 100]] })
                    self.CUDataStacked.push({ "key": "Over Utilized Devices", "values": [[0, self.ODPCU * 100]] })
                    self.CUDataStacked.map(function (series) {
                        series.values = series.values.map(function (d) {
                            return { x: d[0], y: d[1] };
                        });
                        return series;
                    });
                    self.averageDataBar.push({
                        key: "Entire Fleet", values: [
                            { x: 0, y: self.fleetUtilCU }, { x: 1, y: self.monoPrintPCU }, { x: 2, y: self.colorPrintPCU }, { x: 3, y: self.monoMFPPCU }, { x: 4, y: self.colorMFPPCU }]
                    });
                    self.averageDataBar.push({
                        key: "Market Vertical", values: [
                            { x: 0, y: self.marketVerticalCU.fleetUtilCU }, { x: 1, y: self.marketVerticalCU.monoPrintPCU }, { x: 2, y: self.marketVerticalCU.colorPrintPCU }, { x: 3, y: self.marketVerticalCU.monoMFPPCU }, { x: 4, y: self.marketVerticalCU.colorMFPPCU }]
                    });
                }
                    /*DEVICE CATEGORY SUMMARY SECTION CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Device Category Summary'.toLowerCase()) {
                    var DCInfo = self.JSONData[2].tabInfo;
                    for (var i = 0; i < DCInfo.length; i++) {
                        if (DCInfo[i].RowName === 'Mono Printers (Percentage of Fleet)') {
                            DCInfo[i].summaryData[1].rowValue = monototalCountDC / self.totalDeviceDC
                        } else if (DCInfo[i].RowName === 'Mono MFPs (Percentage of Fleet)') {
                            DCInfo[i].summaryData[1].rowValue = monoMFPtotalCountDC / self.totalDeviceDC
                        } else if (DCInfo[i].RowName === 'Color Printers (Percentage of Fleet)') {
                            DCInfo[i].summaryData[1].rowValue = colortotalCountDC / self.totalDeviceDC
                        } else if (DCInfo[i].RowName === 'Color MFPs (Percentage of Fleet)') {
                            DCInfo[i].summaryData[1].rowValue = colorMFPtotalCountDC / self.totalDeviceDC
                        }
                    }
                    self.dataDCpie.push({ value: "Mono Printers", y: self.graphMonthDataDC[51], key: (parseInt(self.graphMonthDataDC[51]) + parseInt(self.graphMonthDataDC[55]) + parseInt(self.graphMonthDataDC[59]) + parseInt(self.graphMonthDataDC[63])) });
                    self.dataDCpie.push({ value: "Color Printers", y: self.graphMonthDataDC[55], key: (parseInt(self.graphMonthDataDC[51]) + parseInt(self.graphMonthDataDC[55]) + parseInt(self.graphMonthDataDC[59]) + parseInt(self.graphMonthDataDC[63])) });
                    self.dataDCpie.push({ value: "Mono MFPs", y: self.graphMonthDataDC[59], key: (parseInt(self.graphMonthDataDC[51]) + parseInt(self.graphMonthDataDC[55]) + parseInt(self.graphMonthDataDC[59]) + parseInt(self.graphMonthDataDC[63])) });
                    self.dataDCpie.push({ value: "Color MFPs", y: self.graphMonthDataDC[63], key: (parseInt(self.graphMonthDataDC[51]) + parseInt(self.graphMonthDataDC[55]) + parseInt(self.graphMonthDataDC[59]) + parseInt(self.graphMonthDataDC[63])) });
                    self.dataDCMonoPrint.push({ key: "HP Devices", y: self.graphMonthDataDC[52], y2: parseInt(self.graphMonthDataDC[52]) + parseInt(self.graphMonthDataDC[53]) }, { key: "3rd Party Devices", y: self.graphMonthDataDC[53], y2: parseInt(self.graphMonthDataDC[52]) + parseInt(self.graphMonthDataDC[53]) });
                    self.dataDCColorPrint.push({ key: "HP Devices", y: self.graphMonthDataDC[56], y2: parseInt(self.graphMonthDataDC[56]) + parseInt(self.graphMonthDataDC[57]) }, { key: "3rd Party Devices", y: self.graphMonthDataDC[57], y2: parseInt(self.graphMonthDataDC[56]) + parseInt(self.graphMonthDataDC[57]) });
                    self.dataDCMonoMFP.push({ key: "HP Devices", y: self.graphMonthDataDC[60], y2: parseInt(self.graphMonthDataDC[60]) + parseInt(self.graphMonthDataDC[61]) }, { key: "3rd Party Devices", y: self.graphMonthDataDC[61], y2: parseInt(self.graphMonthDataDC[60]) + parseInt(self.graphMonthDataDC[61]) });
                    self.dataDCColorMFP.push({ key: "HP Devices", y: self.graphMonthDataDC[64], y2: parseInt(self.graphMonthDataDC[64]) + parseInt(self.graphMonthDataDC[65]) }, { key: "3rd Party Devices", y: self.graphMonthDataDC[65], y2: parseInt(self.graphMonthDataDC[64]) + parseInt(self.graphMonthDataDC[65]) })
                    self.dataDCHorizontalBar.push({ "key": "Customer Fleet", "values": [{ "label": "Mono Printers", "value": self.graphMonthDataDC[54] }, { "label": "Color Printers", "value": self.graphMonthDataDC[58] }, { "label": "Mono MFPs", "value": self.graphMonthDataDC[62] }, { "label": "Color MFPs", "value": self.graphMonthDataDC[66] }] });
                    self.dataDCHorizontalBar.push({ "key": "Market Vertical", "values": [{ "label": "Mono Printers", "value": self.marketVerticalDC[3] }, { "label": "Color Printers", "value": self.marketVerticalDC[7] }, { "label": "Mono MFPs", "value": self.marketVerticalDC[11] }, { "label": "Color MFPs", "value": self.marketVerticalDC[15] }] });

                }
                    /* COLOR USAGE SECTION CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Color Device Usage'.toLowerCase()) {
                    self.dataColorUsageCD = [];
                    self.dataColorUsageCD.push({
                        key: "Current Usage",
                        yAxis: 1,
                        color: '#4F81BD',
                        type: "bar",
                        values: self.currUsageCUArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataColorUsageCD.push({
                        key: "Color Percentage",
                        yAxis: 2,
                        color: '#7E7E7E',
                        type: "line",
                        values: self.colorPercentCUArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataColorUsageCD.push({
                        key: "Color Average",
                        yAxis: 2,
                        color: '#7E7E7E',
                        classed: 'dashedBig',
                        type: "line",
                        values: self.colorAvgArrCU.slice(self.startSelection, self.endSelection)
                    });
                    self.dataColorUsageCD.push({
                        key: "Target Average",
                        yAxis: 2,
                        color: '#7E7E7E',
                        classed: 'dashedDotted',
                        type: "line",
                        values: self.targetAvgCUArr.slice(self.startSelection, self.endSelection)
                    });
                    var maxvalueBar1 = 0;
                    var maxvalueBar2 = 0;
                    for (var i = 0; i < 10; i++) {
                        var AC74 = parseFloat(((xAxisZero - i * 0.01) * 100).toFixed(2));
                        var AC80 = ((((U73 - ((xAxisZero - i * 0.01)) * U73 / U74org) * self.displayMonth).toFixed(0)) * U79).toFixed(0)
                        var target = (T74 === '' ? 10000 : (T74 === AC74) ? AC80 : -10000)
                        self.estimatedSavingXAxisCU.push(AC74.toFixed(0));
                        self.colorPageSlopeCU.push({ x: i, y: parseFloat((AC74 * U73.toFixed(0) / U74) / 1000) });
                        self.extSaveSlopeCU.push({ x: i, y: AC80 });
                        if (target !== -10000)
                            self.savingTarget.push({ x: i, y: target });
                        if (maxvalueBar2 < parseInt(AC80))
                            maxvalueBar2 = parseInt(AC80);
                        if (maxvalueBar1 < parseInt((AC74 * U73.toFixed(0) / U74)))
                            maxvalueBar1 = parseInt((AC74 * U73.toFixed(0) / U74));
                    }
                    maxvalueBar1 = parseInt(maxvalueBar1 / 1000);
                    var devided1 = 1
                    for (i = 1 ; i < maxvalueBar1.toString().length; i++) {
                        devided1 = devided1 * 10;
                    }
                    var devided2 = 1
                    for (i = 1 ; i < maxvalueBar2.toString().length; i++) {
                        devided2 = devided2 * 10;
                    }
                    self.optionEstimatedCU.chart.yDomain1 = [0, (Math.ceil((parseFloat(maxvalueBar1) + 1) / devided1) * devided1)];
                    self.optionEstimatedCU.chart.yDomain2 = [0, (Math.ceil((parseFloat(maxvalueBar2) + 1) / devided2) * devided2)];
                    self.dataEstimatedGraph = [];
                    self.dataEstimatedGraph.push({
                        key: "Color pages Slope",
                        yAxis: 1,
                        color: 'blue',
                        type: "line",
                        values: self.colorPageSlopeCU
                    });
                    if (showColorSummary)
                        self.dataEstimatedGraph.push({
                            key: "Potetial Savings Slope",
                            yAxis: 2,
                            color: 'green',
                            type: "line",
                            values: self.extSaveSlopeCU
                        });
                    self.dataEstimatedGraph.push({
                        key: "Estimated savings at Target %",
                        yAxis: 2,
                        color: '#38D438',
                        type: "line",
                        values: self.savingTarget
                    });
                }
                    /* MONO PAGES ON COLOR DEVICES SECTION CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Mono Pages on Color Devices'.toLowerCase()) {
                    self.dataMonoUsageMD = [];
                    self.dataMonoUsageMD.push({
                        key: "Current MPoCD",
                        yAxis: 1,
                        color: '#9595FF',
                        type: "bar",
                        values: self.currMPoCDArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataMonoUsageMD.push({
                        key: "MPoCD Percentage",
                        yAxis: 2,
                        color: '#7E7E7E',
                        type: "line",
                        values: self.MPoCDPercentageArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataMonoUsageMD.push({
                        key: "Current Average",
                        yAxis: 2,
                        color: '#7E7E7E',
                        classed: 'dashedBig',
                        type: "line",
                        values: self.colorAvgArrmono.slice(self.startSelection, self.endSelection)
                    });
                    self.dataMonoUsageMD.push({
                        key: "Target Average",
                        yAxis: 2,
                        color: '#7E7E7E',
                        classed: 'dashedDotted',
                        type: "line",
                        values: self.targetAvgMonoArr.slice(self.startSelection, self.endSelection)
                    });
                    console.log(self.dataMonoUsageMD);
                    var maxvalueBar1 = 0;
                    var maxvalueBar2 = 0;
                    for (var i = 0; i < 10; i++) {
                        var AC90 = parseFloat(((xAxisZeroMono - (i / 2) * 0.01) * 100).toFixed(2));
                        var AC96 = ((parseInt(U94) - parseInt(U94 / U90 * AC90 / 100))).toFixed(0)
                        var target = ((T90 === '' || T90 === 0) ? -10000 : (T90 === AC90) ? AC96 : -10000)
                        //self.estimatedSavingXAxisMono.push((Math.round(AC90 * 2) / 2).toFixed(1));
                        self.estimatedSavingXAxisMono.push(AC90)
                        self.monoPageSlopeMPoCD.push({ x: i, y: parseFloat(((AC90 / 100) * U88 / U90).toFixed(0) / 1000) });
                        var tempEstSlope = parseInt((U94 - (U94 / parseFloat(U90) * (AC90 / 100))).toFixed(0));
                        self.extSaveSlopeMPoCD.push({ x: i, y: tempEstSlope });
                        if (target !== -10000)
                            self.savingTargetMPoCD.push({ x: i, y: target });
                        if (maxvalueBar2 < tempEstSlope)
                            maxvalueBar2 = tempEstSlope;
                        if (maxvalueBar1 < parseInt(((AC90 / 100) * U88 / U90)))
                            maxvalueBar1 = parseInt(((AC90 / 100) * U88 / U90));
                    }
                    maxvalueBar1 = parseInt(maxvalueBar1 / 1000);
                    var devided1 = 1
                    for (i = 1 ; i < maxvalueBar1.toString().length; i++) {
                        devided1 = devided1 * 10;
                    }
                    var devided2 = 1
                    for (i = 1 ; i < maxvalueBar2.toString().length; i++) {
                        devided2 = devided2 * 10;
                    }
                    self.optionEstimatedMPoCD.chart.yDomain1 = [0, (Math.ceil((parseFloat(maxvalueBar1) + 1) / devided1) * devided1)];
                    if (showMonoSummary)
                        self.optionEstimatedMPoCD.chart.yDomain2 = [0, (Math.ceil((parseFloat(maxvalueBar2) + 1) / devided2) * devided2)];
                    else
                        self.optionEstimatedMPoCD.chart.yDomain2 = [0, 1];
                    self.dataEstimatedGraphMpoCD = [];
                    self.dataEstimatedGraphMpoCD.push({
                        key: "MP on CP Slope",
                        yAxis: 1,
                        color: '#9595FF',
                        type: "line",
                        values: self.monoPageSlopeMPoCD
                    });
                    if (showMonoSummary) 
                        self.dataEstimatedGraphMpoCD.push({
                            key: "Potential Savings Slope",
                            yAxis: 2,
                            color: 'green',
                            type: "line",
                            values: self.extSaveSlopeMPoCD
                        });
                        self.dataEstimatedGraphMpoCD.push({
                            key: "Estimated savings at Target %",
                            yAxis: 2,
                            color: '#38D438',
                            type: "line",
                            values: self.savingTargetMPoCD
                        });
                }
                else if (tableInfo.RowHeader.toLowerCase() == 'Duplex Usage'.toLowerCase()) {
                    self.dataDuplexDU = [];
                    self.dataDuplexDU.push({
                        key: "Current Usage",
                        yAxis: 1,
                        color: '#E46C0A',
                        type: "bar",
                        values: self.currentUsageDUArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataDuplexDU.push({
                        key: "Current Percentage",
                        yAxis: 2,
                        color: '#7E7E7E',
                        type: "line",
                        values: self.currentPercentDUArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataDuplexDU.push({
                        key: "Current Average",
                        yAxis: 2,
                        color: '#7E7E7E',
                        classed: 'dashedBig',
                        type: "line",
                        values: self.currentAvgArrDU.slice(self.startSelection, self.endSelection)
                    });
                    self.dataDuplexDU.push({
                        key: "Target Average",
                        yAxis: 2,
                        color: '#7E7E7E',
                        classed: 'dashedDotted',
                        type: "line",
                        values: self.targetAvgDUArr.slice(self.startSelection, self.endSelection)
                    });

                    var maxvalueBar1 = 0;
                    var maxvalueBar2 = 0;
                    for (var i = 0; i < 10; i++) {
                        var AC104 = parseFloat(((xAxisZeroDuplex + i * 0.01) * 100).toFixed(2));
                        var AC109 = (parseInt(U107 / U104 * AC104 / 100) - parseInt(U107)).toFixed(0)
                        var target = (T104 === '' ? -10000 : (T104 === AC104) ? AC109 : -10000)
                        self.estimatedSavingXAxisDuplex.push(AC104.toFixed(0));
                        self.duplexSlopeDuplex.push({ x: i, y: parseFloat(((AC104 / 100) * U103 / U104).toFixed(0) / 1000) });
                        self.extSaveSlopeDuplex.push({ x: i, y: AC109 });
                        //self.savingTarget.push({ x: i, y: target });
                        if (target !== -10000)
                            self.savingTargetDuplex.push({ x: i, y: target });
                        if (maxvalueBar2 < parseInt(AC109))
                            maxvalueBar2 = parseInt(AC109);
                        if (maxvalueBar1 < parseInt(((AC104 / 100) * U103 / U104)))
                            maxvalueBar1 = parseInt(((AC104 / 100) * U103 / U104));
                    }
                    maxvalueBar1 = parseInt(maxvalueBar1 / 1000);
                    var devided1 = 1
                    for (i = 1 ; i < maxvalueBar1.toString().length; i++) {
                        devided1 = devided1 * 10;
                    }
                    var devided2 = 1
                    for (i = 1 ; i < maxvalueBar2.toString().length; i++) {
                        devided2 = devided2 * 10;
                    }
                    self.optionEstimatedDuplex.chart.yDomain1 = [0, (Math.ceil((parseFloat(maxvalueBar1) + 1) / devided1) * devided1)];
                    self.optionEstimatedDuplex.chart.yDomain2 = [0, (Math.ceil((parseFloat(maxvalueBar2) + 1) / devided2) * devided2)];
                    self.dataEstimatedGraphDuplex = [];
                    self.dataEstimatedGraphDuplex.push({
                        key: "Duplex Slope",
                        yAxis: 1,
                        color: '#E46C0A',
                        type: "line",
                        values: self.duplexSlopeDuplex
                    });
                    if (showDuplexSummary)
                    self.dataEstimatedGraphDuplex.push({
                        key: "Potential Savings Slope",
                        yAxis: 2,
                        color: 'green',
                        type: "line",
                        values: self.extSaveSlopeDuplex
                    });
                    self.dataEstimatedGraphDuplex.push({
                        key: "Estimated savings at Target %",
                        yAxis: 2,
                        color: '#38D438',
                        type: "line",
                        values: self.savingTargetDuplex
                    });
                }
                    /* TONER/INK TRACKING CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() === 'Toner/Ink Tracking'.toLowerCase()) {
                    self.labelsTIT = self.labelstrack.slice(self.startSelection, self.endSelection)
                    self.dataTIT = [
                      self.tonerUsedArr.slice(self.startSelection, self.endSelection),
                      self.tonerRecvdArr.slice(self.startSelection, self.endSelection),
                      self.invDevArr.slice(self.startSelection, self.endSelection)
                    ];
                    self.dataOSAPercent = [];
                    self.dataOSAPercent.push({
                        key: "Number Of Toner Replacements",
                        yAxis: 1,
                        color: '#4B91B0',
                        type: "bar",
                        values: self.tonerCUsedArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataOSAPercent.push({
                        key: "Toner Replacement Missed",
                        yAxis: 1,
                        color: '#0096D6',
                        type: "bar",
                        values: self.tonerMissedArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataOSAPercent.push({
                        key: "On Time %",
                        yAxis: 2,
                        color: "#B7FFB7",
                        classed: 'bullet',
                        type: "line",
                        values: self.onTimePercentTITArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataOSAPercent.push({
                        key: "On Time Target %",
                        yAxis: 2,
                        color: '#38D438',
                        classed: 'dashed',
                        type: "line",
                        values: self.onTimeTarget.slice(self.startSelection, self.endSelection)
                    });
                }
                    /* OTHER CONSUMABLE TRACKING CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() === 'Other Consumable Tracking'.toLowerCase()) {
                    self.labelstrackSC = self.labelstrack.slice(self.startSelection, self.endSelection)
                    self.datatrackSC = [
                      self.stapleDeviationArr.slice(self.startSelection, self.endSelection),
                      self.stapleUsedArr.slice(self.startSelection, self.endSelection),
                      self.stapleReceivedArr.slice(self.startSelection, self.endSelection),
                      self.stapleDeviationTLArr.slice(self.startSelection, self.endSelection)
                    ];
                    self.datatrackID = [
                      self.drumDeviationArr.slice(self.startSelection, self.endSelection),
                      self.drumUsedArr.slice(self.startSelection, self.endSelection),
                      self.drumReceivedArr.slice(self.startSelection, self.endSelection),
                      self.drumDeviationTLArr.slice(self.startSelection, self.endSelection)
                    ];
                    self.datatrackBOP = [
                      self.bopDeviationArr.slice(self.startSelection, self.endSelection),
                      self.bopUsedArr.slice(self.startSelection, self.endSelection),
                      self.bopReceivedArr.slice(self.startSelection, self.endSelection),
                      self.bopDeviationTLArr.slice(self.startSelection, self.endSelection)
                    ];
                }
                    /* DEVICE TRACKING & DEPLOYMENT CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() === 'Device Tracking & Deployment'.toLowerCase()) {
                    self.DeviceTrackingDataBar = [];
                    self.DeviceTrackingDataBar.push({
                        key: "Projected Installations",
                        color: "#059EE2",
                        values: self.deviceProjectedArr.slice(self.startSelection, self.endSelection)
                    });
                    self.DeviceTrackingDataBar.push({
                        key: "Actual Installations",
                        color: '#DEDCD2',
                        values: self.deviceActualArr.slice(self.startSelection, self.endSelection)
                    });
                    self.siteTrackingDataBar = [];
                    self.siteTrackingDataBar.push({
                        key: "Projected Installations",
                        color: "#059EE2",
                        values: self.siteProjectedArr.slice(self.startSelection, self.endSelection)
                    });
                    self.siteTrackingDataBar.push({
                        key: "Actual Installations",
                        color: '#DEDCD2',
                        values: self.siteActualeArr.slice(self.startSelection, self.endSelection)
                    });
                }
                else if (tableInfo.RowHeader.toLowerCase() === 'Service Level'.toLowerCase()) {
                    self.dataSLPerformanceBar = [];
                    self.dataSLPerformanceBar.push({
                        key: "Performance Uptime",
                        yAxis: 1,
                        color: '#05A0E4',
                        type: "bar",
                        values: self.performanceUpTArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataSLPerformanceBar.push({
                        key: "Accepted Minimum",
                        yAxis: 1,
                        color: 'red',
                        type: "line",
                        classed: 'solidBoldLine',
                        values: self.performanceUpTargetArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataSLMetBar = [];
                    self.dataSLMetBar.push({
                        key: "Service Level Agreement Met",
                        yAxis: 1,
                        color: '#04B854',
                        type: "bar",
                        values: self.SLAMetArr.slice(self.startSelection, self.endSelection)
                    });
                    self.dataSLMetBar.push({
                        key: "Accepted Minimum SLA%",
                        yAxis: 1,
                        color: 'red',
                        type: "line",
                        classed: 'solidBoldLine',
                        values: self.SLAMetTagetArr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar = [];
                    self.serviceIncDataBar.push({
                        key: self.keys[0],
                        values: self.SL131Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[1],
                        values: self.SL132Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[2],
                        values: self.SL133Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[3],
                        values: self.SL134Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[4],
                        values: self.SL135Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[5],
                        values: self.SL136Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[6],
                        values: self.SL137Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[7],
                        values: self.SL138Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[8],
                        values: self.SL139Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[9],
                        values: self.SL140Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[10],
                        values: self.SL141Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[11],
                        values: self.SL142Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[12],
                        values: self.SL143Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[13],
                        values: self.SL144Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[14],
                        values: self.SL145Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[15],
                        values: self.SL146Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[16],
                        values: self.SL147Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[17],
                        values: self.SL148Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[18],
                        values: self.SL149Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[19],
                        values: self.SL150Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[20],
                        values: self.SL151Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[21],
                        values: self.SL152Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[22],
                        values: self.SL153Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[23],
                        values: self.SL154Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[24],
                        values: self.SL155Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.serviceIncDataBar.push({
                        key: self.keys[25],
                        values: self.SL156Arr.slice(self.startSelection, self.endSelection)
                    });
                }
                    /* NRD SECTION DATA CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() === 'NRD Summary'.toLowerCase()) {
                    self.NRDMonthDataBar = [];
                    self.NRDMonthDataBar.push({
                        key: "1 Month",
                        color: "#ADADAD",
                        values: self.NRDm1Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.NRDMonthDataBar.push({
                        key: "2 Months",
                        color: '#FDF1A3',
                        values: self.NRDm2Arr.slice(self.startSelection, self.endSelection)
                    });
                    self.NRDMonthDataBar.push({
                        key: "3 Months +",
                        color: '#DE9254',
                        values: self.NRDm3Arr.slice(self.startSelection, self.endSelection)
                    });
                    // self.NRDMonthOptionsBar.chart.yDomain = [0, parseInt(self.maxvalueBarMonthNRD.slice(self.startSelection, self.endSelection).reduce(function (a, b) { return Math.max(a, b); })) + 2];
                    // self.NRDExceptionsOptionsBar.chart.yDomain = [0, parseInt(self.maxvaluetotalDevicesNRD.slice(self.startSelection, self.endSelection * 3).reduce(function (a, b) { return Math.max(a, b); })) + 5];
                    self.NRDExceptionsDataBar = [];
                    self.NRDExceptionsDataBar.push({
                        key: "Device in Storage",
                        color: "#07BAFA",
                        values: self.NRDDeviceStorageArr.slice(self.startSelection, self.endSelection)
                    });
                    self.NRDExceptionsDataBar.push({
                        key: "Non-Networked Devices",
                        color: '#F7D7A8',
                        values: self.NRDNonNWArr.slice(self.startSelection, self.endSelection)
                    });
                    self.NRDExceptionsDataBar.push({
                        key: "Other Known NRDs",
                        color: '#E2E2E2',
                        values: self.NRDOtherKnownArr.slice(self.startSelection, self.endSelection)
                    });
                }
                    /* NID SECTION DATA CREATE GRAPH DATA */
                else if (tableInfo.RowHeader.toLowerCase() === 'NID Summary'.toLowerCase()) {
                    self.NIDDataBar = [];
                    self.NIDDataBar.push({
                        key: "Non-Invoiced Devices",
                        color: "#E39558",
                        values: self.NIDAdjustedArr.slice(self.startSelection, self.endSelection)
                    });
                    self.NIDDataBar.push({
                        key: "Marked Exceptions",
                        color: '#EDE9D2',
                        values: self.NIDMEArr.slice(self.startSelection, self.endSelection)
                    });
                    self.NIDDataBar.push({
                        key: "Non-Invoiced,Newly Installed Devices",
                        color: '#00AFEF',
                        values: self.NIDNewlyArr.slice(self.startSelection, self.endSelection)
                    });
                }
            })
            /*****************
                //SHARING DATA TO MARKET VERTICAL CONTROLLER - STARTS HERE 
            *****************/
            var getkeymv;
            self.marketVerticalParamData = [];
            self.curRateAlert = false;
            self.curRateAlertArray = [];
            var expression = "[" + self.currSymbol + ",%]";
            var rx = new RegExp(expression, 'g');
            //Collecting Row header names and Values in Object 
            angular.forEach(self.tableInfo, function (row) {
                angular.forEach(row.tabInfo, function (tinfo) {
                    getkeymv = tinfo.RowName;
                    var mvParamObj = {};
                    var mvsumary = tinfo.summary.split(";");
                    //Need to take 2nd object values only 
                    if (tinfo.summaryData.length > 2) {
                        if (tinfo.summaryData[1].rowValue != 0 && tinfo.summaryData[1].rowValue != null && tinfo.summaryData[1].rowValue !== "-" && tinfo.summaryData[1].rowValue.toString().indexOf('Month') === -1 && tinfo.summaryData[1].rowValue.toString().indexOf('Broken') === -1) {
                            mvParamObj['Key'] = getkeymv; //tinfo.summaryData[1].rowValue;
                            mvParamObj['Value'] = tinfo.summaryData[1].rowValue.toString().replace(rx, '');
                            self.marketVerticalParamData.push(mvParamObj);
                        }
                    }
                    //AS per developer needs adding few more values to the same object 
                    if (tinfo.RowID == 79 || tinfo.RowID == 95 || tinfo.RowID == 108) {
                        mvParamObj['Key'] = mvsumary[0] + tinfo.RowID; //Adding row id to give a separation in row header names
                        mvParamObj['Value'] = mvsumary[1].toString().replace(rx, '');
                        self.marketVerticalParamData.push(mvParamObj);
                    } else if (tinfo.RowID == 19) {
                        mvParamObj['Key'] = getkeymv;
                        mvParamObj['Value'] = tinfo.summaryData[0].rowValue.toString().replace(rx, '');
                        self.marketVerticalParamData.push(mvParamObj);
                    }
                    //To make a alert if Currency Rate is more than 10(Value)                       
                    if (tinfo.RowID == 7 || tinfo.RowID == 8 || tinfo.RowID == 9 || tinfo.RowID == 10 || tinfo.RowID == 295 || tinfo.RowID == 296 || tinfo.RowID == 297 || tinfo.RowID == 298) {
                        if (tinfo.summaryData.length > 2) {
                            //Cur Rate Value
                            var calculateAlertValue = tinfo.summaryData[1].rowValue * self.curRateMV; //Calaculating row vlue with Currency Rate
                            //Pushing row name to a object if calacualted values is more than 10 
                            //then Row name can display while popuping a alret 
                            if (calculateAlertValue > 10) {
                                self.curRateAlert = true;
                                self.curRateAlertArray.push({ 'RowName': getkeymv });
                            }
                        }
                    }
                });
            });
            $rootScope.curRateAlert = self.curRateAlert;
            $rootScope.curRateAlertArray = self.curRateAlertArray;
            $rootScope.sbrStartEndDate = self.SBRData;
            //console.log(self.marketVerticalParamData);
            marketVerticalAverage.set(self.marketVerticalParamData);
            /*****************
                //SHARING DATA TO MARKET VERTICAL CONTROLLER - ENDS HERE  
            *****************/
            self.dataCDpie1.push({ value: "Color", y: parseFloat(U74, 1) });
            self.dataCDpie1.push({ value: "Mono", y: (100 - parseFloat(U74, 1) - parseFloat(self.MPMonoTP, 1)) });
            self.dataCDpie1.push({ value: "MP on CD", y: parseFloat(self.MPMonoTP, 1) });
            self.dataCDpie2.push({ value: "Color", y: parseFloat(U75, 1) });
            self.dataCDpie2.push({ value: "Mono", y: 0 });
            self.dataCDpie2.push({ value: "MP on CD", y: 100 - parseFloat(U75, 1) });

            self.valueTUY = (self.valueT283 - (self.valueTU103 * self.displayMonth));
            var ArrOne = self.dplChk == 1 ? self.valueT283 * 528897.6 / 100000000 : self.valueT283 * 528897.6 / 100000000 * 2.20462265;
            var ArrTwo = self.dplChk == 1 ? self.valueTUY * 528897.6 / 100000000 : self.valueTUY * 528897.6 / 100000000 * 2.20462265;
            self.dataDUHorizontalBar.push({ "key": "CO2 Emmissions", "values": [{ "label": "Current", "value": ArrOne.toFixed(2) }, { "label": "At Target", "value": ArrTwo.toFixed(2) }] });
            for (var i = 0 ; i < self.keys.length; i++) {
                self.dataSLpie.push({ value: self.keys[i], y: self.valueSLarr[i] })
            }
            if (showColorSummary && showMonoSummary && showDuplexSummary)
                self.showViewSummary = true;
        }

        /* ----------------------------------------------- */
        /* CALCULATION OF LEFT SIDE DATA */
        /* ----------------------------------------------- */
        var calculateData = function (response) {
            self.JSONData = response.data.Item1;
            self.curRateMV = self.JSONData[0].currRate;
            self.range1 = self.JSONData[0].YearList;
            self.item2Data = response.data.Item2;
            self.currSymbol = self.JSONData[0].currSymbol;
            self.IsClickOnlyArrears = self.JSONData[0].IsClickOnlyArrears;
            self.SBRData.companyName = self.JSONData[0].companyInfo;
            /* SET DEFAULT SLIDER RANGE */
            angular.forEach(self.JSONData[0].YearList, function (element, key) {
                if (element.MonthYear == response.data.Item2[0].MonthYear)
                    self.sliderRange = key - 1;
            });
            /* TOTAL NO OF INVOICE MONTHS */
            self.totalMonth = self.JSONData[0].YearList.length;
            for (var i = 0; i < self.JSONData[0].YearList.length; i++) {
                if (self.JSONData[0].YearList[i].MonthYear.indexOf("-") === -1) {
                    self.JSONData[0].YearList[i].MonthYear = '';
                    self.totalMonth--;
                }
            }
            self.arrayLength = self.range1.length;
            if (self.arrayLength > 13)
                self.arrayLength = 13;
            self.displayRange = parseInt(self.arrayLength);
            self.sliderMax = self.range1.length - 13;
            var PDDataTemp = [];
            var invoicebaseLine = [];
            var invoiceCost = [];
            var baselineCPP = [];
            var blendedCost = [];
            self.valueArrHP = [];
            self.valueArrBlendedCost = [];
            self.valueArrInvoiceCost = [];
            self.valueArrInvoiceBasline = [];
            var NIDNewly = [];
            var NIDME = [];
            var NIDAdjusted = [];
            var NRDm1 = [];
            var NRDm2 = [];
            var NRDm3 = [];
            var NRDNonNW = [];
            var NRDOtherKnown = [];
            var NRDDeviceStorage = [];
            var deviceProjected = [];
            var deviceActual = [];
            var siteProjected = [];
            var siteActual = [];
            var stapleUsed = [];
            var stapleReceived = [];
            var stapleDeviation = [];
            var drumUsed = [];
            var drumReceived = [];
            var drumDeviation = [];
            var bopUsed = [];
            var bopReceived = [];
            var bopDeviation = [];
            var tonerUsed = [];
            var tonerReceived = [];
            var tonerDeviation = [];
            var onTimePercentTIT = [];
            var tonerCUsed = [];
            var tonerMissed = [];
            var currUsageCU = [];
            var colorPercentCU = [];
            var currMPoCD = [];
            var MPoCDPercentage = [];
            var performanceUpT = [];
            var SLAMet = [];
            angular.forEach(self.JSONData, function (tableInfo, key) {
                tableInfo.ID = key;
                tableInfo.TCOselect = false;
                tableInfo.enable = self.displaySection[key];
                var expression = "[" + self.currSymbol + ",%]";
                var rx = new RegExp(expression, 'g');
                /* TOTAL COST OF OWNERSHIP LEFT SECTION DATA */
                if (tableInfo.RowHeader.toLowerCase() == 'TCO Section'.toLowerCase()) {
                    tableInfo.TCOselect = true;
                    tableInfo.RowHeader = "Total Cost Of Ownership";
                    self.dataTotalCostOwernership = [];
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        var estimateSavingDelta = '';
                        tabInfo.dataFormat = 'noDecimal';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() == 'Original Baseline (Blended CPP)'.toLowerCase()) {
                            tabInfo.title = "The Baseline is the Blended Cost Per Page (color and mono pages combined) the customer was paying prior to the HP solution being installed.  If the customer or HP's Pre-Sales Team cannot provide this information you may be able to determine an appropriate value by doing one of the following:\n\nEstimate the Baseline\nIf the customer can provide the total charges from an invoice prior to HP's installed solution, you can divide the Total Invoice Cost by the Total Print Volume of the HP installed fleet.  This method will work only if the customer's fleet print volume has not changed significantly.  Also be sure to remove any unwanted charges such as taxes or charges for additional services.\n\nEstablish a Starting Baseline from Historical Data\nIf the account has been an HP customer for some time you can use the Blended Cost Per Page from a prior QBR as a starting point.  Divide the Average Total Invoice (minus taxes and services) by the Average Total Fleet Page Volume for any previous period of time.\n\nEstablish a Starting Reference Point from the Current Blended Cost Per Page\nYou can use the Current Blended Cost per Page or a value slightly higher as a starting reference. Over time you will be able to track the progress of the fleet.  This method should be used only as a last resort and would require buy-in from the customer. \n\nWhich ever method you choose in determining a Baseline, be certain the resulting value can be justified.  Getting buy-in from the customer prior to presenting the QBR is also strongly encouraged.";
                            tabInfo.dataFormat = 'decimal';
                            tabInfo.RowName = "Baseline (Blended CPP prior to HP Fleet)";
                            baselineCPP = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() == 'Blended Cost Per Page (All Devices)'.toLowerCase()) {
                            tabInfo.title = "Calculation:\nTotal Device Charges  / Total Fleet Pages\n\nNote: This calculation reflects reporting devices only.";
                            tabInfo.dataFormat = 'decimal';
                            blendedCost = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() == 'Blended Cost Per Page (Mono)'.toLowerCase()) {
                            tabInfo.title = "Calculation:\nTotal Mono Device Charges  /  Total Mono Device Pages\n\nNote: This calculation reflects reporting devices only.";
                            tabInfo.dataFormat = 'decimal';
                        } else if (tabInfo.RowName.toLowerCase() == 'Blended Cost Per Page (Color)'.toLowerCase()) {
                            tabInfo.title = "Calculation:\nTotal Color Device Charges  / Total Color Device Pages\n\nNote: This calculation reflects reporting devices only.";
                            tabInfo.dataFormat = 'decimal';
                        } else if (tabInfo.RowName.toLowerCase() == 'TCO Percentage of Improvement'.toLowerCase()) {
                            tabInfo.title = "(Blended Cost Per Page / Baseline) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() == 'Option Charge/Credit Entry'.toLowerCase()) {
                            tabInfo.title = "This Description can be changed as needed.";
                            tabInfo.RowName = '';
                        } else if (tabInfo.RowName.toLowerCase() == 'Device Charges for Total Fleet'.toLowerCase()) {
                            tabInfo.title = "";
                        } else if (tabInfo.RowName.toLowerCase() == 'Total Invoice Cost'.toLowerCase()) {
                            tabInfo.title = "Calculation:\nTotal the Charges, Costs and Taxes listed above 5 rows.";
                            tabInfo.RowName = 'Total Invoice Amount';
                            invoiceCost = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() == 'Estimated Invoice at Original Baseline'.toLowerCase()) {
                            tabInfo.title = "Calculation:\nTotal Fleet Pages x Baseline";
                            tabInfo.RowName = 'Estimated Invoice at Baseline';
                            invoicebaseLine = tabInfo.PDData;
                            /* CALCULATION FOR GRAPH DATA  AND ESTIMATED SAVINGS DELTA*/
                            if (invoicebaseLine.length && invoiceCost.length && baselineCPP.length && blendedCost.length) {
                                var maxvalueBar = 0;
                                var maxvalueline = 0;
                                monthTotal = 0;
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    /* SET ESTIMATED SAVINGS DELTA */
                                    if (invoicebaseLine[i].rowValue - invoiceCost[i].rowValue === 0) {
                                        estimateSavingDelta = '';
                                    } else {
                                        estimateSavingDelta = invoicebaseLine[i].rowValue - invoiceCost[i].rowValue;
                                    }
                                    /* CHECK MAX VALUE FOR GRAPH */
                                    if (parseFloat(maxvalueBar) < parseFloat(invoiceCost[i].rowValue))
                                        maxvalueBar = invoiceCost[i].rowValue;
                                    if (parseFloat(maxvalueBar) < parseFloat(invoicebaseLine[i].rowValue))
                                        maxvalueBar = invoicebaseLine[i].rowValue;
                                    if (parseFloat(maxvalueline) < parseFloat(baselineCPP[i].rowValue))
                                        maxvalueline = baselineCPP[i].rowValue;
                                    /* SET ALL THE DATA */
                                    PDDataTemp.push({
                                        "rowValue": estimateSavingDelta
                                    });
                                    if (self.arrayLength > i && estimateSavingDelta != '') {
                                        monthTotal = monthTotal + parseFloat(estimateSavingDelta);
                                    }
                                    var date = new Date(tableInfo.YearList[i].MonthYear).toLocaleDateString();
                                    self.optionsTotalCostOwernership.chart.xAxisLabels = tableInfo.YearList;
                                    self.valueArrHP.push({
                                        x: i,
                                        y: (baselineCPP[i].rowValue !== '') ? parseFloat(baselineCPP[i].rowValue).toFixed(5) : baselineCPP[i].rowValue
                                    });
                                    self.valueArrBlendedCost.push({
                                        x: i,
                                        y: (blendedCost[i].rowValue !== '') ? parseFloat(blendedCost[i].rowValue).toFixed(5) : blendedCost[i].rowValue
                                    });
                                    self.valueArrInvoiceCost.push({
                                        x: i,
                                        y: (invoiceCost[i].rowValue) ? parseFloat(invoiceCost[i].rowValue).toFixed(0) / 1000 : invoiceCost[i].rowValue
                                    });
                                    self.valueArrInvoiceBasline.push({
                                        x: i,
                                        y: (invoicebaseLine[i].rowValue) ? parseFloat(invoicebaseLine[i].rowValue).toFixed(0) / 1000 : invoicebaseLine[i].rowValue
                                    });
                                }
                                maxvalueBar = parseInt(maxvalueBar / 1000);
                                self.optionsTotalCostOwernership.chart.yDomain1 = [0, (Math.ceil((parseFloat(maxvalueBar) + 1) / 1000) * 1000)];
                                self.optionsTotalCostOwernership.chart.yDomain2 = [0, parseFloat(maxvalueline).toFixed(5)];
                            }
                        }
                        if (tabInfo.RowID === 19) {
                            tabInfo.RowName = "Estimated Savings Delta";
                            tabInfo.PDData = PDDataTemp
                        }
                    });
                }
                    /* CAPACITIES & UTILIZATION LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Capacities & Utilization Section'.toLowerCase()) {
                    /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                    tableInfo.RowHeader = "Capacities & Utilization";
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Additional Volume (From Mono NRDs)'.toLowerCase()) {
                            tabInfo.title = "Enter page volume from Non-Reporting Devices.";
                            tabInfo.RowName = "Additional Mono Volume (From NRDs)";
                        } else if (tabInfo.RowName.toLowerCase() === 'Additional Volume (From Color NRDs)'.toLowerCase()) {
                            tabInfo.title = "Enter page volume from Non-Reporting Devices.";
                            tabInfo.RowName = "Additional Color Volume (From NRDs)";
                        } else if (tabInfo.RowName.toLowerCase() === 'Fleet Target Volume (Pages)'.toLowerCase()) {
                            tabInfo.title = "Calculated using the target values entered on the 'Sow Information' tab.";
                        } else if (tabInfo.RowName.toLowerCase() === 'Average Pages Per Device'.toLowerCase()) {
                            tabInfo.title = "Total Fleet Pages / Number of Devices Invoiced";
                        } else if (tabInfo.RowName.toLowerCase() === 'Under Utilized Device Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation:\n(Number of devices less than the Minimum Suggested Volume / Total number of  Devices in Fleet ) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Over Utilized Device Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Number of devices greater than the Maximum Suggested Volume / Total number of  Devices in Fleet ) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Fleet Utilization Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Actual Fleet Volume / Fleet Target Volume) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Mono Printers Utilization Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Pages Printed on Mono Printers / Average Target Volume for Mono Printers) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Color Printers Utilization Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Pages Printed on Color Printers / Average Target Volume for Color Printers) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Mono MFP Utilization Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Pages Printed on Mono MFPs / Average Target Volume for Mono MFPs) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Color MFP Utilization Percentage'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Pages Printed on Color MFPs / Average Target Volume for Color MFPs) x 100";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Fleet Size (# devices Invoiced)'.toLowerCase()) {
                            tabInfo.classBold = true;
                        }
                    });
                }
                    /* DEVICE CATEGORY SUMMARY LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Device Category Summary Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Device Category Summary";
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowID === 58) {
                            tabInfo.RowName = 'Color Printers (Percentage of Fleet)';
                        } else if (tabInfo.RowID === 59) {
                            tabInfo.RowName = 'Mono MFPs (Total Count)';
                        }
                        if (tabInfo.RowName.toLowerCase() === 'Mono Printers (Total Count)'.toLowerCase()) {
                            tabInfo.classBold = true;
                        } else if (tabInfo.RowName.toLowerCase() === 'Color Printers (Total Count)'.toLowerCase()) {
                            tabInfo.classBold = true;
                        } else if (tabInfo.RowName.toLowerCase() === 'Mono MFPs (Total Count)'.toLowerCase()) {
                            tabInfo.classBold = true;
                        } else if (tabInfo.RowName.toLowerCase() === 'Color MFPs (Total Count)'.toLowerCase()) {
                            tabInfo.classBold = true;
                        } else if (tabInfo.RowName.trim().toLowerCase() === 'HP Devices'.toLowerCase()) {
                            tabInfo.classBold = true;
                            tabInfo.classGray = true;
                        } else if (tabInfo.RowName.trim().toLowerCase() === '3rd Party Devices'.toLowerCase()) {
                            tabInfo.classBold = true;
                            tabInfo.classGray = true;
                        } else if (tabInfo.RowName.toLowerCase() === 'Mono Printers (Percentage of Fleet)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \nMono Printer Count / Number of Devices Invoiced";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Mono MFPs (Percentage of Fleet)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \nMono MFP Count / Number of Devices Invoiced";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Color Printers (Percentage of Fleet)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \nColor Printer Count / Number of Devices Invoiced";
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase() === 'Color MFPs (Percentage of Fleet)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \nColor MFP Count / Number of Devices Invoiced";
                            tabInfo.dataFormat = 'percent';
                        }

                    });
                }
                /* COLOR USAGE LEFT SECTION DATA */
                if (tableInfo.RowHeader.toLowerCase() == 'Color Usage Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Color Device Usage";
                    var targetAvgCU = 0;
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Color Pages'.toLowerCase()) {
                            tabInfo.RowName = 'Total Color Pages';
                            currUsageCU = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Color Pages vs. Total Fleet Volume (%)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Total Color Pages / Total Fleet Pages) x 100";
                            tabInfo.dataFormat = 'percentOneDigit';
                            colorPercentCU = tabInfo.PDData;
                            var summaryArr = result.RowValues.split(";")
                            summaryArr[0] = (summaryArr[0].indexOf('%') !== -1) ? summaryArr[0].replace(rx, '') / 100 : summaryArr[0].replace(rx, '');
                            targetAvgCU = parseFloat(summaryArr[0] * 100);
                        } else if (tabInfo.RowName.toLowerCase() === 'Color Pages vs. TPoCD (%)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Total Color Pages / TPoCD) x 100";
                            tabInfo.dataFormat = 'percentOneDigit';
                        } else if (tabInfo.RowName.toLowerCase() === 'Average Color Click Charge'.toLowerCase()) {
                            tabInfo.title = "Calculation: \nTotal Color Click Charges / Total Color Pages";
                            tabInfo.dataFormat = 'decimal';
                        } else if (tabInfo.RowName.toLowerCase() === 'Estimated Color Click Charges'.toLowerCase()) {
                            tabInfo.title = "Calculation: \nColor Pages x Average Color Click Charge";
                            tabInfo.dataFormat = 'noDecimal';
                            /* CALCULATION OF GRAPH DATA */
                            if (currUsageCU.length && colorPercentCU.length) {
                                self.currUsageCUArr = [];
                                self.colorPercentCUArr = [];
                                self.targetAvgCUArr = [];
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    self.currUsageCUArr.push({
                                        x: i,
                                        y: (currUsageCU[i].rowValue !== '') ? parseInt(currUsageCU[i].rowValue) / 1000 : 0
                                    });
                                    self.colorPercentCUArr.push({
                                        x: i,
                                        y: (colorPercentCU[i].rowValue !== '') ? parseFloat(colorPercentCU[i].rowValue * 100).toFixed(2) : 0
                                    });
                                    self.targetAvgCUArr.push({
                                        x: i,
                                        y: parseFloat(targetAvgCU).toFixed(2)
                                    });
                                }
                            }
                        }
                    });
                }
                /* MONO ON COLOR LEFT SECTION DATA */
                if (tableInfo.RowHeader.toLowerCase() == 'Mono on Color Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Mono Pages on Color Devices";
                    var targetAvgMono = 0;
                    var colorAvgMono = 0;
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'MPoCD vs. TPoCD (%)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(MPoCD / TPoCD) x 100";
                            tabInfo.dataFormat = 'percentOneDigit';
                        } else if (tabInfo.RowName.toLowerCase() === 'MPoCD vs. Total Fleet Volume (%)'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(MPoCD / Total Fleet Volume) x 100";
                            tabInfo.dataFormat = 'percentOneDigit';
                            targetAvgMono = parseFloat(result.RowValues.split(";")[0] * 100);
                            colorAvgMono = parseFloat(result.RowValues.split(";")[1] * 100);
                            MPoCDPercentage = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Mono Pages on Color Devices (MPoCD)'.toLowerCase()) {
                            currMPoCD = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Average Mono on Color Click Charge'.toLowerCase()) {
                            tabInfo.dataFormat = 'decimal';
                        } else if (tabInfo.RowName.toLowerCase() === 'Average Mono on Mono Click Charge'.toLowerCase()) {
                            tabInfo.dataFormat = 'decimal';
                        } else if (tabInfo.RowName.toLowerCase() === 'Average Click Charge Differential'.toLowerCase()) {
                            tabInfo.dataFormat = 'decimal';
                            tabInfo.title = "Calculation: \nAverage Mono Click Charge on Color Device - Average Mono Click Charge on Mono Device";
                            tabInfo.RowName = 'Average Mono Click Charge Differential'
                        } else if (tabInfo.RowName.toLowerCase() === 'Estimated Additional Expence'.toLowerCase()) {
                            tabInfo.RowName = "Estimated Additional Expense";
                            tabInfo.dataFormat = 'noDecimal';
                            /* CALCULATION OF GRAPH DATA */
                            if (currMPoCD.length && MPoCDPercentage.length) {
                                self.currMPoCDArr = [];
                                self.MPoCDPercentageArr = [];
                                self.targetAvgMonoArr = [];
                                self.colorAvgArrmono = [];
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    self.currMPoCDArr.push({
                                        x: i,
                                        y: (currMPoCD[i].rowValue !== '') ? parseInt(currMPoCD[i].rowValue) / 1000 : 0
                                    });
                                    self.MPoCDPercentageArr.push({
                                        x: i,
                                        y: (MPoCDPercentage[i].rowValue !== '') ? parseFloat(MPoCDPercentage[i].rowValue * 100).toFixed(2) : 0
                                    });
                                    self.targetAvgMonoArr.push({
                                        x: i,
                                        y: parseFloat(targetAvgMono).toFixed(2)
                                    });
                                    self.colorAvgArrmono.push({
                                        x: i,
                                        y: parseFloat(colorAvgMono).toFixed(2)
                                    })
                                }
                            }
                        }
                    });
                }
                /* DUPLEX LEFT SECTION DATA */
                if (tableInfo.RowHeader.toLowerCase() == 'Duplex Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Duplex Usage";
                    var targetAvgDU = 0;
                    var currentPercent = [];
                    var currentPercentDU = [];
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Duplex Percentage'.toLowerCase()) {
                            tabInfo.RowName = 'Duplex Percentage(Pages)';
                            tabInfo.dataFormat = 'percentOneDigit';
                            currentPercentDU = tabInfo.PDData;
                            tabInfo.title = 'Calculation:\n Duplex Sheets x 2  / Total Fleet Volume x 100';
                            targetAvgDU = parseFloat(result.RowValues.split(";")[0]);
                        } else if (tabInfo.RowName.toLowerCase() === 'Duplex Volume (Sheets)'.toLowerCase()) {
                            currentUsageDU = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Paper Reduction Percentage'.toLowerCase()) {
                            tabInfo.RowName = 'Paper Reduction Percentage(Sheets)';
                            tabInfo.dataFormat = 'percentOneDigit';
                            tabInfo.title = 'Calculation:\n (Duplex Sheets / Total Fleet Volume) x 100';
                        } else if (tabInfo.RowName.toLowerCase() === 'Paper Cost Multiplier (Cost of 1 Sheet)'.toLowerCase()) {
                            tabInfo.dataFormat = 'decimal';
                            tabInfo.title = "This value is the customer's cost to purchase 1 sheet of paper.  If no value is entered the default is 1 cent.";
                        } else if (tabInfo.RowName.toLowerCase() === 'Estimated Savings'.toLowerCase()) {
                            tabInfo.dataFormat = 'noDecimal';
                            tabInfo.title = "Calculation:\nDuplex Sheets x  Paper Cost Multiplier";
                            /* CALCULATION OF GRAPH DATA */
                            if (currUsageCU.length && colorPercentCU.length) {
                                self.currentUsageDUArr = [];
                                self.currentPercentDUArr = [];
                                self.targetAvgDUArr = [];
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    self.currentUsageDUArr.push({
                                        x: i,
                                        y: (currentUsageDU[i].rowValue !== '') ? parseInt(currentUsageDU[i].rowValue) / 1000 : 0
                                    });
                                    self.currentPercentDUArr.push({
                                        x: i,
                                        y: (currentPercentDU[i].rowValue !== '') ? parseFloat(currentPercentDU[i].rowValue * 100).toFixed(2) : 0
                                    });
                                    self.targetAvgDUArr.push({
                                        x: i,
                                        y: parseFloat(targetAvgDU).toFixed(2)
                                    });
                                }
                            }
                        }
                    });
                }
                /* SERVICE LEVEL LEFT SECTION DATA */
                if (tableInfo.RowHeader.toLowerCase() == 'Service Level Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Service Level";
                    var SL131Arr = [];
                    var SL132Arr = [];
                    var SL133Arr = [];
                    var SL134Arr = [];
                    var SL135Arr = [];
                    var SL136Arr = [];
                    var SL137Arr = [];
                    var SL138Arr = [];
                    var SL139Arr = [];
                    var SL140Arr = [];
                    var SL141Arr = [];
                    var SL142Arr = [];
                    var SL143Arr = [];
                    var SL144Arr = [];
                    var SL145Arr = [];
                    var SL146Arr = [];
                    var SL147Arr = [];
                    var SL148Arr = [];
                    var SL149Arr = [];
                    var SL150Arr = [];
                    var SL151Arr = [];
                    var SL152Arr = [];
                    var SL153Arr = [];
                    var SL154Arr = [];
                    var SL155Arr = [];
                    var SL156Arr = [];
                    self.keys = [];
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        if ([126, 127, 128, 129, 157, 165, 166].indexOf(tabInfo.RowID) !== -1) {
                            tabInfo.PDData = [];
                            tabInfo.RowName = 'duplicate';
                        } else {
                            if (!tabInfo.PDData.length)
                                for (var i = 0; i < self.range1.length; i++)
                                    tabInfo.PDData.push({ rowValue: "" });
                        }

                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Incident Categories'.toLowerCase()) {
                            tabInfo.RowName = 'Service Incident Categories';
                            tabInfo.colspan = 13;
                            tabInfo.dataFormat = 'string';
                        } else if (tabInfo.RowName.toLowerCase() === 'Defined Service Level Agreements'.toLowerCase()) {
                            tabInfo.RowName = 'Service Level Agreements (MISSED Count)';
                            tabInfo.colspan = 13;
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'Performance Uptime %'.toLowerCase()) {
                            tabInfo.title = "Calculation:\n\nPerformance Uptime Percentage = (Total Fleet Available Minutes – Downtime Minutes) / Total Fleet Available Minutes\n\nTotal Fleet Available Minutes  =  Number of Working Days in the Month  x  Contract Covered Minutes per Work Day  x  Number of Devices in the Fleet\n\nDowntime Minutes  =  (Number of Incidents  x  (Average Response Minutes  +  Average Repair Minutes))  +  Missed Response and Resolve Minutes\n\nMissed Response and Resolve Times:\nAll entries for 'Response Time Missed', 'Resolve Time Missed' and 'NBD Service Missed' are multiplied by the value entered in the cell just left of the row header and added to the down time. \n\nDefault Settings:  (These can be changed by clicking the 'Settings' button.)\nAverage Working Days Per Month = 20.8\nAverage Work Hours per Day = 9   (8am to 5pm)\nAverage Response Time = 3 hours   (180 Minutes)\nAverage Repair Time = 3 Hours   (180 Minutes)\nMinimum Accepted Performance Uptime = 95%\n\nNOTE 2:\nA blue font indicates an estimated value.  You may manually enter a different value.  In doing so the font will turn brown.  To re-enable the estimated calculation, delete the value in the appropriate cell.";
                            tabInfo.dataFormat = 'percent';
                            performanceUpT = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'Average "Call to Repair" Hours'.toLowerCase()) {
                            tabInfo.title = "Calculation:\n\nAverage Downtime Minutes  =  Average Response Minutes  +  Average Repair Minutes  +  (Missed Response and Resolve Minutes / Number of Incidents)\n\nMissed Response and Resolve Times:\nAll entries for 'Response Time Missed', 'Resolve Time Missed' and 'NBD Service Missed' are multiplied by the value entered in the cell just left of the row header and added to the down time. \n\nDefault Settings:  (These values can be changed by clicking the 'Settings' button.)\n    Average Response time = 3 hours  (180 minutes)\n    Average Repair time = 3 hours  (180 minutes)\n\nNOTE 1:\nA black font indicates an estimated value.  You may manually enter a different value.  In doing so the font will turn brown.  To re-enable the estimated calculation, delete the value in the appropriate cell.";
                            tabInfo.dataFormat = 'customNumberFloat';
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'Sevice Level Agreement Met %'.toLowerCase()) {
                            tabInfo.title = "Calculation:\n(1 - ((Next Business Day Service Missed Count + All Reponse Time Missed Counts) / Number of Supported Incidents)) x 100\n\nDefault Setting:  (This value can be changed by clicking the 'Settings' button.)\n   Minimum Accepted Response Time = 90%";
                            tabInfo.RowName = 'Service Level Agreement MET';
                            tabInfo.dataFormat = 'percent';
                            SLAMet = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'Proactive Call %'.toLowerCase()) {
                            tabInfo.dataFormat = 'percent';
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'Other Non-Calls (No Onsite Time)'.toLowerCase()) {
                            tabInfo.RowName = 'Reporting Times Missing (RTM)';
                        }
                        /* CALCULATION OF GRAPH DATA */
                        if (tabInfo.RowID === 131) {
                            SL131 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 132) {
                            SL132 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 133) {
                            SL133 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 134) {
                            SL134 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 135) {
                            SL135 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 136) {
                            SL136 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 137) {
                            SL137 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 138) {
                            SL138 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 139) {
                            SL139 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 140) {
                            SL140 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 141) {
                            SL141 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 142) {
                            SL142 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 143) {
                            SL143 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 144) {
                            SL144 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 145) {
                            SL145 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 146) {
                            SL146 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 147) {
                            SL147 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 148) {
                            SL148 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 149) {
                            SL149 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 150) {
                            SL150 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 151) {
                            SL151 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 152) {
                            SL152 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 153) {
                            SL153 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 154) {
                            SL154 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 155) {
                            SL155 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                        } else if (tabInfo.RowID === 156) {
                            SL156 = tabInfo.PDData;
                            self.keys.push(tabInfo.RowName);
                            self.SL131Arr = [];
                            self.SL132Arr = [];
                            self.SL133Arr = [];
                            self.SL134Arr = [];
                            self.SL135Arr = [];
                            self.SL136Arr = [];
                            self.SL137Arr = [];
                            self.SL138Arr = [];
                            self.SL139Arr = [];
                            self.SL140Arr = [];
                            self.SL141Arr = [];
                            self.SL142Arr = [];
                            self.SL143Arr = [];
                            self.SL144Arr = [];
                            self.SL145Arr = [];
                            self.SL146Arr = [];
                            self.SL147Arr = [];
                            self.SL148Arr = [];
                            self.SL149Arr = [];
                            self.SL150Arr = [];
                            self.SL151Arr = [];
                            self.SL152Arr = [];
                            self.SL153Arr = [];
                            self.SL154Arr = [];
                            self.SL155Arr = [];
                            self.SL156Arr = [];
                            self.performanceUpTArr = [];
                            self.SLAMetArr = [];
                            for (var i = 0; i < tabInfo.PDData.length; i++) {
                                self.ServiceIncOptionsBar.chart.xAxisLabels = self.range1;
                                self.performanceUpTArr.push({
                                    x: i,
                                    y: (performanceUpT[i].rowValue !== '') ? parseFloat(performanceUpT[i].rowValue * 100).toFixed(2) : 0
                                });
                                self.SLAMetArr.push({
                                    x: i,
                                    y: (SLAMet[i].rowValue !== '') ? parseFloat(SLAMet[i].rowValue * 100).toFixed(2) : 0
                                });
                                self.SL131Arr.push({
                                    x: i,
                                    y: (SL131[i].rowValue !== '') ? parseInt(SL131[i].rowValue) : 0
                                });
                                self.SL132Arr.push({
                                    x: i,
                                    y: (SL132[i].rowValue !== '') ? parseInt(SL132[i].rowValue) : 0
                                });
                                self.SL133Arr.push({
                                    x: i,
                                    y: (SL133[i].rowValue !== '') ? parseInt(SL133[i].rowValue) : 0
                                });
                                self.SL134Arr.push({
                                    x: i,
                                    y: (SL134[i].rowValue !== '') ? parseInt(SL134[i].rowValue) : 0
                                });
                                self.SL135Arr.push({
                                    x: i,
                                    y: (SL135[i].rowValue !== '') ? parseInt(SL135[i].rowValue) : 0
                                });
                                self.SL136Arr.push({
                                    x: i,
                                    y: (SL136[i].rowValue !== '') ? parseInt(SL136[i].rowValue) : 0
                                });
                                self.SL137Arr.push({
                                    x: i,
                                    y: (SL137[i].rowValue !== '') ? parseInt(SL137[i].rowValue) : 0
                                });
                                self.SL138Arr.push({
                                    x: i,
                                    y: (SL138[i].rowValue !== '') ? parseInt(SL138[i].rowValue) : 0
                                });
                                self.SL139Arr.push({
                                    x: i,
                                    y: (SL139[i].rowValue !== '') ? parseInt(SL139[i].rowValue) : 0
                                });
                                self.SL140Arr.push({
                                    x: i,
                                    y: (SL140[i].rowValue !== '') ? parseInt(SL140[i].rowValue) : 0
                                });
                                self.SL141Arr.push({
                                    x: i,
                                    y: (SL141[i].rowValue !== '') ? parseInt(SL141[i].rowValue) : 0
                                });
                                self.SL142Arr.push({
                                    x: i,
                                    y: (SL142[i].rowValue !== '') ? parseInt(SL142[i].rowValue) : 0
                                });
                                self.SL143Arr.push({
                                    x: i,
                                    y: (SL143[i].rowValue !== '') ? parseInt(SL143[i].rowValue) : 0
                                });
                                self.SL144Arr.push({
                                    x: i,
                                    y: (SL144[i].rowValue !== '') ? parseInt(SL144[i].rowValue) : 0
                                });
                                self.SL145Arr.push({
                                    x: i,
                                    y: (SL145[i].rowValue !== '') ? parseInt(SL145[i].rowValue) : 0
                                });
                                self.SL146Arr.push({
                                    x: i,
                                    y: (SL146[i].rowValue !== '') ? parseInt(SL146[i].rowValue) : 0
                                });
                                self.SL147Arr.push({
                                    x: i,
                                    y: (SL147[i].rowValue !== '') ? parseInt(SL147[i].rowValue) : 0
                                });
                                self.SL148Arr.push({
                                    x: i,
                                    y: (SL148[i].rowValue !== '') ? parseInt(SL148[i].rowValue) : 0
                                });
                                self.SL149Arr.push({
                                    x: i,
                                    y: (SL149[i].rowValue !== '') ? parseInt(SL149[i].rowValue) : 0
                                });
                                self.SL150Arr.push({
                                    x: i,
                                    y: (SL150[i].rowValue !== '') ? parseInt(SL150[i].rowValue) : 0
                                });
                                self.SL151Arr.push({
                                    x: i,
                                    y: (SL151[i].rowValue !== '') ? parseInt(SL151[i].rowValue) : 0
                                });
                                self.SL152Arr.push({
                                    x: i,
                                    y: (SL152[i].rowValue !== '') ? parseInt(SL152[i].rowValue) : 0
                                });
                                self.SL153Arr.push({
                                    x: i,
                                    y: (SL153[i].rowValue !== '') ? parseInt(SL153[i].rowValue) : 0
                                });
                                self.SL154Arr.push({
                                    x: i,
                                    y: (SL154[i].rowValue !== '') ? parseInt(SL154[i].rowValue) : 0
                                });
                                self.SL155Arr.push({
                                    x: i,
                                    y: (SL155[i].rowValue !== '') ? parseInt(SL155[i].rowValue) : 0
                                });
                                self.SL156Arr.push({
                                    x: i,
                                    y: (SL156[i].rowValue !== '') ? parseInt(SL156[i].rowValue) : 0
                                });
                            }
                        }

                    });
                }
                    /* TONER/INK TRACKING LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Toner Tracking'.toLowerCase()) {
                    tableInfo.RowHeader = "Toner/Ink Tracking";
                    var onTimeTarget = 0;
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Black Cartridges'.toLowerCase()) {
                            tabInfo.rowSpan = 6;
                            tabInfo.rowSpanFlag = true;
                        } else if (tabInfo.RowName.toLowerCase() === 'Accum. Black Cartridges'.toLowerCase()) {
                            tabInfo.rowSpan = 11;
                            tabInfo.rowSpanFlag = true;
                        } else if (tabInfo.RowName.toLowerCase() === 'Cartridge Replacements Missed'.toLowerCase()) {
                            tabInfo.rowSpan = 2;
                            tabInfo.rowSpanFlag = true;
                            onTimePercentTIT = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Total Cartridges Used'.toLowerCase()) {
                            tonerCUsed = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Total Cartridges Ordered'.toLowerCase()) {
                            tonerUsed = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Total Cartridges Returned'.toLowerCase()) {
                            tonerReceived = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Cumulative Inventory Deviation'.toLowerCase()) {
                            tonerDeviation = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'On Time Cartridge Replacement %'.toLowerCase()) {
                            tonerMissed = tabInfo.PDData;
                            onTimeTarget = parseFloat(result.RowValues.split(";")[0] * 100);
                            tabInfo.dataFormat = 'percent';
                        }
                        /* CALCULATION OF GRAPH DATA */
                        if (tonerUsed.length && tonerReceived.length && tonerDeviation.length && tonerCUsed.length && tonerMissed.length && onTimePercentTIT.length) {
                            self.tonerUsedArr = [];
                            self.tonerRecvdArr = [];
                            self.invDevArr = [];
                            self.tonerCUsedArr = [];
                            self.tonerMissedArr = [];
                            self.onTimePercentTITArr = [];
                            self.onTimeTarget = [];
                            self.maxvalueToner = [];
                            for (var i = 0; i < tabInfo.PDData.length; i++) {
                                self.maxvalueToner.push(tonerUsed[i].rowValue);
                                self.maxvalueToner.push(tonerReceived[i].rowValue);
                                self.maxvalueToner.push(tonerDeviation[i].rowValue);
                                self.tonerUsedArr.push({
                                    x: i,
                                    y: (tonerUsed[i].rowValue !== '') ? parseInt(tonerUsed[i].rowValue) * -1 : 0
                                });
                                self.tonerRecvdArr.push({
                                    x: i,
                                    y: (tonerReceived[i].rowValue !== '') ? parseInt(tonerReceived[i].rowValue) : 0
                                });
                                self.invDevArr.push({
                                    x: i,
                                    y: (tonerDeviation[i].rowValue !== '') ? parseInt(tonerDeviation[i].rowValue) : 0
                                });
                                self.tonerCUsedArr.push({
                                    x: i,
                                    y: (tonerCUsed[i].rowValue !== '') ? parseInt(tonerCUsed[i].rowValue) : 0
                                });
                                self.tonerMissedArr.push({
                                    x: i,
                                    y: (tonerMissed[i].rowValue !== '') ? parseInt(tonerMissed[i].rowValue) : 0
                                });
                                self.onTimePercentTITArr.push({
                                    x: i,
                                    y: (onTimePercentTIT[i].rowValue !== '') ? parseInt(onTimePercentTIT[i].rowValue) : 0
                                });
                                self.onTimeTarget.push({
                                    x: i,
                                    y: parseInt(onTimeTarget)
                                });
                            }
                        }
                    });
                }
                    /* OTHER CONSUMABLE TRACKING LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Other Consumables'.toLowerCase()) {
                    tableInfo.RowHeader = "Other Consumable Tracking";
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        tabInfo.classBold = true;
                        if (tabInfo.RowName.toLowerCase() === 'Staple Cartridges Used'.toLowerCase()) {
                            stapleUsed = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Staple Cartridges Ordered/Received'.toLowerCase()) {
                            stapleReceived = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Staple Cartridges - Inventory Deviation'.toLowerCase()) {
                            stapleDeviation = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Drums Used'.toLowerCase()) {
                            drumUsed = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Drums Ordered/Received'.toLowerCase()) {
                            drumReceived = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Drums - Inventory Deviation'.toLowerCase()) {
                            drumDeviation = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Reams of Paper Used'.toLowerCase()) {
                            bopUsed = tabInfo.PDData;
                            tabInfo.RowName = 'Boxes of Paper Used';
                        } else if (tabInfo.RowName.toLowerCase() === 'Reams of Paper Ordered/Received'.toLowerCase()) {
                            bopReceived = tabInfo.PDData;
                            tabInfo.RowName = 'Boxes of Paper Ordered/Received';
                        } else if (tabInfo.RowName.toLowerCase() === 'Boxes of Paper - Inventory Deviation'.toLowerCase()) {
                            bopDeviation = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Reams of Paper Returned'.toLowerCase()) {
                            tabInfo.RowName = 'Boxes of Paper Returned'
                        }
                        /* CALCULATION OF GRAPH DATA */
                        if (stapleUsed.length && stapleReceived.length && stapleDeviation.length &&
                            drumUsed.length && drumReceived.length && drumDeviation.length &&
                            bopUsed.length && bopReceived.length && bopDeviation.length) {
                            self.stapleUsedArr = [];
                            self.stapleReceivedArr = [];
                            self.stapleDeviationArr = [];
                            self.stapleDeviationTLArr = [];
                            self.stapleDeviationTLArr.push({
                                x: 0,
                                y: NaN
                            });
                            self.drumUsedArr = [];
                            self.drumReceivedArr = [];
                            self.drumDeviationArr = [];
                            self.drumDeviationTLArr = [];
                            self.drumDeviationTLArr.push({
                                x: 0,
                                y: NaN
                            });
                            self.bopUsedArr = [];
                            self.bopReceivedArr = [];
                            self.bopDeviationArr = [];
                            self.bopDeviationTLArr = [];
                            self.bopDeviationTLArr.push({
                                x: 0,
                                y: NaN
                            });
                            self.maxvalueStaple = [];
                            self.maxvalueDrum = [];
                            self.maxvalueBOP = [];
                            for (var i = 0; i < tabInfo.PDData.length; i++) {
                                self.maxvalueStaple.push(stapleUsed[i].rowValue);
                                self.maxvalueStaple.push(stapleReceived[i].rowValue);
                                self.maxvalueStaple.push(stapleDeviation[i].rowValue);
                                self.maxvalueDrum.push(drumUsed[i].rowValue);
                                self.maxvalueDrum.push(drumReceived[i].rowValue);
                                self.maxvalueDrum.push(drumDeviation[i].rowValue);
                                self.maxvalueBOP.push(bopUsed[i].rowValue);
                                self.maxvalueBOP.push(bopReceived[i].rowValue);
                                self.maxvalueBOP.push(bopDeviation[i].rowValue);
                                self.stapleUsedArr.push({
                                    x: i,
                                    y: (stapleUsed[i].rowValue !== '') ? parseInt(stapleUsed[i].rowValue) : 0
                                });
                                self.stapleReceivedArr.push({
                                    x: i,
                                    y: (stapleReceived[i].rowValue !== '') ? parseInt(stapleReceived[i].rowValue) : 0
                                });
                                self.stapleDeviationArr.push({
                                    x: i,
                                    y: (stapleDeviation[i].rowValue !== '') ? parseInt(stapleDeviation[i].rowValue) : 0
                                });
                                if (stapleDeviation[i + 1] !== undefined) {
                                    var st1 = (stapleDeviation[i].rowValue !== '') ? parseInt(stapleDeviation[i].rowValue) : 0;
                                    self.stapleDeviationTLArr.push({
                                        x: i + 1,
                                        y: (st1 + parseInt(stapleDeviation[i + 1].rowValue)) / 2
                                    });
                                }
                                self.drumUsedArr.push({
                                    x: i,
                                    y: (drumUsed[i].rowValue !== '') ? parseInt(drumUsed[i].rowValue) : 0
                                });
                                self.drumReceivedArr.push({
                                    x: i,
                                    y: (drumReceived[i].rowValue !== '') ? parseInt(drumReceived[i].rowValue) : 0
                                });
                                self.drumDeviationArr.push({
                                    x: i,
                                    y: (drumDeviation[i].rowValue !== '') ? parseInt(drumDeviation[i].rowValue) : 0
                                });
                                if (drumDeviation[i + 1] !== undefined) {
                                    var st1 = (drumDeviation[i].rowValue !== '') ? parseInt(drumDeviation[i].rowValue) : 0;
                                    self.drumDeviationTLArr.push({
                                        x: i + 1,
                                        y: (st1 + parseInt(drumDeviation[i + 1].rowValue)) / 2
                                    });
                                }
                                self.bopUsedArr.push({
                                    x: i,
                                    y: (bopUsed[i].rowValue !== '') ? parseInt(bopUsed[i].rowValue) : 0
                                });
                                self.bopReceivedArr.push({
                                    x: i,
                                    y: (bopReceived[i].rowValue !== '') ? parseInt(bopReceived[i].rowValue) : 0
                                });
                                self.bopDeviationArr.push({
                                    x: i,
                                    y: (bopDeviation[i].rowValue !== '') ? parseInt(bopDeviation[i].rowValue) : 0
                                });
                                if (bopDeviation[i + 1] !== undefined) {
                                    var st1 = (bopDeviation[i].rowValue !== '') ? parseInt(bopDeviation[i].rowValue) : 0;
                                    self.bopDeviationTLArr.push({
                                        x: i + 1,
                                        y: (st1 + parseInt(bopDeviation[i + 1].rowValue)) / 2
                                    });
                                }
                            }
                        }
                    })
                }
                    /* DEVICE TRACKING & DEPLOYMENT LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Device Tracking & Deployment Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Device Tracking & Deployment";
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        if ([248, 249].indexOf(tabInfo.RowID) !== -1) {
                            tabInfo.PDData = [];
                            tabInfo.RowName = 'duplicate';
                        }
                        tabInfo.dataFormat = 'customNumber';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        tabInfo.classBold = true;
                        if (tabInfo.RowName.toLowerCase() === 'New Devices Installed (Projected)'.toLowerCase()) {
                            deviceProjected = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'New Devices Installed (Actual)'.toLowerCase()) {
                            deviceActual = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'New Sites Deployed (Projected)'.toLowerCase()) {
                            siteProjected = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'New Sites Deployed (Actual)'.toLowerCase()) {
                            siteActual = tabInfo.PDData;
                            /* CALCULATION OF GRAPH DATA */
                            if (deviceProjected.length && deviceActual.length && siteProjected.length && siteActual.length) {
                                self.deviceProjectedArr = [];
                                self.deviceActualArr = [];
                                self.siteProjectedArr = [];
                                self.siteActualeArr = [];
                                self.maxvalueBardevicetracking = [];
                                self.maxvalueBarsiteTracking = [];
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    self.maxvalueBardevicetracking.push(deviceProjected[i].rowValue);
                                    self.maxvalueBardevicetracking.push(deviceActual[i].rowValue);
                                    self.maxvalueBarsiteTracking.push(siteProjected[i].rowValue);
                                    self.maxvalueBarsiteTracking.push(siteActual[i].rowValue);
                                    self.DeviceTrackingOptionsBar.chart.xAxisLabels = self.range1;
                                    self.siteTrackingOptionsBar.chart.xAxisLabels = self.range1;
                                    self.deviceProjectedArr.push({
                                        x: i,
                                        y: (deviceProjected[i].rowValue !== '') ? parseInt(deviceProjected[i].rowValue) : 0
                                    });
                                    self.deviceActualArr.push({
                                        x: i,
                                        y: (deviceActual[i].rowValue !== '') ? parseInt(deviceActual[i].rowValue) : 0
                                    });
                                    self.siteProjectedArr.push({
                                        x: i,
                                        y: (siteProjected[i].rowValue) ? parseInt(siteProjected[i].rowValue) : 0
                                    });
                                    self.siteActualeArr.push({
                                        x: i,
                                        y: (siteActual[i].rowValue !== '') ? parseInt(siteActual[i].rowValue) : 0
                                    });
                                }
                            }
                        }
                    });
                }
                    /* NRD LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'NRD Section'.toLowerCase()) {
                    tableInfo.RowHeader = "NRD Summary";

                    var totalDevicesMonth = [];
                    var totalDevicesNRD = [];
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        if ([265, 266, 267].indexOf(tabInfo.RowID) !== -1) {
                            tabInfo.PDData = [];
                            tabInfo.RowName = 'duplicate';
                        }
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        tabInfo.classBold = true;
                        tabInfo.classRed = false;
                        if (tabInfo.RowName.toLowerCase() === 'Invoiced Devices - Not Reporting'.toLowerCase()) {
                            tabInfo.RowName = 'Total Non-Reporting Devices (NRD)';
                            totalDevicesNRD = tabInfo.PDData;
                        } else if (tabInfo.RowName.trim().toLowerCase() === '- Devices in Storage'.toLowerCase()) {
                            NRDDeviceStorage = tabInfo.PDData;
                        } else if (tabInfo.RowName.trim().toLowerCase() === '- Non-Networked Devices'.toLowerCase()) {
                            tabInfo.RowName = '- Non-Networked Devices (Local)';
                            NRDNonNW = tabInfo.PDData;
                        } else if (tabInfo.RowName.trim().toLowerCase() === '- Other known NRDs'.toLowerCase()) {
                            NRDOtherKnown = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Total Non-Reporting Devices (NRD)'.toLowerCase()) {
                            tabInfo.RowName = 'Adjusted Non-Reporting Devices (NRD)';
                            tabInfo.classRed = true;
                            totalDevicesMonth = tabInfo.PDData;
                        } else if (tabInfo.RowName.trim().toLowerCase() === 'Non-Reporting Devices (30 Days)'.toLowerCase()) {
                            tabInfo.RowName = 'Non-Reporting Devices (1 Month)';
                            tabInfo.classRed = true;
                            NRDm1 = tabInfo.PDData;
                        } else if (tabInfo.RowName.trim().toLowerCase() === 'Non-Reporting Devices (60 Days)'.toLowerCase()) {
                            tabInfo.RowName = 'Non-Reporting Devices (2 Month)';
                            tabInfo.classRed = true;
                            NRDm2 = tabInfo.PDData;
                        } else if (tabInfo.RowName.trim().toLowerCase() === 'Non-Reporting Devices (>90 Days)'.toLowerCase()) {
                            tabInfo.RowName = 'Non-Reporting Devices (3 Month +)';
                            tabInfo.classRed = true;
                            NRDm3 = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Non-Reporting Devices %'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Total NRDs / Number of Devices Invoiced ) x 100";
                            tabInfo.dataFormat = 'percent';
                            tabInfo.classBold = false;
                            /* CALCULATION OF GRAPH DATA */
                            if (NRDm1.length && NRDm2.length && NRDm3.length && NRDNonNW.length && NRDOtherKnown.length && NRDDeviceStorage.length) {
                                self.NRDm1Arr = [];
                                self.NRDm2Arr = [];
                                self.NRDm3Arr = [];
                                self.NRDDeviceStorageArr = [];
                                self.NRDNonNWArr = [];
                                self.NRDOtherKnownArr = [];
                                self.maxvalueBarMonthNRD = [];
                                self.maxvaluetotalDevicesNRD = [];
                                monthTotal = 0;
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    self.maxvalueBarMonthNRD.push(totalDevicesMonth[i].rowValue);
                                    self.maxvaluetotalDevicesNRD.push(NRDNonNW[i].rowValue);
                                    self.maxvaluetotalDevicesNRD.push(NRDOtherKnown[i].rowValue);
                                    self.maxvaluetotalDevicesNRD.push(NRDDeviceStorage[i].rowValue);
                                    self.NRDMonthOptionsBar.chart.xAxisLabels = self.range1;
                                    self.NRDm1Arr.push({
                                        x: i,
                                        y: (NRDm1[i].rowValue !== '') ? parseInt(NRDm1[i].rowValue) : 0
                                    });
                                    self.NRDm2Arr.push({
                                        x: i,
                                        y: (NRDm2[i].rowValue !== '') ? parseInt(NRDm2[i].rowValue) : 0
                                    });
                                    self.NRDm3Arr.push({
                                        x: i,
                                        y: (NRDm3[i].rowValue) ? parseInt(NRDm3[i].rowValue) : 0
                                    });
                                    self.NRDNonNWArr.push({
                                        x: i,
                                        y: (NRDNonNW[i].rowValue !== '') ? parseInt(NRDNonNW[i].rowValue) : 0
                                    });
                                    self.NRDOtherKnownArr.push({
                                        x: i,
                                        y: (NRDOtherKnown[i].rowValue !== '') ? parseInt(NRDOtherKnown[i].rowValue) : 0
                                    });
                                    self.NRDDeviceStorageArr.push({
                                        x: i,
                                        y: (NRDDeviceStorage[i].rowValue) ? parseInt(NRDDeviceStorage[i].rowValue) : 0
                                    });
                                }
                            }
                        }
                    });
                }
                    /* NID LEFT SECTION SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'NID Section'.toLowerCase()) {
                    tableInfo.RowHeader = "NID Summary";
                    var totalDevices = [];
                    self.NIDDataBar = [];
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                        if ([277, 276].indexOf(tabInfo.RowID) !== -1) {
                            tabInfo.PDData = [];
                            tabInfo.RowName = 'duplicate';
                        }
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Non-Invoiced Devices Reporting (NID)'.toLowerCase()) {
                            tabInfo.RowName = 'Total Non-Invoiced Devices (NID)';
                            tabInfo.classBold = true;
                            totalDevices = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === '- Non-Invoiced, New Devices Reporting'.toLowerCase()) {
                            tabInfo.RowName = '- Non-Invoiced, Newly Installed Devices';
                            tabInfo.classBold = true;
                            NIDNewly = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === '- Marked Exceptions'.toLowerCase()) {
                            tabInfo.RowName = '- Marked Exceptions (Ignored)';
                            tabInfo.classBold = true;
                            NIDME = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Adjusted NID Reporting'.toLowerCase()) {
                            tabInfo.RowName = 'Adjusted Non-Invoiced Devices (NID)';
                            tabInfo.classBold = true;
                            tabInfo.classRed = true;
                            NIDAdjusted = tabInfo.PDData;
                        } else if (tabInfo.RowName.toLowerCase() === 'Non-Invoiced Devices Reporting %'.toLowerCase()) {
                            tabInfo.title = "Calculation: \n(Total NID Reporting / All Reporting Devices) x 100";
                            tabInfo.dataFormat = 'percent';
                            /* CALCULATION OF GRAPH DATA */
                            if (NIDNewly.length && NIDME.length && NIDAdjusted.length) {
                                self.NIDNewlyArr = [];
                                self.NIDMEArr = [];
                                self.NIDAdjustedArr = [];
                                var maxvalueBar = 0;
                                var maxvalueline = 0;
                                monthTotal = 0;
                                for (var i = 0; i < tabInfo.PDData.length; i++) {
                                    if (parseFloat(maxvalueBar) < parseFloat(totalDevices[i].rowValue))
                                        maxvalueBar = totalDevices[i].rowValue;
                                    self.NIDOptionsBar.chart.xAxisLabels = self.range1;
                                    self.NIDNewlyArr.push({
                                        x: i,
                                        y: (NIDNewly[i].rowValue !== '') ? parseInt(NIDNewly[i].rowValue) : 0
                                    });
                                    self.NIDMEArr.push({
                                        x: i,
                                        y: (NIDME[i].rowValue !== '') ? parseInt(NIDME[i].rowValue) : 0
                                    });
                                    self.NIDAdjustedArr.push({
                                        x: i,
                                        y: (NIDAdjusted[i].rowValue) ? parseInt(NIDAdjusted[i].rowValue) : 0
                                    });
                                }
                                self.NIDOptionsBar.chart.yDomain = [0, parseInt(maxvalueBar) + 10];
                            }
                        }
                    });
                }
                    /* INDUSTRY ANALYSIS DATA POINTS(RM REPORTED VALUES) LEFT SECTION DATA */
                else if (tableInfo.RowHeader.toLowerCase() == 'Industry Analysis Section'.toLowerCase()) {
                    tableInfo.RowHeader = "Industry Analysis Data Points(RM Reported Values)";
                    /* APPLY PROPER TITLE, ROWNAME, DATAFORMAT  */
                    angular.forEach(tableInfo.tabInfo, function (tabInfo) {
                        tabInfo.dataFormat = 'noPercent';
                        var result = _.findWhere(tableInfo.Summary, { RowID: tabInfo.RowID });
                        tabInfo.summary = result.RowValues;
                        if (tabInfo.RowName.toLowerCase() === 'Total Mono Pages (Mono Devices)'.toLowerCase()) {
                            tabInfo.title = "Total Mono Pages includes Accent Color Pages.";
                        } else if (tabInfo.RowName.toLowerCase() === 'Total Color Pages (Color Devices)'.toLowerCase()) {
                            tabInfo.title = "Total Color Pages includes Color Professional Pages.";
                        } else if (tabInfo.RowName.toLowerCase() === 'Total Color Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Mono Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Target Revenue'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Mono Click Charges (All Devices)'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Mono Click Charges (Mono Devices)'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Mono Click Charges (Color Devices)'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Color Click Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Base Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Color Accent Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJetBaseCharges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJet Mono/Color Accent Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJet Color Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJet Color Pro Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Color Professional Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Color Base Charges'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Total Mono + Color Accent Charges'.toLowerCase()) {
                            tabInfo.dataFormat = 'noDecimal';
                        }
                        else if (tabInfo.RowName.toLowerCase() === 'Avg. Mono Click Charge (All Devices)'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Avg. Mono Click Charge (Mono Devices)'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Avg. Mono Click Charge (Color Devices)'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Avg. Color Click Charge'.toLowerCase()) {
                            tabInfo.dataFormat = 'decimal';
                        } else if (tabInfo.RowName.toLowerCase().trim() === '% Target Revenue Realized'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase().trim() === '1st Visit Conpletion %'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase().trim() === 'Rerepaired in 30 Days %'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase().trim() === 'HP CE - SLA Met %'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase().trim() === 'Service Partner - SLA Met %'.toLowerCase()) {
                            tabInfo.dataFormat = 'percentNoColor';
                        } else if (tabInfo.RowName.toLowerCase().trim() === 'Top Service Issue'.toLowerCase()) {
                            tabInfo.dataFormat = 'string';
                        } else if (tabInfo.RowName.toLowerCase() === 'Color LaserJet Count'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJet Mono/Color Accent Pages'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJet Color Pages'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Color LaserJet Color Pro Pages'.toLowerCase()) {
                            tabInfo.dataFormat = 'customNumber';
                        } else if (tabInfo.RowName.toLowerCase() === 'Call to Onsite hours'.toLowerCase() ||
                            tabInfo.RowName.toLowerCase() === 'Call to Repair hours'.toLowerCase()) {
                            tabInfo.dataFormat = 'customNumberFloat';
                        }
                    });
                }
            });
            self.tableInfo = self.JSONData;
        }
        //$http.get('public/js/json/performance/performance-dashboard.json').then(function (response) {
         performanceDashboardServices.postPDInfoData(shareUser.get()).then(function (response) {
            calculateData(response);
            calculateAllData();
        });
        $rootScope.updatePD = function (response) {
            console.log(response);
            calculateData(response);
            calculateAllData();
        }
        var calculateAllData = function () {
            /* TOTAL NO OF DISPLAY MONTHS AND DISPLAY RANGE IN UI*/
            self.arrayLength = self.range1.length - parseInt(self.sliderRange);
            self.arrayLength = (self.arrayLength > 13) ? 13 : self.arrayLength;
            self.displayMonth = self.totalMonth - parseInt(self.sliderRange);
            self.displayMonth = (self.displayMonth > 12) ? 12 : self.displayMonth;
            self.displayRange = parseInt(self.arrayLength) + parseInt(self.sliderRange);
            displayGraphs(false);
        }
        /* ----------------------------------------------- */
        /* DATA SLIDER */
        /* ----------------------------------------------- */
        self.slideTable = function () {
            if (!self.pageLoad) {
                var param = {};
                param.strRollingviewIndex = self.sliderRange;
                param.PDUsers = shareUser.get();
                performanceDashboardServices.postPDUpdateView(param).then(function (response) {
                    calculateData(response);
                    calculateAllData();
                });
            } else {
                self.pageLoad = false;
            }
        };

        /* ----------------------------------------------- */
        /* HIGHLIGHT TABLE ON SELECT RANGE */
        /* ----------------------------------------------- */
        self.highlightTable = function () {
            angular.element(".lotr").addClass("shaded");
            angular.element(".otr table tr th").removeClass("selected_heading");
            angular.element(".ltco").addClass("shaded");
            angular.element(".tco table tr th").removeClass("selected_heading");
            self.displayMonth = parseInt(self.selected2) - parseInt(self.selected1) + 1
            for (i = (parseInt(self.selected1) - parseInt(self.sliderRange)) + 1 ; i <= (parseInt(self.selected2) - parseInt(self.sliderRange)) + 1; i++) {
                angular.element(".lotr:nth-child(" + i + ")").removeClass("shaded");
                angular.element(".otr table tr th:nth-child(" + i + ")").addClass("selected_heading");
            }
            for (i = (parseInt(self.selected1) - parseInt(self.sliderRange)) + 1 ; i <= (parseInt(self.selected2) - parseInt(self.sliderRange)) + 1; i++) {
                var newI = i;
                /* CHECK FOR CLICK ARREARS, IF TRUE TCO SECTION WILL SELECT ONE MONTH AHEAD*/
                if (self.IsClickOnlyArrears.toLowerCase() === 'true')
                    newI = i + 1;
                if (angular.element(".tco table tr th:nth-child(" + newI + ")")[0].innerHTML.indexOf("-") !== -1) {
                    angular.element(".ltco:nth-child(" + newI + ")").removeClass("shaded");
                    angular.element(".tco table tr th:nth-child(" + newI + ")").addClass("selected_heading");
                }
            }
        };
        /* ----------------------------------------------- */
        /* SET AND RESET SELECTED RANGE */
        /* ----------------------------------------------- */
        self.setRange = function () {
            /* CALL API FOR SELECT RANGE WITH SELECT MONTH DISPLAY INDEX*/
            if (self.selected1 !== '' && self.selected2 !== '') {
                if ((self.selected2 - self.selected1) < 0) {
                    alert("To value should be greater than from value");
                } else {
                    var param = {};
                    var startMonth = self.range1[parseInt(self.selected1)].MonthYear;
                    var endMonth = self.range1[parseInt(self.selected2)].MonthYear;
                    for (var i = 0; i < self.item2Data.length; i++) {
                        if (self.item2Data[i].MonthYear === startMonth)
                            param.startMonth = i;
                        if (self.item2Data[i].MonthYear === endMonth)
                            param.endMonth = i;
                    }
                    param.PDUsers = shareUser.get();
                    performanceDashboardServices.postPDSelectRangeData(param).then(function (response) {
                        calculateData(response);
                        calculateAllData();
                        self.setSelected = true;
                        $timeout(function () {
                            self.highlightTable();
                        }, 1000)

                    });
                }
            }
        }
        self.resetSelect = function () {
            var param = {};
            param.PDUsers = shareUser.get();
            performanceDashboardServices.postPDResetRangeData(param).then(function (response) {
                self.selected1 = '';
                self.selected2 = '';
                angular.element(".otr table tr td").removeClass("shaded");
                angular.element(".otr table tr th").removeClass("selected_heading");
                angular.element(".tco table tr td").removeClass("shaded");
                angular.element(".tco table tr th").removeClass("selected_heading");
                self.setSelected = false;
                calculateData(response);
                calculateAllData();
            });
        };
        /* ----------------------------------------------- */
        /* CHECK BOX SELECTION ON SERVICE LEVEL SCRUBBER CHANGES */
        /* ----------------------------------------------- */
        self.eventChange = function (val) {
            var param = {};
            param.ServiceScrubber = val;
            param.PDUsers = shareUser.get();
            if (val === 'onsite')
                param.selected = self.evntChk1;
            else
                param.selected = self.evntChk;

            performanceDashboardServices.postPDUpdateServiceScrubber(param).then(function (response) {
                calculateData(response);
                calculateAllData();
            })
        }
        /* ----------------------------------------------- */
        /* CLEAR SERVICE LEVEL SECTION DATA */
        /* ----------------------------------------------- */
        self.clearServiceData = function () {
            var confirmClear = confirm("Manually entered data cannot be recovered. Do you want to continue?")
            if (confirmClear) {
                var param = {};
                param.PDUsers = shareUser.get();
                performanceDashboardServices.postPDClearServiceData(param).then(function (response) {
                    calculateData(response);
                    calculateAllData();
                })
            }
        }
        /* TOTAL COST OF OWNERSHIP GRAPH OPTIONS */
        self.optionsTotalCostOwernership = {
            chart: {
                type: 'multiChart',
                height: 450,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                legendRightAxisHint: "",
                y2AxisLabels: ["Baseline (Blended CPP prior to HP Fleet)", "Blended Cost Per Page (All Devices)"],
                reduceXTicks: false,
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsTotalCostOwernership.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'Invoice Amount(Thousands)',
                    stroke: 'black',
                    showMaxMin: true,
                    tickFormat: function (d) {
                        return self.currSymbol + d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    axisLabel: 'Blended Cost Per Page',
                    showMaxMin: true,
                    tickFormat: function (d) {
                        return self.currSymbol + d3.format(',.5f')(d);
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + self.currSymbol  + $filter('currency')(d.data.y * 1000,'', 0);
                        else
                            return 'Series" ' + self.optionsTotalCostOwernership.chart.y2AxisLabels[d.point.series] + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.point.x].MonthYear + '"\n<br> Value: ' + self.currSymbol  + $filter('currency')(d.point.y,'', 5);
                    }
                }
            }
        };
        /* CAPACITIES & UTILIZATION GRAPH OPTIONS */
        self.optionsCUPie = {
            chart: {
                type: 'pieChart',
                height: 500,
                x: function (d) {
                    return d.value;
                },
                y: function (d) {
                    return d.y;
                },
                showLabels: true,
                color: ['#585858', '#EE6612', '#BDBDBD', '#ED9C00'],
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: true,
                labelType: function (d) {
                    return d3.format(',f')(d.value) + "(" + d3.format(',f')(d.value * 100 / d.data.key) + ")%";
                },
                legend: {
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "Pages Printed" Point "' + d.data.value + '"\n<br> Value: ' + $filter('number')(d.data.y, 0) + "(" + $filter('number')(d.data.y * 100 / d.data.key, 0) + "%)";
                    }
                },
                legend: {
                    margin: {
                        top: 5,
                        right: 35,
                        bottom: 5,
                        left: 0
                    }
                }
            }
        };
        self.optionsCUStacked = {
            chart: {
                type: 'multiBarChart',
                height: 450,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 45,
                    left: 45
                },
                yAxis: {
                    axisLabel: 'Entire Customer Fleet',
                    axisLabelDistance: -70,
                    tickFormat: function (d) {
                        return '';
                    }
                },
                clipEdge: false,
                showControls: false,
                duration: 500,
                stacked: true,
                showYAxis: true,
                showXAxis: false,
                groupSpacing: 0.3,
                legend: {
                    updateState: false
                },
                color: ["#E0AD23", "#05B453", "#D8D71C"],
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "' + d.data.key + '" Point "Over Utilized" <br> Value: ' + $filter('number')(d.data.y, 2) + "%";
                    }
                },
                callback: setStackBarCaption,
                dispatch: {
                    renderEnd: function () {
                        setStackBarCaption()
                    }
                }
            }
        };
        self.optionsAverageFleetBar = {
            chart: {
                type: 'multiBarChart',
                xAxisLabels: ["Entire Fleet", "Mono Printers", "Color Printers", "Mono MFPs", "Color MFPs"],
                height: 450,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 45,
                    left: 45
                },
                clipEdge: false,
                showControls: false,
                duration: 500,
                stacked: false,
                groupSpacing: 0.5,
                showLegend: false,
                yDomain: [0, 100],
                reduceXTicks: false,
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    rotateLabels: 5,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsAverageFleetBar.chart.xAxisLabels[index];
                        } else {
                            return index;
                        }
                    }
                },
                yAxis: {
                    axisLabel: 'Utilization %',
                    axisLabelDistance: -20,
                    tickValues: [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
                    tickFormat: function (d) {
                        return d3.format(',f')(d) + "%";
                    }
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "' + d.data.key + '" Point "' + $filter('number')(d.data.x+1) + '" <br> Value: ' + $filter('number')(d.data.y, 2) + "%";
                    }
                }
            }
        };
        var setStackBarCaption = function () {
            d3.selectAll('.averageFleetgraph .nv-multibar .nv-group').each(function (group) {
                var g = d3.select(this);
                g.selectAll('text').remove();
                g.selectAll('.nv-bar').each(function (bar) {
                    var b = d3.select(this);
                    var barWidth = b.attr('width');
                    var barHeight = b.attr('height');
                    g.append('text')
                      .attr('transform', b.attr('transform'))
                      .text(function () {
                          if (bar.y === 0) {
                              return;
                          }
                          return parseFloat(bar.y).toFixed(2) + '%';
                      })
                      .attr('y', function () {
                          var height = this.getBBox().height;
                          if ((parseFloat(barHeight) / 2) - (height / 2) < 16)
                              return parseFloat(b.attr('y')) + 5; // 15 is the label's margin from the top of bar
                          return parseFloat(b.attr('y')) + (parseFloat(barHeight) / 2) - (height / 2);
                      })
                      .attr('x', function () {
                          var width = this.getBBox().width;
                          return parseFloat(b.attr('x')) + (parseFloat(barWidth) / 2) - (width / 2);
                      })
                      .style("stroke-opacity", "0")
                      .style('fill', 'black');
                });
            });
        }
        /* DEVICE CATEGORY SUMMARY GRAPH OPTIONS */
        self.optionsDCPie = {
            chart: {
                type: 'pieChart',
                height: 500,
                x: function (d) {
                    return d.value;
                },
                y: function (d) {
                    return d.y;
                },
                showLabels: true,
                color: ['#585858', '#EE6612', '#BDBDBD', '#ED9C00'],
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: true,
                labelType: function (d) {
                    return d3.format(',f')(d.value * 100 / d.data.key) + "%";
                },
                legend: {
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series 1 Point "' + d.data.value + '"\n<br> Value: ' + $filter('number')(d.data.y, 0) + "(" + $filter('number')(d.data.y * 100 / d.data.key, 0) + "%)";
                    }
                },
                legend: {
                    margin: {
                        top: 5,
                        right: 35,
                        bottom: 5,
                        left: 0
                    }
                }
            }
        };
        var optionsDCCircular = {
            chart: {
                type: 'pieChart',
                height: 150,
                x: function (d) { return d3.format(',f')(d.y * 100 / d.y2) + "%"; },
                showLegend: false,
                showLabels: true,
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: false,
                donutLabelsOutside: true,
                donutRatio: 0.6,
                donut: true,
                margin: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series 1 Point "' + d.data.key + '"\n<br> Value: ' + $filter('number')(d.data.y, 0) + "(" + $filter('number')(d.data.y * 100 / d.data.y2, 0) + "%)";
                    }
                }
            }
        };
        self.optionsDCMonoPrint = angular.copy(optionsDCCircular);
        self.optionsDCMonoPrint.chart.title = 'HP Mono Printers';
        self.optionsDCMonoPrint.chart.color = ['#585858', '#d62728'];
        self.optionsDCMonoMFP = angular.copy(optionsDCCircular);
        self.optionsDCMonoMFP.chart.title = 'HP Mono MFPs';
        self.optionsDCMonoMFP.chart.color = ['#BDBDBD', '#d62728'];
        self.optionsDCColorPrint = angular.copy(optionsDCCircular);
        self.optionsDCColorPrint.chart.title = 'HP Color Printers';
        self.optionsDCColorPrint.chart.color = ['#EE6612', '#d62728'];
        self.optionsDCColorMFP = angular.copy(optionsDCCircular);
        self.optionsDCColorMFP.chart.title = 'HP Color MFPs';
        self.optionsDCColorMFP.chart.color = ['#ED9C00', '#d62728'];
        self.optionsDCHorizontalBar = {
            chart: {
                type: 'multiBarHorizontalChart',
                height: 450,
                width: 500,
                x: function (d) {
                    return d.label;
                },
                y: function (d) {
                    return d.value;
                },
                showControls: false,
                showValues: true,
                showLegend: true,
                duration: 500,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 40,
                    left: 120
                },
                xAxis: {
                    showMaxMin: false,
                    rotateYLabel: true,
                    orient: 'left',
                    css: {
                        'transform': 'rotate(45deg)'
                    }
                },
                yAxis: {
                    axisLabel: 'Number Of Devices',
                    tickFormat: function (d) {
                        return d3.format(',f')(d * 100) + "%";
                    }
                },
                valueFormat: function (d) {
                    return d3.format(',f')(d * 100) + "%";
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "' + d.data.key + '" Point "' + d.data.label + '" <br> Value: ' + $filter('number')(d.data.value * 100, 2) + "%";
                    }
                }
            }
        };
        d3.select(".DChorizontalGraph .nv-x").select(".nvd3").select("text").attr("transform", "rotate(45)");
        /* COLOR DEVICE USAGE GRAPH OPTIONS */
        self.optionsColorUsageCD = {
            chart: {
                type: 'multiChart',
                height: 350,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                reduceXTicks: false,
                legendRightAxisHint: "",
                y2AxisLabels: ["Color Percentage", "Color average", "Target average"],
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsTotalCostOwernership.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'Color Pages(Thousands)',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d) + "%";
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined) {
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.data.y * 1000, '', 0);
                        } else if (d.series[0].key === "Color Percentage" || d.series[0].key === "Color Average" || d.series[0].key === "Target Average") {
                            return 'Series" ' + d.series[0].key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.pointIndex].MonthYear + '"\n<br> Value: ' + $filter('number')(d.series[0].value, 1) + '%';
                        } else {
                            return 'Series" ' + self.optionsColorUsageCD.chart.y2AxisLabels[d.point.series] + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.point.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.point.y, '',5);
                        }
                    }
                }
            }
        };
        self.optionsCDPie = {
            chart: {
                type: 'pieChart',
                height: 300,
                x: function (d) {
                    return d.value;
                },
                y: function (d) {
                    return d.y;
                },
                showLabels: true,
                color: ['#0097FB', '#7E7E7E', '#B3B6BE'],
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: true,
                labelType: function (d) {
                    return d3.format(',.1f')(d.value) + "%";
                },
                legend: {
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "Pages Printed" Point "' + d.data.value + '"\n<br> Value: ' + $filter('number')(d.data.y,1) + "(" + $filter('number')(d.data.y,0) + "%)";
                    }
                }
            }
        };
        self.optionsCDPie2 = angular.copy(self.optionsCDPie);
        self.optionsCDPie2.showLegend = false;

        var chart;
        self.optionEstimatedCU = {
            chart: {
                type: 'multiChart',
                height: 350,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                reduceXTicks: false,
                legendRightAxisHint: "",
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: true,
                    axisLabel: 'Target Percentages',
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.estimatedSavingXAxisCU[index] + "%";
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'Color Pages(Thousands)',
                    showMaxMin: true,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    axisLabel: 'Estimated Savings',
                    showMaxMin: true,
                    tickFormat: function (d) {
                        return self.currSymbol + d3.format(',f')(d);
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.series[0].color === 'green')
                            return 'Series "' + d.series[0].key + '" Point "' + self.estimatedSavingXAxisCU[d.point.x] + '%"\n<br> value:' +self.currSymbol+ $filter('currency')(d.point.y,'', 0) + '';
                        else
                            return 'Series "' + d.series[0].key + '" Point "' + self.estimatedSavingXAxisCU[d.point.x] + '%"\n<br> value:' + $filter('number')(d.point.y*1000, 0) + '';
                    }
                },
                callback: highlightPointsCD,
                dispatch: {
                    renderEnd: function () {
                        highlightPointsCD(chart)
                    }
                }
            }
        };
        $scope.onReady = function (scope, el) {
            chartCD = scope.chart;
        }
        function highlightPointsCD(chart, data) {
            var data = self.dataEstimatedGraph
            var points = d3.select('.estimatedGraph .nv-groups')
                .selectAll("rect.myPoint")
                .data(data[0].values.filter(function (d) { return d.y; }));
            if (data[2] !== undefined)
            var points1 = d3.select('.estimatedGraph .nv-groups')
                .selectAll("circle.myPoint")
                .data(data[2].values.filter(function (d) { return d.y; }));

            var points2 = d3.select('.estimatedGraph .nv-groups')
                .selectAll("circle.myPoint")
                .data(data[1].values.filter(function (d) { return d.y; }));

            points.enter().append("rect")
                .attr("class", "myPoint")
                .attr("x", function (d) { return chart.xAxis.scale()(d.x) - 4; })
                .attr("y", function (d) { return chart.yAxis1.scale()(d.y) - 4; })
                .attr("width", 8)
                .attr("height", 8)
                .attr("fill", "#B07E7D");
            if (data[2] !== undefined)
            points1.enter().append("circle")
                .attr("class", "myPoint")
                .attr("cx", function (d) { return chart.xAxis.scale()(d.x); })
                .attr("cy", function (d) { return chart.yAxis2.scale()(d.y); })
                .attr("r", 10)
                .attr("fill-opacity", "0")
                .attr("stroke", "#84A95B")
                .attr("stroke-width", "3");

            points2.enter().append("circle")
                .attr("class", "myPoint")
                .attr("cx", function (d) { return chart.xAxis.scale()(d.x); })
                .attr("cy", function (d) { return chart.yAxis2.scale()(d.y); })
                .attr("r", 5)
                .attr("fill", "#ABB0A4");
        }
        /* MONO PAGES ON COLOR DEVICES GRAPH OPTIONS */
        self.optionsMonoUsageMD = {
            chart: {
                type: 'multiChart',
                height: 350,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                yDomain2:[0,100],
                reduceXTicks: false,
                legendRightAxisHint: "",
                y2AxisLabels: ["MPoCD Percentage", "Current average", "Target average"],
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsTotalCostOwernership.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'MP on CD(Thousands)',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d) + "%";
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' +self.currSymbol+ $filter('currency')(d.data.y * 1000,'',  0);
                        else if (d.series[0].key === "MPoCD Percentage" || d.series[0].key === "Current Average" || d.series[0].key === "Target Average")
                            return 'Series" ' + d.series[0].key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.pointIndex].MonthYear + '"\n<br> Value: ' + $filter('number')(d.series[0].value, 1) + '%';
                        else
                            return 'Series" ' + self.optionsMonoUsageMD.chart.y2AxisLabels[d.point.series] + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.point.x].MonthYear + '"\n<br> Value: ' + self.currSymbol +$filter('currency')(d.point.y, '',5);
                    }
                }
            }
        };

        self.optionEstimatedMPoCD = {
            chart: {
                type: 'multiChart',
                height: 450,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                reduceXTicks: false,
                legendRightAxisHint: "",
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    axisLabel: 'Target Percentages',
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.estimatedSavingXAxisMono[index] + "%";
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'MPoCD(Thousands)',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    axisLabel: 'Estimated Savings',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return self.currSymbol + d3.format(',f')(d);
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.series[0].color === 'green')
                            return 'Series "' + d.series[0].key + '" Point "' + self.estimatedSavingXAxisMono[d.point.x] + '%"\n<br> value:' + self.currSymbol + $filter('currency')(d.point.y,'', 0) + '';
                        else
                            return 'Series "' + d.series[0].key + '" Point "' + self.estimatedSavingXAxisMono[d.point.x] + '%"\n<br> value:' + $filter('number')(d.point.y * 1000, 0) + '';
                    }
                },
                callback: highlightPointsMPoCD,
                dispatch: {
                    renderEnd: function () {
                        highlightPointsMPoCD(chart)
                    }
                }
            }
        };
        function highlightPointsMPoCD(chart) {
            var data = self.dataEstimatedGraphMpoCD
            var points = d3.select('.estimatedGraph .nv-groups')
                .selectAll("rect.myPoint")
                .data(data[0].values.filter(function (d) { return d.y; }));
            if (data[2] !== undefined)
            var points1 = d3.select('.estimatedGraph .nv-groups')
                .selectAll("circle.myPoint")
                .data(data[2].values.filter(function (d) { return d.y; }));

            var points2 = d3.select('.estimatedGraph .nv-groups')
                .selectAll("circle.myPoint")
                .data(data[1].values.filter(function (d) { return d.y; }));

            points.enter().append("rect")
                .attr("class", "myPoint")
                .attr("x", function (d) { return chart.xAxis.scale()(d.x) - 4; })
                .attr("y", function (d) { return chart.yAxis1.scale()(d.y) - 4; })
                .attr("width", 8)
                .attr("height", 8)
                .attr("fill", "#7E7E7E");
            if (data[2] !== undefined)
            points1.enter().append("circle")
                .attr("class", "myPoint")
                .attr("cx", function (d) { return chart.xAxis.scale()(d.x); })
                .attr("cy", function (d) { return chart.yAxis2.scale()(d.y); })
                .attr("r", 10)
                .attr("fill-opacity", "0")
                .attr("stroke", "#84A95B")
                .attr("stroke-width", "3");

            points2.enter().append("circle")
                .attr("class", "myPoint")
                .attr("cx", function (d) { return chart.xAxis.scale()(d.x); })
                .attr("cy", function (d) { return chart.yAxis2.scale()(d.y); })
                .attr("r", 5)
                .attr("fill", "#ABB0A4");
        }
        /* DUPLEX USAGE GRAPH OPTIONS */
        self.optionsDuplexDU = {
            chart: {
                type: 'multiChart',
                height: 350,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                // useInteractiveGuideline: true,
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                reduceXTicks: false,
                legendRightAxisHint: "",
                yDomain2:[0,100],
                y2AxisLabels: ["Current Percentage", "Current average", "Target average"],
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsTotalCostOwernership.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'Duplex Sheets(Thousands)',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d) + "%";
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.data.y * 1000,'', 0);
                        else if (d.series[0].key === "Current Percentage" || d.series[0].key === "Current Average" || d.series[0].key === "Target Average")
                            return 'Series" ' + d.series[0].key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.pointIndex].MonthYear + '"\n<br> Value: ' + $filter('number')(d.series[0].value, 1) + '%';
                        else
                            return 'Series" ' + self.optionsDuplexDU.chart.y2AxisLabels[d.point.series] + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.point.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.point.y, '',5);
                    }
                }
            }
        };
        self.optionsDUPie = {
            chart: {
                type: 'pieChart',
                height: 300,
                x: function (d) {
                    return d.value;
                },
                y: function (d) {
                    return d.y*100/d.y1;
                },
                showLabels: true,
                color: ['#F9D3B3', '#C15C08'],
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: true,
                labelType: function (d) {
                    return d3.format(',.1f')(d.value) + "%";
                },
                legend: {
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "' + d.data.value + '"\n<br> Value: ' + $filter('number')(d.data.y, 1) + "(" + $filter('number')(d.data.y*100 / d.data.y1, 0) + "%)";
                    }
                }
            }
        };
        self.optionsDUHorizontalBar = {
            chart: {
                type: 'multiBarHorizontalChart',
                height: 150,
                width: 300,
                x: function (d) {
                    return d.label;
                },
                y: function (d) {
                    return d.value;
                },
                showControls: false,
                showValues: true,
                showLegend: false,
                duration: 500,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 40,
                    left: 120
                },
                xAxis: {
                    showMaxMin: false,
                    rotateYLabel: true,
                    orient: 'left',
                    css: {
                        'transform': 'rotate(45deg)'
                    }
                },
                yAxis: {
                    axisLabel: '',
                    tickFormat: function (d) {
                        return d3.format(',.2f')(d / 1000);
                    }
                },
                valueFormat: function (d) {
                    return d3.format(',.1f')(d / 1000);
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "' + d.data.label + '<br> Value: ' + $filter('number')(d.data.value, 2);
                    }
                }
            }
        };
        d3.select(".DuhorizontalGraph1 .nv-bar").select("rect").style("fill", "red");
        self.optionEstimatedDuplex = {
            chart: {
                type: 'multiChart',
                height: 350,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                reduceXTicks: false,
                legendRightAxisHint: "",
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: true,
                    axisLabel: 'Target Duplex Percentages',
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.estimatedSavingXAxisDuplex[index] + "%";
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'Paper Reduction Sheets(Thousands)',
                    showMaxMin: true,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    axisLabel: 'Estimated Savings',
                    showMaxMin: true,
                    tickFormat: function (d) {
                        return self.currSymbol + d3.format(',f')(d);
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.series[0].color === 'green')
                            return 'Series "' + d.series[0].key + '" Point "' + self.estimatedSavingXAxisDuplex[d.point.x] + '%"\n<br> value:' + self.currSymbol + $filter('currency')(d.point.y,'', 0) + '';
                        else
                            return 'Series "' + d.series[0].key + '" Point "' + self.estimatedSavingXAxisDuplex[d.point.x] + '%"\n<br> value:' + $filter('number')(d.point.y * 1000, 0) + '';
                    }
                },
                callback: highlightPointsDuplex,
                dispatch: {
                    renderEnd: function () {
                        highlightPointsDuplex(chart)
                    }
                }
            }
        };
        function highlightPointsDuplex(chart) {
            var data = self.dataEstimatedGraphDuplex
            var points = d3.select('.estimatedGraph .nv-groups')
                .selectAll("rect.myPoint")
                .data(data[0].values.filter(function (d) { return d.y; }));
            if (data[2] != undefined)
            var points1 = d3.select('.estimatedGraph .nv-groups')
                .selectAll("circle.myPoint")
                .data(data[2].values.filter(function (d) { return d.y; }));

            var points2 = d3.select('.estimatedGraph .nv-groups')
                .selectAll("circle.myPoint")
                .data(data[1].values.filter(function (d) { return d.y; }));

            points.enter().append("rect")
                .attr("class", "myPoint")
                .attr("x", function (d) { return chart.xAxis.scale()(d.x) - 4; })
                .attr("y", function (d) { return chart.yAxis1.scale()(d.y) - 4; })
                .attr("width", 8)
                .attr("height", 8)
                .attr("fill", "#7E7E7E");
            if (data[2] != undefined)
            points1.enter().append("circle")
                .attr("class", "myPoint")
                .attr("cx", function (d) { return chart.xAxis.scale()(d.x); })
                .attr("cy", function (d) { return chart.yAxis2.scale()(d.y); })
                .attr("r", 10)
                .attr("fill-opacity", "0")
                .attr("stroke", "#84A95B")
                .attr("stroke-width", "3");

            points2.enter().append("circle")
                .attr("class", "myPoint")
                .attr("cx", function (d) { return chart.xAxis.scale()(d.x); })
                .attr("cy", function (d) { return chart.yAxis2.scale()(d.y); })
                .attr("r", 5)
                .attr("fill", "#ABB0A4");
        }
        /* SERVICE LEVEL GRAPH OPTIONS */
        self.SLOptionsBar = {
            chart: {
                type: 'multiChart',
                height: 450,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                reduceXTicks: false,
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsTotalCostOwernership.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',.2f')(d) + "%";
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.data.y * 1000,'', 0);
                        else
                            return 'Series" ' + self.optionsDuplexDU.chart.y2AxisLabels[d.point.series] + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.point.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.point.y,'', 5);
                    }
                }
            }
        };
        self.SLIncPie = {
            chart: {
                type: 'pieChart',
                height: 300,
                x: function (d) {
                    return d.value;
                },
                y: function (d) {
                    return d.y;
                },
                showLabels: false,
                legendPosition: 'bottom',
                showLegend: false,
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: true,
                labelType: function (d) {
                    return d3.format(',.1f')(d.value) + "%";
                },
                legend: {
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series "Pages Printed" Point "' + d.data.value + '"\n<br> Value: ' + $filter('number')(d.data.y, 0);
                    }
                }
            }
        };
        self.ServiceIncOptionsBar = {
            chart: {
                type: 'multiBarChart',
                height: 450,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 65,
                    left: 45
                },
                clipEdge: true,
                showControls: false,
                duration: 500,
                stacked: true,
                groupSpacing: 0.3,
                showLegend: true,
                reduceXTicks: false,
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    rotateLabels: 45,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.NIDOptionsBar.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis: {
                    axisLabel: 'Number Of Incidents',
                    showMaxMin: false,
                    axisLabelDistance: -20,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + d.data.y
                    }
                }
            }
        };
        /* TONER/INK TRACKING GRAPH OPTIONS */
        self.seriesTIT = ['Series A', 'Series B', 'Series B'];
        self.datasetOverrideTIT = [{
            label: "Toner Used",
            borderWidth: 3,
            type: 'line',
            showLine: false,
            pointRadius: 8,
            backgroundColor: 'blue',
            borderColor: 'blue',
            pointBackgroundColor: 'blue',
            pointBorderColor: 'blue',
            pointHoverBackgroundColor: 'blue',
            pointHoverBorderColor: 'blue',
            pointHoverBorderWidth: 3,
            pointHoverRadius: 8,
            pointStyle: 'dash'

        }, {
            label: "Overall Toner Orders Received",
            borderWidth: 3,
            type: 'line',
            showLine: false,
            pointRadius: 8,
            backgroundColor: 'green',
            borderColor: 'green',
            pointBackgroundColor: 'green',
            pointBorderColor: 'green',
            pointHoverBackgroundColor: 'green',
            pointHoverBorderColor: 'green',
            pointHoverBorderWidth: 3,
            pointHoverRadius: 8,
            pointStyle: 'dash'
        }, {
            label: "Inventory Deviation",
            type: 'line',
            fill: false,
            backgroundColor: 'orange',
            borderColor: 'red',
            borderWidth: 1,
            pointStyle: 'rectRot',
            pointRadius: 5,
            pointBackgroundColor: 'orange',
            pointBorderColor: 'red',
            lineTension: 0,
            usePointStyle: false
        }];
        self.optionsTIT = {
            title: {
                display: true,
                text: 'Toner Inventory Tracking'
            },
            gridLines: {
                display: true,
                drawBorder: true,
                drawOnChartArea: false,
                drawTicks: false,
            },
            legend: {
                display: true,
                position: 'top',
                labels: {
                    usePointStyle: true
                }
            },
            tooltips: {
                position: 'nearest',
                mode: 'point',
                intersect: false,
                yPadding: 4,
                xPadding: 4,
                caretSize: 8,
                backgroundColor: 'white',
                titleFontColor: 'black',
                bodyFontColor: 'black',
                borderColor: 'rgba(0,0,0,1)',
                borderWidth: 1,
                enabled: false,
                custom: customTooltips
            },
            hover: {
                mode: 'point',
                intersect: true
            }
        };
        self.OSAPercent = {
            chart: {
                type: 'multiChart',
                height: 450,
                margin: { top: 30, right: 90, bottom: 50, left: 70 },
                duration: 500,
                x: function (d) {
                    return d.x;
                },
                y: function (d) {
                    return d.y;
                },
                y2AxisLabels: ["ON TIME %", "On Time Target %"],
                reduceXTicks: false,
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.optionsTotalCostOwernership.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis1: {
                    axisLabel: 'Toner Replacement',
                    stroke: 'black',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                yAxis2: {
                    axisLabel: 'On Time Percentage',
                    showMaxMin: false,
                    tickFormat: function (d) {
                        return d3.format(',f')(d) + "%";
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                legendPosition: 'bottom',
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.data.y * 1000,'', 0);
                        else
                            return 'Series" ' + self.OSAPercent.chart.y2AxisLabels[d.point.series] + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.point.x].MonthYear + '"\n<br> Value: ' + self.currSymbol + $filter('currency')(d.point.y,'', 5);
                    }
                }
            }
        };
        /* OTHER CONSUMABLE TRACKING GRAPH OPTIONS */
        self.seriestrack = ['Series A', 'Series B'];
        self.datasetOverridetrack = [{
            label: "Inventory Monthly Deviation",
            borderWidth: 3,
            type: 'line',
            showLine: false,
            pointRadius: 5,
            backgroundColor: 'transparent',
            borderColor: '#CBDFA1',
            pointBackgroundColor: 'transparent',
            pointBorderColor: '#CBDFA1',
            pointHoverBackgroundColor: 'transparent',
            pointHoverBorderColor: '#CBDFA1',
            pointHoverBorderWidth: 3,
            pointHoverRadius: 5,
            pointStyle: 'point'

        }, {
            label: "Item Used",
            borderWidth: 3,
            type: 'line',
            showLine: false,
            pointRadius: 4,
            backgroundColor: '#2D40E1',
            borderColor: '#2D40E1',
            pointBackgroundColor: '#2D40E1',
            pointBorderColor: '#2D40E1',
            pointHoverBackgroundColor: '#2D40E1',
            pointHoverBorderColor: '#2D40E1',
            pointHoverBorderWidth: 3,
            pointHoverRadius: 4,
            pointStyle: 'line'
        }, {
            label: "Item Received",
            borderWidth: 3,
            type: 'line',
            showLine: false,
            pointRadius: 4,
            backgroundColor: '#FF3A08',
            borderColor: '#FF3A08',
            pointBackgroundColor: '#FF3A08',
            pointBorderColor: '#FF3A08',
            pointHoverBackgroundColor: '#FF3A08',
            pointHoverBorderColor: '#FF3A08',
            pointHoverBorderWidth: 3,
            pointHoverRadius: 4,
            pointStyle: 'line'
        }, {
            label: "Inventory Deviation Trend Lines",
            type: 'line',
            fill: false,
            backgroundColor: '#89E489',
            borderColor: '#89E489',
            borderWidth: 3,
            pointRadius: 0,
            pointStyle: 'line',
            lineTension: 0,
            usePointStyle: false
        }];
        self.datasetOverridetrackSC = angular.copy(self.datasetOverridetrack);

        self.datasetOverridetrackID = angular.copy(self.datasetOverridetrack);
        self.datasetOverridetrackID[0].borderColor = '#FAC090';
        self.datasetOverridetrackID[0].pointBorderColor = '#FAC090';
        self.datasetOverridetrackID[0].pointHoverBorderColor = '#FAC090';
        self.datasetOverridetrackID[3].backgroundColor = '#FAC090';
        self.datasetOverridetrackID[3].borderColor = '#FAC090';
        self.datasetOverridetrackBOP = angular.copy(self.datasetOverridetrack);
        self.datasetOverridetrackBOP[0].borderColor = '#B3A2C7';
        self.datasetOverridetrackBOP[0].pointBorderColor = '#B3A2C7';
        self.datasetOverridetrackBOP[0].pointHoverBorderColor = '#B3A2C7';
        self.datasetOverridetrackBOP[3].backgroundColor = '#B3A2C7';
        self.datasetOverridetrackBOP[3].borderColor = '#B3A2C7';

        self.optionsBOP = {
            responsive: true,
            maintainAspectRatio: false,
            gridLines: {
                display: true,
                drawBorder: true,
                drawOnChartArea: true,
                drawTicks: false,
            },
            legend: {
                display: true,
                position: 'right',
                labels: {
                    usePointStyle: true
                }
            },
            tooltips: {
                position: 'nearest',
                mode: 'point',
                intersect: false,
                yPadding: 4,
                xPadding: 4,
                caretSize: 8,
                backgroundColor: 'white',
                titleFontColor: 'black',
                bodyFontColor: 'black',
                borderColor: 'rgba(0,0,0,1)',
                borderWidth: 1,
                enabled: false,
                custom: customTooltips
            },
            hover: {
                mode: 'point',
                intersect: true
            }
        };
        self.optionstrack = angular.copy(self.optionsBOP);
        self.optionstrack.scales = {
            xAxes: [{
                ticks: {
                    display: false
                },
                gridLines: {
                    display: true
                }
            }]
        }
        /* DEVICE TRACKING & DEPLOYMENT, NRD SUMMARY, NID SUMMARY GRAPH OPTIONS */
        self.NIDOptionsBar = {
            chart: {
                type: 'multiBarChart',
                height: 450,
                margin: {
                    top: 20,
                    right: 20,
                    bottom: 65,
                    left: 45
                },
                clipEdge: true,
                showControls: false,
                duration: 500,
                stacked: true,
                groupSpacing: 0.3,
                showLegend: true,
                //yDomain: [0, 100],
                reduceXTicks: false,
                xAxis: {
                    reduceXTicks: false,
                    showMaxMin: false,
                    rotateLabels: 45,
                    tickFormat: function (index) {
                        if (!isNaN(index)) {
                            return self.NIDOptionsBar.chart.xAxisLabels[index].MonthYear;
                        } else {
                            return index;
                        }
                    }
                },
                yAxis: {
                    axisLabel: 'Devices',
                    showMaxMin: false,
                    axisLabelDistance: -20,
                    tickFormat: function (d) {
                        return d3.format(',f')(d);
                    }
                },
                legend: {
                    align: false,
                    rightAlign: false,
                    updateState: false
                },
                tooltip: {
                    contentGenerator: function (d) {
                        if (d.data !== undefined)
                            return 'Series" ' + d.data.key + '" Point "' + self.optionsTotalCostOwernership.chart.xAxisLabels[d.data.x].MonthYear + '"\n<br> Value: ' + d.data.y
                    }
                }
            }
        };
        self.NRDMonthOptionsBar = angular.copy(self.NIDOptionsBar);
        self.NRDExceptionsOptionsBar = angular.copy(self.NIDOptionsBar);
        self.NRDExceptionsOptionsBar.chart.stacked = false;
        self.DeviceTrackingOptionsBar = angular.copy(self.NIDOptionsBar);
        self.DeviceTrackingOptionsBar.chart.stacked = false;
        self.siteTrackingOptionsBar = angular.copy(self.NIDOptionsBar);
        self.siteTrackingOptionsBar.chart.stacked = false;
        /* ----------------------------------------------- */
        /* OPEN VIEW SUMMARY MODEL POPUP */
        /* ----------------------------------------------- */
        self.openViewSummaryModal = function () {
            if (self.showViewSummary)
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/view-savings-summary-modal.html',
                    controller: "openViewSummaryController",
                    controllerAs: "openViewSummaryCtrl",
                    scope: $scope,
                    backdrop: 'static',
                    keyboard: false
                });
        };
        /* ----------------------------------------------- */
        /* OPEN GRAPHS MODEL POPUP */
        /* ----------------------------------------------- */
        self.loadGraph = function (tabName) {
            self.popNameToOpen = tabName;
            var modalInstance1 = $modal.open({
                templateUrl: 'public/templates/modal/graph-modal.html',
                controller: "PerformanceGraphController",
                controllerAs: "performGraphCtrl",
                scope: $scope,
                windowClass: 'performance-dashboard-modal',
                backdrop: 'static',
                keyboard: false
            });

        };
        /* ----------------------------------------------- */
        /* SAVE INPUT FIELDS */
        /* ----------------------------------------------- */
        self.fillAllTheFields = function (inputValue, rowID, rowHeader, rowMonth, type) {
            var obj = {
                RowHeader: rowHeader,
                RowID: rowID,
                value: inputValue,
            }
            if (type == "month") {
                obj.MonthName = self.range1[rowMonth].MonthYear
            } else {
                obj.MonthName = 'target/best Practice'
            }
            var param = {};
            param.PDLeftSave = obj;
            param.PDUsers = shareUser.get();
            performanceDashboardServices.postPDDataSave(param).then(function (response) {
                calculateData(response);
                calculateAllData();
            });
        };
        /***************
            //  Opeing a Market Vertical Modal
        **************************************/
        self.openMarketVerticleModal = function (ChangeMVdata) {

            //var url = "\\PDAPI\\PD\\Satheeshtest-1-210.zip";
            //var popUp = window.open(url);
            
            //console.log(popUp);
            $rootScope.ChangeMVdata = ChangeMVdata;
            var modalInstance = $modal.open({
                templateUrl: 'public/templates/modal/market-verticle.html',
                controller: "markatVerticalController",
                controllerAs: "markatVrtclCtrl",
                size: 'md',
                windowClass: "mvmodal-window",
                animation: true,
                backdrop: 'static',
                keyboard: false
            });
        };
    }
])
.controller('PerformanceGraphController', function ($scope, $uibModalInstance) {
    var self = this;
    self.closePerformGraph = function () {
        $uibModalInstance.dismiss('cancel');
    };
})
.controller('openViewSummaryController', function ($scope, $uibModalInstance) {
    var self = this;
    self.closeOpenSummary = function () {
        $uibModalInstance.dismiss('cancel');
    };
})
.controller('markatVerticalController', ['$scope', '$http', '$uibModalInstance', '$uibModal', 'shareUser', 'marketVerticalAverage', 'marketVerticalServices',
        function ($scope, $http, $modalInstance, $modal, shareUser, marketVerticalAverage, marketVerticalServices) {
            /**
             * Market Vertical 1st Popup Functionality 
             * It will active while click on Market Vertical button in the PD 
             */
            var self = this;
            self.marketinrModalHeaders = ["Cost Per Page Help", "Average Click Charge Help", "Microsoft Excel", "Capacities & Utilization Help", "NRD and NID Help"];
            /**
             * Making a object to push into an Array  
             * Since adding 2 objects in an Array as developer needs specific format 
             * Final param data array to send to backend while call an API
             */
            self.averageMarketVerticalObj = {
                "averageMarketVertical": marketVerticalAverage.get()
            }
            self.finalMVParamData = [];
            self.finalMVParamData.push(self.averageMarketVerticalObj);
            self.finalMVParamData.push(shareUser.get());
            /**
             * Loading total Market Vertical Data by calling API
             * Market Vertical Collected Object and User details are sending to backend as param 
             */ 
            marketVerticalServices.mvfstModalGetData(self.finalMVParamData).then(function (response) {
                self.marketVerticalData = response.data;
            }); 
            /**
             * Changing API url based on the button values
             * Showing only 1 modal popup for 2 different events 
             */
            //if ($scope.ChangeMVdata === "MarketVertical") {
            //    self.mvApiurl = Constants.POST_GET_MARKET_VERTICAL_DATA;
            //    self.loadMarketVerticalData();
            //} else {
            //    self.mvApiurl = Constants.POST_GET_MARKET_VERTICAL_DATA;
            //    self.loadMarketVerticalData();
            //}
            //Closing modal
            self.closeModal = function () {
                $modalInstance.dismiss('cancel');
            };
            /************
             * Showing one more Popup inside the Modal Popup when click on the help buttons
             *****************************************************/
            self.marketHelpShowModal = function (cls) {
                if (cls !== "close") {
                    self.mvInrModalHeader = self.marketinrModalHeaders[cls];
                    var selecterCls = String(".markcont" + cls); //Making a string class based on the input 
                    $('#markethelp-modal').fadeIn(500);
                    $(".marketmodal-inrcont").hide(100);
                    $(selecterCls).fadeIn(100);
                    $("#markethelp-modal").parent().addClass('showbacdrop');
                } else {
                    $('#markethelp-modal').hide(100, function () {
                        $(".marketmodal-inrcont").hide("fast");
                        $(this).parent().removeClass('showbacdrop');
                    });
                }
            }
            /************
             * After Click on Continue button opeing a another modal popup
             ******************************************************/
            self.marketVerticalContinue = function () {
                //Closing current popup modal
                $modalInstance.dismiss('cancel');
                //and Opening a Market Vertical Export Popup 
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/market-verticle-export.html',
                    controller: "mvDataExportController",
                    controllerAs: "mvExpCtrl",
                    size: 'lg',
                    windowClass: "mvexport-window",
                    animation: true,
                    backdrop: 'static',
                    keyboard: false
                });
            }
            /**
             * Create/Update SBR Form Populating
             */
            self.openSBRCreateModal = function () {
                $modalInstance.dismiss('cancel');
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/sbr-create-update.html',
                    controller: "updateSBRController",
                    controllerAs: "crtesbrCtrl",
                    size: 'md',
                    windowClass: "sbrcreate-window",
                    animation: true,
                    backdrop: 'static',
                    keyboard: false
                });
            }
        }])
.controller('mvDataExportController', ['$scope', '$rootScope', '$http', '$uibModalInstance', '$uibModal', 'Constants', 'shareUser', '$timeout', 'marketVerticalAverage', 'marketVerticalServices',
        function ($scope, $rootScope, $http, $modalInstance, $modal, Constants, shareUser, $timeout, marketVerticalAverage, marketVerticalServices) {
            var self = this;
            console.log('export ctrl');
            self.enableExportButton = false;
            self.enableUploadbtn = false;
            self.enableUploadbtn2 = false;
            //Closing modal here
            self.closeModal = function () {
                $modalInstance.dismiss('cancel');
            };
            self.isActiveSelectBlock = false;
            self.showSelectSection = function () {
                self.isActiveSelectBlock = !self.isActiveSelectBlock;
            }
            self.mvCategoriesIds = {};
            /**
             * Getting all the data for Market Vertical Catgories, Sub Categories and Grand child from API
             * calling API to get Market Vertica Categories data 
             */

            self.loadAllMarketVerticalData = function () {

                marketVerticalServices.mvExportModalGetData(shareUser.get()).then(function (response) {
                    console.log(response); 
                    //self.shareForImportModal = response.data;
                    self.marketVerticalExportData = response.data.Item1;
                    self.mvExportCountryData = response.data.Item2;
                    self.mvExportSelectedData = response.data.Item3;
                    self.mvExportCountrySelected = self.mvExportCountryData[0];
                    //Selecting object if it's already saved
                    if (self.mvExportSelectedData.Item1.MV_ID) {
                        angular.forEach(self.marketVerticalExportData, function (mvSelitem) {
                            if (mvSelitem.MV_ID === self.mvExportSelectedData.Item1.MV_ID) {
                                self.selectedExportData = {};
                                self.selectedExportData = mvSelitem;
                            }
                        });
                    }
                });

                //$http({
                //    method: 'POST',
                //    url: Constants.POST_GET_MARKET_VERTICAL_CATEGORY_DATA,
                //    data: shareUser.get()
                //}).then(function successCallback(response) {
                //    console.log(response);
                //    //self.shareForImportModal = response.data;
                //    self.marketVerticalExportData = response.data.Item1;
                //    self.mvExportCountryData = response.data.Item2;
                //    self.mvExportSelectedData = response.data.Item3;
                //    self.mvExportCountrySelected = self.mvExportCountryData[0];
                //    //Selecting object if it's already saved
                //    if (self.mvExportSelectedData.Item1.MV_ID) {
                //        angular.forEach(self.marketVerticalExportData, function (mvSelitem) {
                //            if (mvSelitem.MV_ID === self.mvExportSelectedData.Item1.MV_ID) {
                //                self.selectedExportData = {};
                //                self.selectedExportData = mvSelitem;
                //            }
                //        });
                //    } //else {
                //    //self.selectedExportData = self.marketVerticalExportData[0];
                //    //}
                //}, function errorCallback(response) {
                //    console.log(response);
                //});
            }
            self.loadAllMarketVerticalData();
            /*
             * Getting Sub Categories by selected parent category object
             * Getting parent object id 
             */
            self.selectedParentRow, self.selectedChildRow = '';
            /*
             * Getting Sub Categories Data after click on Parent Categories list 
             * Selecting Parent Object by ID 
             */ 
            self.getSubCategories = function (subcat, parentindex) {
                console.log(subcat.MVCategory);
                self.selectedParentRow = parentindex;
                self.mvExportSubCatData = subcat.MVCategory;
                self.mvCategoriesIds['MV_ID'] = subcat.MV_ID;
                //Reseting selected calss and data of Sub and Grand Category
                self.selectedChildRow = "";
                self.grandChildSearchFilterString = '';
                self.mvExportGrandSubCatData = '';
                self.enableUploadbtn2 = false;
            }
            /*
             * Getting Grand Sub Categories by selected Sub category object
             * Selecting Sub category object by id 
             */ 
            self.getGrandSubCategories = function (grandsubcat, childIndex) {
                console.log(grandsubcat);
                self.selectedChildRow = childIndex;
                self.mvExportGrandSubCatData = grandsubcat.MVSubCategory;
                self.selectedGrandChildRow = '';
                self.mvCategoriesIds['MV_CID'] = grandsubcat.MV_CID;
                if (self.mvExportGrandSubCatData.length) {
                    self.enableUploadbtn2 = false
                } else {
                    self.enableUploadbtn2 = true
                }                
            }
            /*
             * Getting selected Grand Child object
             * Selecting Grand Child object by id 
             */ 
            self.getGrandChildSelected = function (grandSelceted) {
                console.log(grandSelceted);
                self.selectedGrandChildRow = grandSelceted.MV_SID;
                self.mvCategoriesIds['MV_SID'] = grandSelceted.MV_SID;
                self.enableUploadbtn2 = true
            }
            /*
             * Selecting Region based on selected Country     
             * Collecting selected Country and Region   
             */        
            self.mvExportCountryChange = function () {
                console.log(self.mvExportCountrySelected);
                //Adding country detials to selected object 
                self.mvCategoriesIds['Country_ID'] = self.mvExportCountrySelected.Country_ID;
                self.mvCategoriesIds['Country_Name'] = self.mvExportCountrySelected.Country_Name;
                //self.enableUploadbtn = true;
            }
            /*
             * Sending Data to backend when click on upload button
             * Saving selected category, sub category, grand category object and Country region   
             */ 
            self.uploadMarketVertical = function () {
                console.log('Upload market Vertical Section');
                console.log(self.mvExportCountrySelected);
                //Based on selected MV Parent ID, changing selected object and Sharing it to 3rd popup
                self.mvCategoriesIds['Country_ID'] = self.mvExportCountrySelected.Country_ID;
                self.mvCategoriesIds['Country_Name'] = self.mvExportCountrySelected.Country_Name;
                //self.mvCategoriesIds['Region_ID'] = self.mvExportCountrySelected.Region_ID;
                //self.mvCategoriesIds['Region_Name'] = self.mvExportCountrySelected.Region_Name;
                $rootScope.selectedMVParentId = self.mvCategoriesIds;
                angular.forEach(self.marketVerticalExportData, function (mvitem) {
                    if (mvitem.MV_ID === self.mvCategoriesIds.MV_ID) {
                        self.selectedExportData = {};
                        self.selectedExportData = mvitem;
                    }
                });
                //Merging Userdetails and Categories 
                self.mergeUserSelected = {};
                angular.merge(self.mergeUserSelected, shareUser.get(), self.mvCategoriesIds);
                console.log(self.mergeUserSelected);
                self.enableExportButton = true;
            }
            /*
             * When click on Export Market Vertical button this function will trigger
             * Sending Market Vertical Avarage values of object, selected category, sub category, grand category object and Country region as Array to backend 
             * Checking Currency Values is above 10 or not 
             */
            self.mvImportTableData = [];
            self.exportMarketVertical = function () {
                //console.log('After click on export button');
                //console.log($scope.curRateAlert);
                //console.log($scope.curRateAlertArray);
                $scope.curRateAlert = false;
                /*
                 * If is Currency Rate is not more than 10
                 * Else is for make a alert in the ciondition Currency Rate is more than 10
                 */ 
                if (!$scope.curRateAlert) {
                    self.averageMarketVerticalDataObj = {
                        "averageMarketVertical": marketVerticalAverage.get()
                    }
                    self.mvExportFinalParam = [];
                    self.mvExportFinalParam.push(self.averageMarketVerticalDataObj);
                    self.mvExportFinalParam.push(self.mergeUserSelected);
                    console.log(self.mvExportFinalParam);
                    //Calling API 
                    //mvExportModalPostSelectedData
                    marketVerticalServices.mvExportModalPostSelectedData(self.mvExportFinalParam).then(function (response) {
                        console.log(response);
                        self.mvImportTableData.push(response.data[0]);
                    });

                    //$http({
                    //    method: 'POST',
                    //    url: Constants.POST_EXPORT_MARKET_VERTICAL_DATA,
                    //    data: self.mvExportFinalParam
                    //}).then(function successCallback(response) {
                    //    console.log(response);
                    //    self.mvImportTableData.push(response.data[0]);
                    //}, function errorCallback(response) {
                    //    console.log(response);
                    //});
                    self.openImportModal();
                } else {
                    var newLine = "\r\n"
                    var CurRateMessage = "Click charges more than 10 cents not allowed for the following fields"
                    CurRateMessage += newLine;
                    CurRateMessage += $scope.curRateAlertArray[0].RowName;
                    CurRateMessage += newLine;
                    CurRateMessage += "Please review and fix these in order to continue";
                    alert(CurRateMessage);
                }
            }
            /*
             * Closeing Current Modal and Opening Import Modal popup
             * sharing shareDataImportModal data to import controller 
             */ 
            self.openImportModal = function () {
                self.closeModal();
                self.shareDataImportModal = {
                    'exportCategoriesData': self.marketVerticalExportData,
                    'importTableData': self.mvImportTableData,
                }
                var modalInstance = $modal.open({
                    templateUrl: 'public/templates/modal/market-verticle-import.html',
                    controller: "mvDataImportController",
                    controllerAs: "mvImpCtrl",
                    size: 'lg',
                    windowClass: "mvimport-window",
                    animation: true,
                    backdrop: 'static',
                    keyboard: false,
                    resolve: {
                        passtoimport: function () {
                            return self.shareDataImportModal || {};
                        }
                    }
                });
            }
        }])
.controller('mvDataImportController', ['$scope', '$rootScope', '$http', '$uibModalInstance', '$uibModal', 'Constants', 'shareUser', 'marketVerticalAverage', 'passtoimport', 'marketVerticalServices',
        function ($scope, $rootScope, $http, $modalInstance, $modal, Constants, shareUser, marketVerticalAverage, passtoimport, marketVerticalServices) {
            var self = this;
            //Closing a modal 
            self.closeModal = function () {
                $modalInstance.dismiss('cancel');
            }
            self.checkAllSubCategories = false;
            self.selectedMVCategory = {};
            self.selectedMVCategory["CategoryId"] = $scope.selectedMVParentId.MV_ID;
            self.selectedMVSubCategories = [];
            /*
             * Selecting the specific Market Vertical service object by selected Market Vertical object in earlier Popup  
             */
            self.mvImportCategoryChange = function () {
                self.selectedMVCategory["CategoryId"] = self.mvImportSelectedCategory.MV_ID;
                self.mvImportSelectedSubCategory = self.mvImportSelectedCategory.MVCategory;
                self.checkAllSubCategories = false;
                self.changeSelectAllSubCategories();
            }
            /*
             * While changing Market Vertical Categories  
             */
            self.changeSelectAllSubCategories = function () {
                //self.selectedMVSubCategories = [];
                angular.forEach(self.mvImportSelectedSubCategory, function (sub) {
                    sub.eachcheck = self.checkAllSubCategories;
                    console.log(self.checkAllSubCategories);
                    //self.selectedMVSubCategories.push({ 'MV_CID': sub.MV_CID });
                });
                self.checkLength();
            }
            /**
             * Loading total MV Parent and Child data from 2nd Popup data
             */
            self.loadImportData = function () {
                self.mvImportData = passtoimport.exportCategoriesData;
                console.log($scope.selectedMVParentId);
                angular.forEach(self.mvImportData, function (selectmv) {
                    if (selectmv.MV_ID === self.selectedMVCategory["CategoryId"]) {
                        self.mvImportSelectedCategory = selectmv;
                    }
                    angular.forEach(selectmv.MVCategory, function (selectsubmv) {
                        if (selectsubmv.MV_CID === $scope.selectedMVParentId.MV_CID) {
                            selectsubmv.eachcheck = true;
                        }
                    });
                });
                self.mvImportSelectedSubCategory = self.mvImportSelectedCategory.MVCategory;
                self.mvImportRightTableData = passtoimport.importTableData;
                //self.changeSelectAllSubCategories();
            }
            self.loadImportData();
            /**
             * Checking length and selecting specific object based on user selecting 
             * Multiple also allowed to select 
             */
            self.checkLength = function () {
                self.selectedMVSubCategories = [];
                self.selectedMVSubCategories.push(self.selectedMVCategory);
                self.totalChecked = 0;
                angular.forEach(self.mvImportSelectedSubCategory, function (sub) {
                    if (sub.eachcheck) {
                        self.totalChecked++;
                        self.selectedMVSubCategories.push({ 'MV_CID': sub.MV_CID });
                    }
                });
                if (self.totalChecked === self.mvImportSelectedSubCategory.length) {
                    self.checkAllSubCategories = true
                } else {
                    self.checkAllSubCategories = false
                }
                /**
                 * CALLING API WITH SENDING SELECTED CATEGORY, SUB CATEGORIES ID'S AND USER DETAILS
                 */
                self.mvonchangeSubParam = [];
                self.mvonchangeSubParam.push({ "SelectedCategories": self.selectedMVSubCategories });
                self.mvonchangeSubParam.push(shareUser.get());
                //Calling API 

                marketVerticalServices.mvImportModalGetTableData(self.mvonchangeSubParam).then(function (response) {
                    console.log(response); 
                });

                //$http({
                //    method: 'POST',
                //    url: Constants.POST_UPDATE_EXPORT_MV_DATA,
                //    data: self.mvonchangeSubParam
                //}).then(function successCallback(response) {
                //    console.log(response);
                //}, function errorCallback(response) {
                //    console.log(response);
                //});
            }
            /**
             * While click on Import button 
             * Sending selected Market Vertical Object id's and Right Side data 
             * Calling function updatePD() finally 
             */
            self.mvImportPostData = function () {
                self.mvImportPostParam = [];
                //angular.merge(self.mvImportPostParam, shareUser.get(), self.mvImportRightTableData[0]);
                self.mvImportPostParam.push(self.mvImportRightTableData[0]);
                self.mvImportPostParam.push(shareUser.get());
                //$rootScope.updatePD('test');
                marketVerticalServices.mvImportModalGetTableDataLoad(self.mvImportPostParam).then(function (response) {
                    console.log(response);
                    self.closeModal();
                    $rootScope.updatePD(response);
                });
                //$http({
                //    method: 'POST',
                //    url: Constants.POST_MARKET_VERTICAL_IMPORT_DATA,
                //    data: self.mvImportPostParam
                //}).then(function successCallback(response) {
                //    console.log(response);
                //    self.closeModal();
                //    $rootScope.updatePD(response);
                //}, function errorCallback(response) {
                //    console.log(response);
                //    self.closeModal();
                //    $rootScope.updatePD(response);
                //});
            }
        }])
.controller('updateSBRController', ['$scope', '$rootScope', '$http', '$uibModalInstance', '$uibModal', 'Constants', 'shareUser', 'marketVerticalServices',
        function ($scope, $rootScope, $http, $modalInstance, $modal, Constants, shareUser, marketVerticalServices) {
            var self = this;
            //Closing Modal
            self.closeModal = function () {
                $modalInstance.dismiss('cancel');
            };
            self.disabledit = true;
            self.sbrcompanyname = "SGS Global";
            self.sbrsite = "All Locations";
            self.sbradmname = "Koh Lay Hong";
            self.sbrrmclocation = ['None', 'Ariana, Tunisia', 'Bangalore, India', 'Heredia, Costa Rica', 'Sofia, Bulgaria'];
            self.sbrfrequency = ['Monthly', 'Quarterly', 'Semi-Annual', 'Annually'];
            self.sbrlanguage = [{ 'Name': 'Deutsch (German)', 'disabled': false }, { 'Name': 'English', 'disabled': false }, { 'Name': 'French (Canadian)', 'disabled': false }, { 'Name': 'French (EMEA)', 'disabled': false }, { 'Name': 'Portuguese (EMEA)', 'disabled': false }, { 'Name': 'Portuguese (LA)', 'disabled': false }, { 'Name': 'Russian', 'disabled': false }, { 'Name': 'Spanish (EMEA)', 'disabled': false }, { 'Name': 'Spanish (LA)', 'disabled': false }];
            self.sbrSelectedLanguage = "English";
            self.sbrstyle = ['dMPS Full', 'pMPS SBR (EMEA)', 'pMPS SBR (AMS & APJ)'];
            self.styleSelectedVal = self.sbrstyle[0];
            self.sbrtime = ['Quarterly', 'Semi-Annual'];
            self.summaryTimeFrame = self.sbrtime[0];
            self.sbrUserName = 'RMC';
            self.sbrStartDate = $rootScope.sbrStartEndDate.StartMonth;
            self.sbrEndDate = $rootScope.sbrStartEndDate.EndMonth;
            self.sbrCompanyName = $rootScope.sbrStartEndDate.companyName;
            self.sbrfrequencySelect = self.sbrfrequency[0];
            /**
             * Selecting Language or Disabling languages when seleting SBR styles 
             */
            self.sbrStyleChange = function (selstyle, sbrlanguage) {
                if (selstyle === "dMPS Full") {
                    angular.forEach(sbrlanguage, function (lang) {
                        lang.disabled = false;
                    });
                } else {
                    angular.forEach(sbrlanguage, function (lang) {
                        if (lang.Name !== 'English') {
                            lang.disabled = true;
                        }
                    });
                    self.sbrSelectedLanguage = "English";
                }
            }
            /**
             * Calling API 
             * Sending user details and SBR input values 
             */         
            self.createNewSBR = function () {
                self.sbrColletedInputs = {
                    "CompanyName": self.sbrCompanyName,
                    "User": self.sbrUserName,
                    "StartMonth": self.sbrStartDate,
                    "EndMonth": self.sbrEndDate,
                    "Frequency": self.sbrfrequencySelect,
                    "Language": self.sbrSelectedLanguage,
                    "Style": self.styleSelectedVal,
                    "TimeFrame": self.summaryTimeFrame
                }
                self.sbrPostParam = [];
                //angular.merge(self.sbrPostParam, shareUser.get());
                self.sbrPostParam.push();
                self.sbrPostParam.push(self.sbrColletedInputs);
                self.sbrPostParam.push(shareUser.get());
                marketVerticalServices.mvCreateSBRModalPostData(self.sbrPostParam).then(function (response) {
                    console.log(response);
                    var splitData = response.data.split(";");
                    if (splitData.length === 2) {
                        $scope.zipFile = splitData[0].split(":")[1].trim();
                        var url = Constants.API_URL + $scope.zipFile;
                        window.open(url);
                        alert(splitData[1]);
                    } else {
                        alert(response.data);
                    }
                    self.closeModal();
                });
                //$http({
                //    method: 'POST',
                //    url: Constants.POST_CREATE_SBR_REPORT,
                //    data: self.sbrPostParam
                //}).then(function successCallback(response) {
                //    var splitData = response.data.split(";");
                //    if (splitData.length === 2) {
                //        $scope.zipFile = splitData[0].split(":")[1].trim();
                //        var url = Constants.API_URL + $scope.zipFile;
                //        window.open(url);
                //        alert(splitData[1]);
                //    } else {
                //        alert(response.data);
                //    }
                //    self.closeModal();
                //}, function errorCallback(response) {
                //    console.log(response);
                //});
            }

        }])
.directive("summaryPopupDirective", function ($uibModal) {
    return {
        restrict: 'A',
        scope: {
            condition: '=condition'
        },
        link: function (scope, element, attrs) {
            if (scope.condition) {
                console.log(attrs.tabheadername);
                element.css('background', 'yellow');
                element.bind("blur", function () {
                    console.log(element.val());
                    var textValue = element.val();
                    var digits = textValue.replace(/[^0-9]/g, '');

                    if (digits !== textValue || textValue === null || textValue === "") {
                        alert("Please enter a valid percentage");
                        angular.element(".summaryTable table").removeClass("ng-show").addClass("ng-hide");
                    } else {

                        if (attrs.tabheadername == 'Color Device Usage') {

                            angular.element(".ColorUsageSummaryTable").removeClass("ng-hide").addClass("ng-show");
                        } else if (attrs.tabheadername == 'Mono Pages on Color Devices') {
                            angular.element(".MonoPagesOnColorDevicesSummaryTable").removeClass("ng-hide").addClass("ng-show");
                        } else {
                            angular.element(".DuplexUsageSummaryTable").removeClass("ng-hide").addClass("ng-show");
                            var modalInstance = $uibModal.open({
                                templateUrl: 'public/templates/modal/duplex-summary-table.html',
                                controller: "ModalInstanceCtrl",
                                size: 'lg'

                            });
                        }

                    }
                });
            }

        }
    };
})
  .directive('inlineEdit', function ($timeout) {
      return {
          scope: {
              model: '=inlineEdit',
              rowid: '=rowid',
              rowHeader: '=rowHeader',
              rowMonth: '=rowMonth',
              displayFormat: '=format',
              currSymbol: '=currSymbol',
              handleSave: '&onSave',
              handleCancel: '&onCancel',
              type: '@type'
          },
          link: function (scope, elm, attr) {
              var previousValue;

              scope.edit = function () {
                  scope.editMode = true;
                  previousValue = scope.model;

                  $timeout(function () {
                      elm.find('input')[0].focus();
                  }, 0, false);
              };
              scope.filterValue = function ($event) {
                  if (scope.model.indexOf(".") !== -1) {
                      if (isNaN(String.fromCharCode($event.keyCode))) {
                          $event.preventDefault();
                      }
                  } else {
                      if ($event.keyCode === 45 && scope.model.length)
                          $event.preventDefault();
                      else if ($event.keyCode !== 45 && $event.keyCode !== 46 && isNaN(String.fromCharCode($event.keyCode))) {
                          $event.preventDefault();
                      }
                  }
              };
              scope.save = function () {
                  scope.editMode = false;
                  if (parseFloat(scope.model) !== parseFloat(previousValue))
                      scope.handleCancel({
                          value: scope.model,
                          rowID: scope.rowid,
                          rowHeader: scope.rowHeader,
                          rowMonth: scope.rowMonth,
                          type: scope.type
                      });
              };
              scope.cancel = function () {
                  scope.editMode = false;
                  scope.model = previousValue;
              };
          },
          template: '<input type="text" class="form-control custom-form-control pdEditableBox" ng-keypress="filterValue($event)" on-enter="save()" ng-blur="cancel()" on-esc="cancel()" ng-model="model" ng-show="editMode">\
                    <div style="width:100%;height:100%;line-height: 30px;" ng-hide="editMode"  ng-click="edit()">\
                    <span ng-if="model!==\'\' && displayFormat === \'noDecimal\'" ng-class="{\'hp-red\': model < 0 }">{{model | currency:currSymbol:0 }}</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'decimal\'" ng-class="{\'hp-red\': model < 0 }">{{model | currency:currSymbol:5 }}</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'percent\'" class="percentageFont" ng-class="{\'hp-red\': model < 0 }">{{model*100 | number :2 }}%</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'percentOneDigit\'" class="percentageFont" ng-class="{\'hp-red\': model < 0 }">{{model*100 | number :1 }}%</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'noPercent\'">{{model | number :0 }}</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'string\'" ng-class="{\'percentageFont\':model.indexOf(\'%\') !==-1}">{{model}}</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'customNumber\'" ng-class="{\'hp-red\': model < 0 }">{{model | customNumber}}</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'customNumberFloat\'" ng-class="{\'hp-red\': model < 0 }">{{model | customNumberFloat}}</span>\
                    <span ng-if="model!==\'\' && displayFormat === \'customNumberFloatOneDigit\'" ng-class="{\'hp-red\': model < 0 }">{{model | customNumberFloatOneDigit}}</span>\
                    <span ng-if="model===\'\'"></span></div>'
      };
  })
  .directive('onEsc', function () {
      return function (scope, elm, attr) {
          elm.bind('keydown', function (e) {
              if (e.keyCode === 27) {
                  scope.$apply(attr.onEsc);
                  e.stopImmediatePropagation();
              }
          });
      };
  })
  .directive('onEnter', function () {
      return function (scope, elm, attr) {
          elm.bind('keypress', function (e) {
              if (e.keyCode === 13) {
                  scope.$apply(attr.onEnter);
                  e.stopImmediatePropagation();
              }
          });
      };
  })
.filter('customNumber', function () {
    return function (value) {
        return parseInt(value) //convert to int
    }
}).filter('customNumberFloat', function () {
    return function (value) {
        return parseFloat(value).toFixed(2)
    }
}).filter('customNumberFloatOneDigit', function () {
    return function (value) {
        return parseFloat(value).toFixed(1)
    }
})
.filter('ifZero', function () {
    return function (input, defaultValue) {
        if (input === defaultValue + '0') {
            return '-';
        }
        return '';
    }
});