﻿(function () {
    "use strict";
    angular.module('PerformanceDashboard')
   .controller('holidaysListCtrl', ['$scope', function ($scope) {
       var self = this;
       //Static Json "Holiday List" as Backend is not yet ready 
       self.holidaysList = [{ "DateSerialValue": 41275, "Date": "February 06, 2013", "Country": "Canada", "Holiday": "New Years" },
           {"DateSerialValue": 41276, "Date": "January 01, 2013", "Country": "India", "Holiday": "New Years Day" },
           {"DateSerialValue": 41277, "Date": "October 03, 2013", "Country": "Canada2", "Holiday": "New Years Day2" },
           { "DateSerialValue": 41278, "Date": "October 04, 2013", "Country": "Canada3", "Holiday": "New Years3" },
           { "DateSerialValue": 41275, "Date": "February 06, 2013", "Country": "Canada", "Holiday": "New Years" },
           { "DateSerialValue": 41276, "Date": "January 01, 2013", "Country": "India", "Holiday": "New Years Day" },
           { "DateSerialValue": 41277, "Date": "October 03, 2013", "Country": "Canada2", "Holiday": "New Years Day2" },
           { "DateSerialValue": 41278, "Date": "October 04, 2013", "Country": "Canada3", "Holiday": "New Years3" },
           { "DateSerialValue": 41279, "Date": "October 05, 2013", "Country": "Canada4", "Holiday": "New Years4" }];
       //Static Json "Service Zone List" as Backend is not yet ready
       self.ServiceZoneList = [{ "PostalCode": 560066, "Area": "Igate", "Zone": "1" },
            { "PostalCode": 560067, "Area": "Igate2", "Zone": "3" },
            { "PostalCode": 560068, "Area": "Igate3", "Zone": "2" },
            { "PostalCode": 560069, "Area": "Igate4", "Zone": "1" },
            { "PostalCode": 560016, "Area": "Igate5", "Zone": "2" },
            { "PostalCode": 560026, "Area": "Igate6", "Zone": "1" },
            { "PostalCode": 560036, "Area": "Igate7", "Zone": "2" },
            { "PostalCode": 560046, "Area": "Igate8", "Zone": "1" },
            { "PostalCode": 560056, "Area": "Igate9", "Zone": "2" }];
       /******
        * Holiday list CRUD Oparetions starts here
       */
       //Adding editable key in "Holiday List"
       self.addingEditable = function(){
           angular.forEach(self.holidaysList, function (day) {
               day.id = (self.holidaysList.indexOf(day) + 1) * new Date().getTime() * 9;
               day.editable = false; 
           });
           console.log(self.holidaysList);
       }
       //Making editable of row elements to edit a data in "Holiday List"
       self.addingEditable();
       self.oldRow = {};
       self.editDayRow = function (day) {
           angular.forEach(self.holidaysList, function (day) {
               day.editable = false;
           });
           day.editable = true;
           self.oldRow = angular.copy(day);
           console.log(self.oldRow);
       }
       //Updating table row data in "Holiday List"
       self.updateDayRow = function (day, id) {
           console.log(self.holidaysList.indexOf(day));
           var indval = self.holidaysList.indexOf(day);
           if (angular.equals(angular.toJson(day), angular.toJson(self.oldRow))) {
               console.log("No changes in Edit");
               self.oldRow.editable = false;
               self.holidaysList[indval] = angular.copy(self.oldRow);
               self.oldRow = {};

           } else { 
                self.oldRow.editable = false;
                self.holidaysList[indval] = angular.copy(self.oldRow);
                self.oldRow = {};
                console.log(self.holidaysList)
           }  
       }
       //Deleting table row data in "Holiday List"
       self.deleteDayRow = function (day, id) {
           var r = confirm("Click on OK to delete a Row, Other wise click on Cancel button");
           if (r == true) {
               var index = self.holidaysList.indexOf(day)
               self.holidaysList.splice(index, 1);
           }
       }
       //Showing "add a row" block to take input values in "Holiday List"
       self.showAddaRow = false;
       self.showAddDayRow = function (val) {
           self.addRow = {};
           if (val === "add") {
               self.showAddaRow = true;
           } else {
               self.showAddaRow = false;
           }
       }
       //Adding a new row of data to "Holiday List"
       self.addaDayRow = function (addRow) {
           addRow.id = new Date().getTime() * 987;
           addRow.editable = false;
           self.holidaysList.push(addRow);
           self.showAddaRow = false;
           self.addRow = {};
           console.log(self.holidaysList);
       }
       //Reseting selected row in "Holiday List"
       self.resetDayRow = function (day) {
           day.editable = false;
       }
       /******
        * "Service Zone" table CRUD oparetions starts here
       */
       //Adding editable and id keys and values to "Service Zone list"
       self.addingZoneEditable = function () {
           angular.forEach(self.ServiceZoneList, function (zone) {
               zone.id = self.ServiceZoneList.indexOf(zone);
               zone.editable = false;
           });
           console.log(self.ServiceZoneList);
       }
       //Making editable of row elements to edit a data in "Service Zone list"
       self.addingZoneEditable();
       self.oldZoneRow = {};
       self.editZoneRow = function (zone) {
           angular.forEach(self.ServiceZoneList, function (zone) {
               zone.editable = false;
           });
           zone.editable = true;
           self.oldZoneRow = angular.copy(zone);
           console.log(self.oldZoneRow);
       }
       //Updating a selected row data in "Service Zone list"
       self.updateZoneRow = function (zone, id) {
           var indval = self.ServiceZoneList.indexOf(zone);
           //Checking old value and new value
           if (angular.equals(angular.toJson(zone), angular.toJson(self.oldZoneRow))) {
               //console.log("No changes in Edit");
               self.oldZoneRow.editable = false;
               self.ServiceZoneList[indval] = angular.copy(self.oldZoneRow);
               self.oldZoneRow = {};
           } else {
               //console.log("Changes are there");
               self.oldZoneRow.editable = false;
               self.ServiceZoneList[indval] = angular.copy(self.oldZoneRow);
               self.oldZoneRow = {};
               console.log(self.ServiceZoneList)
           }
       }
       //Deleting a seleted row data from "Service Zone list"
       self.deleteZoneRow = function (zone, id) {
           var r = confirm("Click on OK to delete a Row, Other wise click on Cancel button");
           if (r == true) {
               var index = self.ServiceZoneList.indexOf(zone)
               self.ServiceZoneList.splice(index, 1);
           }           
       }
       //Showing add a row block to add row data to "Service Zone list"
       self.showzonerow = false;
       self.showAddZoneRow = function (val) {
           self.addZRow = {};
           if (val === "add") {
               self.showzonerow = true;
           } else {
               self.showzonerow = false;
           }
       }
       //Adding a new row data to "Service Zone list"
       self.addZoneRowUpdate = function (addZRow) {
           addZRow.id = new Date().getTime() * 987;
           addZRow.editable = false;
           self.ServiceZoneList.push(addZRow);
           self.showzonerow = false;
           self.addZRow = {};
           console.log(self.ServiceZoneList);
       }
       //Reseting selected row in "Service Zone list"
       self.resetZoneRow = function (zone) {
           zone.editable = false;
       }
   }]);
}());