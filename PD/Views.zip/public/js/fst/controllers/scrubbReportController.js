﻿angular.module('PerformanceDashboard').controller('scrubbReportController', ['$scope', '$http', '$state', 'Upload', 'Constants', 'scrubServices',
    function ($scope, $http,$state, Upload, Constants, scrubServices) {
    
    $scope.selection = [];
    $scope.ccListSelection = "false";
    $scope.slaListSelection = "false";
    $scope.clearData = false;
    var formdata = new FormData();
    /*start Call this function whenever import from computer is clicked to select the file from Local*/ 
    $scope.fileSelected = function (files, events, b) {
        if (files.length > 0) {
            angular.forEach(files, function (value, key) {
                formdata.append(key, value);
            });
            var postData = {};
            postData.CompanyName = $scope.companyName;
            postData.IsSetAllSLA = $scope.slaListSelection;
            postData.SLASelected = $scope.slaList;
            postData.IsSetAllCoverage = $scope.ccListSelection;
            postData.CoverageSelected = $scope.ccList;
            postData.IsClearData = $scope.clearData;
            var PostProcessPPUFileFromComputerUrl = Constants.API_URL + Constants.POST_PPU_COMPUTER;
            $http({
                method: 'POST',
                url: PostProcessPPUFileFromComputerUrl,
                data: formdata,
                headers: {
                    'Content-Type': undefined
                }
            }).then(function successCallback(response) {
                scrubServices.PostProcessPPUFile(postData)
                .then(function successCallback(response) {
                    if (response.success === undefined) {
                        alert(response.data);
                        $state.go('main.scrubber.compInfo');
                    }
                });
            });
        }
    };
        /*end Call this function whenever import from computer is clicked to select the file from Local*/
        /* start download from network*/
    $scope.downloadFrmNetwork = function () {
        var files = [];
        angular.forEach($scope.allPPUList, function (ppu) {
            if (ppu.selected) {
                var temp = {};
                temp.PPUFileName = ppu.value
                files.push(temp);
            }
        });
        var postData = {};
        postData.CompanyName = $scope.companyName;
        postData.PPUFiles = files;
        postData.IsSetAllSLA = $scope.slaListSelection;
        postData.SLASelected = $scope.slaList;
        postData.IsSetAllCoverage = $scope.ccListSelection;
        postData.CoverageSelected = $scope.ccList;
        postData.IsClearData = $scope.clearData;
        scrubServices.postPPUShare(postData)
            .then(function successCallback(response) {
                if (response.success === undefined) {
                    alert(response.data);
                    $state.go('main.scrubber.compInfo');
                }
            });
    }
        /* end download from network*/
        /* get initial data from API to populate in SLA and CC dropdown*/
    $scope.getScrubReportData = function () {
        scrubServices.postScrubReport().then(function successCallback(response) {
            var scrubData = response.data;
            $scope.allPPUList = [];
            $scope.companyName = scrubData.Company_Name[0].CompanyName;
            angular.forEach(scrubData.Files, function (file) {
                var tempObj = {};
                tempObj.value = file;
                tempObj.selected = false;
                $scope.allPPUList.push(tempObj);
            })
            $scope.SLASettings = [];//Object.keys(scrubData.SLA_Settings).map(function (k) { return scrubData.SLA_Settings[k] });
            $scope.contractCoverage = Object.keys(scrubData.Contract_Coverage).map(function (k) { return scrubData.Contract_Coverage[k] });
            $scope.SLASettings.push({ "SLASettings": "Need SLA" });
            angular.forEach(scrubData.SLA_Settings, function (sla) {
                $scope.SLASettings.push(sla);
            })
            $scope.slaList = "Need SLA";
            $scope.ccList = "MF: 8-17";
            $scope.ppuList = $scope.allPPUList;
            $scope.selectPPU = false;
        });
    }
    //on click on ppu buttons
    $scope.toggle = function (ppu) {
        $scope.selectPPU = true;
        ppu.selected = !ppu.selected;
        angular.forEach($scope.ppuList, function (ppu) {
            if (!ppu.selected) {
                $scope.selectPPU = false;
            }
        });
    };
    /*select all checkbox selection/deselection start*/
    $scope.selectAllPPU = function () {
        angular.forEach($scope.ppuList, function (ppu) {
            ppu.selected = $scope.selectPPU;
        });
    }
    /*select all checkbox selection/deselection start */
    /*Clear all button start */
    $scope.clearAll = function () {
        $scope.selectPPU = false;
        $scope.companyName = "";
        $scope.searchPPU = "";
        $scope.ppuList = $scope.allPPUList;
        angular.forEach($scope.ppuList, function (ppu) {
            ppu.selected = false;
        });
    }
    /*Clear all button end*/
    /*search PPU from data start*/
    $scope.searchFilter = function () {
        $scope.ppuList = [];
        if ($scope.searchPPU === undefined || $scope.searchPPU === '') {
            $scope.ppuList = $scope.allPPUList;
        } else {
            $scope.selectPPU = true;
            angular.forEach($scope.allPPUList, function (ppu) {
                ppu.value = ppu.value.replace(/\s+/g, ' ').trim();
                if (ppu.value.toLowerCase() === $scope.searchPPU.toLowerCase()) {
                    ppu.selected = true;
                    $scope.ppuList.push(ppu);
                }
            });
        }
    }
        /*search PPU from data end*/

    //$scope.openFilelocation = function () {
    //    scrubServices.getOpenUrl()
    //        .then(function successCallback(response) {
    //            console.log(response);
    //        });
    //}
}]);
