﻿angular.module('PerformanceDashboard')
      .factory('processInvoiceServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
          var processInvoiceServices = {
              deleteLastMonthData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.DELETE_LAST_MONTH_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting delete last month data'));
              },
              postAvailableData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_AVAILABLE_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting data'));
              },
              PostUpdateDeviceStatus: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_UPDATE_DEVICE_STATUS, param, true)
                  .then(this.handleSuccess, this.handleError('Error while updating device status'));
              },
              abortInvoiceProcess: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.GET_ABORT_INVOICE_PROCESS, param, true)
                  .then(this.handleSuccess, this.handleError('Abort invoice unknown devices error'));
              },
              cleargroupRow: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_CLEAR_GROUP_ROW, param, true)
                  .then(this.handleSuccess, this.handleError('clear group error'));
              },
              cleargroup: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_CLEAR_GROUP, param, true)
                  .then(this.handleSuccess, this.handleError('clear group error'));
              },
              deleteOneMonthData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_DELETE_ONE_MONTH_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while delete for one month data'));
              },
              postUpdateFlagData: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_INVOICE_USAGE_FLAG_UPDATE, param, true)
                  .then(this.handleSuccess, this.handleError('Error while updateing flag'));
              },
              postUpdateNRDStatusData: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_NRD_STATUS_UPDATE, param, true)
                  .then(this.handleSuccess, this.handleError('Error while updateing flag'));
              },
              handleSuccess: function (response) {
                  return response;
              },

              handleError: function (error) {
                  return function () {
                      console.log(error);
                      return { success: false, message: error };
                  };
              }
          };
          return processInvoiceServices;
      }])