﻿angular.module('PerformanceDashboard')
      .factory('sowServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
          var sowServices = {
              postSowData: function (param) { 
                  return BaseHTTPService.httpPost(Constants.POST_SOW_INFORMATION, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting sow details'));
              },
              postCalculateSow: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_CALCULATE_SOW_VOLUME, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error'));
              },
              postAllCalculateSow: function (jsonData) {                  
                  return BaseHTTPService.httpPost(Constants.POST_CALCULATE_SOW_ALL_VOLUME, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error'));
              },
              postGetDataDesignSow: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_GET_MONTH_SOW_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting month details'));
              },              
              postGotoDataDesignSow: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_GOTO_DATA_DESIGN_SOW, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error while continue report'));
              },
              postGenerateSbrSow: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_GENERATE_SBR_SOW_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting Generate SBR details'));
              },
              postSowTopRowData: function (jsonData) {
                  //var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_SOW_COMPANYINFO, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error while getting Generate SBR details'));
              },
              handleSuccess: function (response) {
                  return response;
              },

              handleError: function (error) {                  
                  return function () {
                      console.log(error);
                      return { success: false, message: error };
                  };
              }
          };
          return sowServices;
      }])