(function () {
    "use strict";
    angular.module('SBRUI')
    .factory('userAppService', ['$rootScope', '$http', function ($rootScope, $http) {
        var passUserDetails = {};
        //passUserDetails.PDFileName = $rootScope.fileused.UserAccFileName;
        //passUserDetails.UserEmail = $rootScope.UserEmail;
        //return passUserDetails;
        return {
            getPDfile: function () {
                return user.PDFileName;
            },
            setPDfile: function (filename) {
                user.PDFileName = filename;
                $rootScope.$broadcast("PDfileUpdate");
            }
        }
    }]);
}());
