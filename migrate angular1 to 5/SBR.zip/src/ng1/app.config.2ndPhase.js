//Configaration UI router
'use strict';

angular.
  module('SBRUI.SBR2ndPhase')
    .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', function ($stateProvider, $urlRouterProvider, $locationProvider) {
        //$urlRouterProvider.otherwise('/datadesign');
        $stateProvider.state('main.datadesign', {
            url: 'datadesign',
            templateUrl: 'public/templates/data-design.html',
            controller: 'dataDesignController',
            controllerAs: 'dataDesignCtrl'
        }).state('main.performancedashboard', {
            url: 'performancedashboard',
            templateUrl: 'public/templates/performance-dashboard.html',
            controller: 'performanceDashboardController',
            controllerAs: 'performDashCtrl'
        }).state('main.optimizationsummary', {
            url: 'optimizationsummary',
            templateUrl: 'public/templates/optimization-summary.html',
            controller: 'optimizationSummaryController',
            controllerAs: 'optimizeSumCtrl'
        })
        .state('main.visualDashboard', {
            url: 'visualDashboard',
            templateUrl: 'public/templates/visual-dashboard.html',
            controller: 'visualDashboardController',
            controllerAs: 'visualDashCtrl'
        }).state('main.test', {
            url: 'test',
            templateUrl: 'public/templates/test.html',
            controller: 'testController',
            controllerAs: 'testCtrl'
        });
    }])
    //Application Config Block 
    .config(['$httpProvider', function ($httpProvider) {
        //$httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
        //$httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
    }])