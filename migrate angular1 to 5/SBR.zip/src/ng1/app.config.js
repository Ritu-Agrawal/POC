'use strict';

angular.
  module('SBRUI')
   .config(['$stateProvider', '$urlRouterProvider', '$locationProvider', function ($stateProvider, $urlRouterProvider, $locationProvider) {
        $urlRouterProvider.otherwise('/');
        $stateProvider.state('login', {
            url: '/login',
            templateUrl: 'public/templates/login.html'
        }).state('unauthorized', {
            url: '/unauthorized',
            templateUrl: 'public/templates/unauthorized.html'
        }).state('main', {
            url: '/',
            templateUrl: 'public/templates/app.html'
        });
    }])

    //Application Config Block 
    .config(['$httpProvider', function ($httpProvider) {
        //$httpProvider.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
        //$httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
    }]);