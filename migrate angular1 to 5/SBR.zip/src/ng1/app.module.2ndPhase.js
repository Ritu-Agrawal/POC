'use strict';

// Define the `SBRUI` module
angular.module('SBRUI.SBR2ndPhase', [
    'ui.bootstrap', 
    'nvd3', 
    'chart.js'
])