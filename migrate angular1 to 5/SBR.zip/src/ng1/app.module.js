'use strict';

// Define the `SBRUI` module
angular.module('SBRUI', [
  'ui.router',
  'ngSanitize', 
  'PerformanceDashboard', 
  'SBRUI.SBR2ndPhase', 
  'ngMaterial',
  'ui.bootstrap', 
  'ui.directives', 
  'ui', 
  'ui.filters', 
  'ngFileUpload', 
  'ngCookies', 
  'dndLists'
]);
