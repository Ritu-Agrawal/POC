import { Component, OnInit, Inject } from '@angular/core';

@Component({
  selector: 'ng2-demo',
  template: `demo`
})
export class Ng2DemoComponent implements OnInit {

}
