﻿(function () {
    "use strict"; 
    angular.module('PerformanceDashboard')
        .controller('dashboardController', ['$scope', '$rootScope', '$window', '$state', 'dashboardService', 'Constants', 'shareUser',
            function ($scope, $rootScope, $window, $state, dashboardService, Constants, shareUser) {
                
                var sessionactionFiles = JSON.parse($window.sessionStorage.getItem("actionFiles"));
                $rootScope.fileSelected = (sessionactionFiles !== null && sessionactionFiles.fileSelected !== undefined) ? sessionactionFiles.fileSelected : false;
                $rootScope.writePermission = false;
                $rootScope.fileused = (sessionactionFiles !== null) ? sessionactionFiles : $rootScope.accountFiles[0];
                $scope.actionFiles = $rootScope.fileused;
                delete $scope.actionFiles.fileSelected;
                $scope.actionFiles = JSON.stringify($scope.actionFiles);
                $scope.errorMsg = false;
                //call a function to create a new Account file if its not there and set session with account file
                $scope.createFile = function () {
                    dashboardService.createFile($scope.actionFiles)                                        
                    .then(function (response) {
                        var resArr = response.split("!");
                        if (resArr[0] === "File Created" || resArr[0] === "File Exists") {
                            $rootScope.fileSelected = true;
                            $rootScope.fileused = JSON.parse($scope.actionFiles);
                            //Ravi added this block - to store user details in Service
                            angular.forEach($rootScope.fileused, function (value, key) {
                                shareUser.store(key, value);
                                if (key == "UserAccFileName") {
                                    shareUser.store('PDFileName', value);
                                }
                            }); 
                            $rootScope.fileused.fileSelected = true;
                            $window.sessionStorage.setItem("actionFiles", JSON.stringify($rootScope.fileused));
                            $state.go('main.InvoiceUsage');
                            $scope.errorMsg = false;
                        } else {
                            $scope.errorMsg = true;
                        }
                    })
                }
                // wipe all data and diable sow and scrubber
                $scope.wipeAllInformation = function () {
                    if (confirm('Are you sure you want to Clear All Data ?')) {
                        dashboardService.wipeAllInformation()
                        .then(function (response) {
                            $rootScope.disableSOW = true;
                            $rootScope.disableNavLinksDOP = true;
                            $rootScope.disableScrubber = true;
                            alert("All Data cleared successfully !");
                        })
                    }
                }
        }]);
}());