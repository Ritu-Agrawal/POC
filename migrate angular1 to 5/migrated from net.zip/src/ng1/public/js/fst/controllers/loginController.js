﻿(function () {
    "use strict"; 
    angular.module('PerformanceDashboard')
        .controller('loginController', ['$scope', '$state', '$rootScope', '$window', 'loginServices', 'Constants',
    function ($scope, $state, $rootScope, $window, loginServices, Constants) {
            $rootScope.ServiceUrl = Constants.API_URL;
            $rootScope.loginUrl = Constants.POST_VALIDATE_USER;
            $scope.error = false;
            $rootScope.authId = Constants.AUTHID;
            $scope.falseuser = false;
            $scope.notAuthorized = false;
            $scope.navigate = function () {
                $scope.error = false;
                $rootScope.accountFiles = [];
                if ($scope.username !== undefined && $scope.username !== "") {
                    var atpos = $scope.username.indexOf("@");
                    var dotpos = $scope.username.lastIndexOf(".");
                    if (atpos < 1 || dotpos < atpos + 2 || dotpos + 2 >= $scope.username.length) {
                        $scope.falseuser = true;
                        $scope.error = true;
                        $scope.errorMsg = "Not a valid e-mail address";
                    } else {
                        $rootScope.userId = $scope.username;//Constants.USERID;
                        $scope.falseuser = false;
                        var param = {
                            "UserEmail": $rootScope.userId,
                            "UserEmpID": $rootScope.authId
                        };
                        loginServices.getValiduser(param)
                        .then(function (response) {
                            //var response = [{ "UserID": "1", "UserName": "Satheesh", "UserEmpID": null, "UserEmail": "satheesh.kumar@hp.com", "UserRoll": null, "UserPermission": "RW", "UserAccFileName": "CLP-Honkong_256", "UserIsAuthorized": "True" }, { "UserID": "1", "UserName": "Satheesh", "UserEmpID": null, "UserEmail": "satheesh.kumar@hp.com", "UserRoll": null, "UserPermission": "RW", "UserAccFileName": "Ernst&Young_257", "UserIsAuthorized": "True" }, { "UserID": "1", "UserName": "Satheesh", "UserEmpID": null, "UserEmail": "satheesh.kumar@hp.com", "UserRoll": null, "UserPermission": "RW", "UserAccFileName": "McDonalds_258", "UserIsAuthorized": "True" }];
                            //var response = [{ "UserID": "3", "UserName": "Guest", "UserEmpID": null, "UserEmail": "guest@hp.com", "UserRoll": null, "UserPermission": "RW", "UserAccFileName": "McDonalds_258", "UserIsAuthorized": "True" }];
                            if (response[0].UserIsAuthorized.toLowerCase() === "true") {
                                $rootScope.userName = response[0].UserName;
                                angular.forEach(response, function (value, key) {
                                    delete value.UserEmail;
                                });
                                $rootScope.accountFiles = response;
                                $window.sessionStorage.setItem("UserIsAuthorized", "True");
                                $scope.notAuthorized = false;
                                $window.sessionStorage.setItem("accountFiles", JSON.stringify($rootScope.accountFiles));
                                $state.go('main.Dashboard');
                                $scope.falseuser = false;
                            } else {
                                $scope.falseuser = true;
                                $scope.error = true;
                                $scope.errorMsg = "Email doesn't exists.";
                                $scope.notAuthorized = true;
                                $window.sessionStorage.clear();
                            }

                        });
                    }
                }
                else {
                    $scope.error = true;
                    $scope.errorMsg = "Please provide user Email";
                }
                               
            }            
        }]);
}());