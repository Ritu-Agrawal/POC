﻿angular.module('PerformanceDashboard').controller('scrubbCompController', ['$scope', 'scrubServices',
    function ($scope,scrubServices) {
        $scope.selectedFilter = 'All';
    $scope.rowNumber = 0;
    $scope.collapseFlag = true;
    $scope.onsiteSLA = true;
    $scope.scrubTab = {
        isSelected: true
    }
    $scope.selectRow = function (item, index) {
        $scope.rowNumber = index;
        if (item !== undefined && item.RepairCode !== undefined && item.RepairCode !== "") {
            angular.forEach($scope.RepairCodeData, function (code) {
                if (code.DataDesign === item.RepairCode) {
                    item.RepairDescription = code.ValidationList;
                }
            })
        }
        $scope.scrubberRowData = item;
    }
    $scope.quickSummary = function (data) {        
        for (var i = 0; i < data.length ; i++) {
            if (i !== 2) {
                data[i].HPOnsite = (data[i].HPOnsite !== null && data[i].HPOnsite !== "" && data[i].HPOnsite !== 0) ? (Math.round(data[i].HPOnsite * 100) / 100) : '';
                data[i].PartnerOnsite = (data[i].PartnerOnsite !== null && data[i].PartnerOnsite !== "" && data[i].PartnerOnsite !== 0) ? (Math.round(data[i].PartnerOnsite * 100) / 100) : '';
                data[i].Remote = (data[i].Remote !== null && data[i].Remote !== "" && data[i].Remote !== 0) ? (Math.round(data[i].Remote * 100) / 100) : '';
                data[i].Scheduled = (data[i].Scheduled !== null && data[i].Scheduled !== "" && data[i].Scheduled !== 0) ? (Math.round(data[i].Scheduled * 100) / 100) : '';
                data[i].Proactive = (data[i].Proactive !== null && data[i].Proactive !== "" && data[i].Proactive !== 0) ? (Math.round(data[i].Proactive * 100) / 100) : '';
                data[i].Totals = (data[i].Totals !== null && data[i].Totals !== "" && data[i].Totals !== 0) ? (Math.round(data[i].Totals * 100) / 100) : '';
            } else {
                data[i].HPOnsite = (data[i].HPOnsite !== null && data[i].HPOnsite !== "" && data[i].HPOnsite !== 0) ? (Math.round(data[i].HPOnsite * 100)) + '%' : '';
                data[i].PartnerOnsite = (data[i].PartnerOnsite !== null && data[i].PartnerOnsite !== "" && data[i].PartnerOnsite !== 0) ? (Math.round(data[i].PartnerOnsite * 100)) + '%' : '';
                data[i].Remote = (data[i].Remote !== null && data[i].Remote !== "" && data[i].Remote !== 0) ? (Math.round(data[i].Remote * 100)) + '%' : '';
                data[i].Scheduled = (data[i].Scheduled !== null && data[i].Scheduled !== "" && data[i].Scheduled !== 0) ? (Math.round(data[i].Scheduled * 100)) + '%' : '';
                data[i].Proactive = (data[i].Proactive !== null && data[i].Proactive !== "" && data[i].Proactive !== 0) ? (Math.round(data[i].Proactive * 100)) + '%' : '';
                data[i].Totals = (data[i].Totals !== null && data[i].Totals !== "" && data[i].Totals !== 0) ? (data[i].Totals * 100).toFixed(2) + '%' : '';
            }
        }
        $scope.SummaryData = data;
    }
    $scope.loadScurbberData = function () {
        scrubServices.postScrubData()
            .then(function successCallback(response) {
                loadData(response);
                $scope.SLAChanged();
        });
    }
        /*start filter case buttons*/
    //---- if filter is all case or unprocessed then call backend API
    $scope.filterCase = function (value) {
        $scope.selectedFilter = value;
        var SelectedParam = {};
        SelectedParam.Description = value;
        if (value === 'Unprocessed' || value === 'All') {
            scrubServices.postfilterCase(SelectedParam)
               .then(function successCallback(response) {
                   loadData(response);
               });
        }
    }
            //select unprocessed item if (ScrubbedSymptomCode is null or ServiceFlag is 'Need SLA') and ServiceFlag should not be Scheduled/Cons Ord/RTM/Proactive
    $scope.filterCaseData = function (value) {
        $scope.selectedFilter = value;
        var filteritems = angular.copy($scope.CompleteScrubberData);
        var itemsTemp = [];
        if (value === 'Unprocessed') {
            if (filteritems.length > 0) {
                angular.forEach(filteritems, function (item) {
                    if ((item.CurrentSymptomCode === null || item.ServiceFlag === 'Need SLA') &&
                        item.ServiceFlag !== 'Scheduled' && item.ServiceFlag !== 'Cons Ord'
                        && item.ServiceFlag !== 'RTM' && item.ServiceFlag !== 'Proactive') {
                        itemsTemp.push(item);
                    }
                });
                $scope.ServiceReportScrubberData = itemsTemp;
            }
        } else if (value === 'Processed') {
            if (filteritems.length > 0) {
                angular.forEach(filteritems, function (item) {
                    if (!((item.CurrentSymptomCode === null || item.ServiceFlag === 'Need SLA') &&
                        item.ServiceFlag !== 'Scheduled' && item.ServiceFlag !== 'Cons Ord'
                        && item.ServiceFlag !== 'RTM' && item.ServiceFlag !== 'Proactive')) {
                        itemsTemp.push(item);
                    }
                });
                $scope.ServiceReportScrubberData = itemsTemp;
            }
        }else if (value === 'Onsite SLAs') {
            if (filteritems.length > 0) {
                angular.forEach(filteritems, function (item) {
                    if (item.CallToResponseMinutes !== null && item.ServiceAction.indexOf("Onsite") > -1) {
                        itemsTemp.push(item);
                    }
                });
                $scope.ServiceReportScrubberData = itemsTemp;
            }
        }
        else if (value === 'Sched / Proactive') {
            if (filteritems.length > 0) {
                angular.forEach(filteritems, function (item) {
                    if (item.ServiceFlag === 'Scheduled' || item.ServiceFlag === 'Proactive') {
                        itemsTemp.push(item);
                    }
                });
                $scope.ServiceReportScrubberData = itemsTemp;
            }
        }
        else if (value === 'Consumables') {
            if (filteritems.length > 0) {
                angular.forEach(filteritems, function (item) {
                    if (item.ServiceFlag === 'Cons Ord' && item.ScrubbedComponentCode === 13) {
                        itemsTemp.push(item);
                    }
                });
                $scope.ServiceReportScrubberData = itemsTemp;
            }
        }
        else if (value === 'RTM') {            
            if (filteritems.length > 0) {
                angular.forEach(filteritems, function (item) {
                    if (item.ServiceFlag === 'RTM') {
                        itemsTemp.push(item);
                    }
                });
                $scope.ServiceReportScrubberData = itemsTemp;
            }
        } else {
            $scope.ServiceReportScrubberData = filteritems
        } 
        $scope.selectRow($scope.ServiceReportScrubberData[0], 0);
    }
        /*end filter case buttons*/
    /*Filter header row */
    $scope.filterScrubbData = function () {
        var filteritems = angular.copy($scope.CompleteScrubberData);
        var itemsTemp = [];
        if (filteritems.length > 0) {
            angular.forEach($scope.filterList, function (fltrValue, fltrKey) {
                itemsTemp = [];
                angular.forEach(filteritems, function (item) {
                    if (item[fltrKey] == fltrValue || fltrValue === '') {
                        itemsTemp.push(item);
                    }
                });
                filteritems = itemsTemp;
            });
            $scope.ServiceReportScrubberData = filteritems;
        }
    }
    $scope.SLAChanged = function () {
        //$scope.onsiteSLA = !$scope.onsiteSLA;
        var SelectedParam = {};
        SelectedParam.ScrubberQuickSummaryData = $scope.ScrubberQuickSummaryData;
        SelectedParam.onsiteSLA = $scope.onsiteSLA;
        scrubServices.postSLAChange(SelectedParam)
            .then(function successCallback(response) {
                $scope.ScrubberQuickSummaryData = response.data;
                $scope.quickSummary(angular.copy($scope.ScrubberQuickSummaryData))
        });
    }
        //call API on service flag change and refresh complte data in UI, in case of delete then confirm with user before delete.
    $scope.setServiceFlag = function (ServiceFlag, data, rowNumber) {
        if (ServiceFlag === "Delete") {
            if (confirm("Are you sure you want to delete this Case ID?")) {
                $scope.oldFlag = $scope.ServiceReportScrubberDataBkp[rowNumber].ServiceFlag;
                $scope.newFlag = ServiceFlag;
                var SelectedParam = {};
                SelectedParam.ServiceFlag = ServiceFlag;
                SelectedParam.CaseID = data.CaseID;
                scrubServices.postServiceFlagChange(SelectedParam)
                .then(function successCallback(response) {
                    loadData(response);
                });
            } else {
                data.ServiceFlag = $scope.ServiceReportScrubberDataBkp[rowNumber].ServiceFlag;
            }
        } else {
            $scope.oldFlag = $scope.ServiceReportScrubberDataBkp[rowNumber].ServiceFlag;
            $scope.newFlag = ServiceFlag;
            var SelectedParam = {};
            SelectedParam.ServiceFlag = ServiceFlag;
            SelectedParam.CaseID = data.CaseID;
            scrubServices.postServiceFlagChange(SelectedParam)
            .then(function successCallback(response) {
                loadData(response);
            });
        }
    }
    // call API on sympotom code change
    $scope.changeSymptomCode = function (code) {
        var SelectedParam = $scope.SymptomCodeData[code - 1];
        SelectedParam.CaseID = $scope.scrubberRowData.CaseID;
        delete SelectedParam.$$hashKey;
        scrubServices.postSymptomCodeChange(SelectedParam)
            .then(function successCallback(response) {
                loadData(response);
            });
    }
        // call API on component code change
    $scope.changeComponentCode = function (code) {
        var SelectedParam = $scope.ComponentCodeData[code - 1];
        SelectedParam.CaseID = $scope.scrubberRowData.CaseID;
        delete SelectedParam.$$hashKey;
        scrubServices.postComponentCodeChange(SelectedParam)
            .then(function successCallback(response) {
                loadData(response);
            });
    }
    var loadData = function (response) {
        $scope.ScrubberReportDateRange = response.data.ScrubberReportDateRange[0].DataRange;
        $scope.ScrubberReportFilterData = response.data.ScrubberReportFilterData[0];
        $scope.ScrubberReportFilterData.Processed = ($scope.ScrubberReportFilterData.Processed !== null && $scope.ScrubberReportFilterData.Processed !== "" && $scope.ScrubberReportFilterData.Processed !== 0) ? (Math.round($scope.ScrubberReportFilterData.Processed * 100)) : '0';
        $scope.SymptomCodeData = response.data.SymptomCodeData;
        $scope.ComponentCodeData = response.data.ComponentCodeData;
        $scope.RepairCodeData = response.data.RepairCodeData;
        $scope.SLASettingsData = response.data.SLASettingsData;
        $scope.ServiceReportScrubberData = response.data.ServiceReportScrubberData;
        $scope.ServiceReportScrubberDataBkp = angular.copy(response.data.ServiceReportScrubberData);
        $scope.CompleteScrubberData = response.data.ServiceReportScrubberData;
        $scope.ScrubberQuickSummaryData = response.data.ScrubberQuickSummaryData;
        $scope.selectRow($scope.ServiceReportScrubberData[0], 0);
        $scope.quickSummary(angular.copy($scope.ScrubberQuickSummaryData));
        $scope.filterCaseData($scope.selectedFilter);
    }
    // alert if any unprocessed data is there and navigate to other page
    $scope.$on("$stateChangeStart", function (event) {
        if (($scope.ScrubberReportFilterData.Unprocessed > 0) && confirm($scope.ScrubberReportFilterData.Unprocessed + ' Case ID(s) on the Service Report Scrubber tab remain unprocessed and require your attention.Leaving them unassigned may effect the SLA Met/Missed and Response Time calculations. To correct this issue, please return to the Service Report Scrubber tab and click the Filter Preset Button labeled \'Unprocessed\'.  In the Service Flag column, provide the appropriate SLA designation or Symptom Code as needed. '))
            event.preventDefault();
    });
}]);
