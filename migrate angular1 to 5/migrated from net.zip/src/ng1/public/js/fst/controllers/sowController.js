﻿(function () {
    "use strict";
    angular.module('PerformanceDashboard')
   .controller('infoSowCtrl', ['$scope', '$http', '$timeout', 'sowServices', 'Constants', '$state', '$rootScope', 'shareUser', function ($scope, $http, $timeout, sowServices, Constants, $state, $rootScope, shareUser) {
       $scope.boolToStr = function (arg) {
           return arg ? 'True' : 'False'
       };
       var self = this;
       self.editableElem = false;
       self.lesslength = false;
       self.generateSBRbtn = false;
       self.downloadSBRbtn = false;
       self.monthData = [];       
       self.SOWTargetColorBackup = "";
       self.enableDataDesign = true;       
       //Getting total data of SOW View on page load   
       sowServices.postSowData(shareUser.get()).then(function (response) {
           console.log(response);
           self.sowdata = response.data[0];
           self.sowdatamodelAll = self.sowdata.Sow_DeviceModels;
           self.createTopSowinfo(self.sowdata);
           /****
            * Showing table data if table data is there, 
            * Showing "No Data Found" error message if table data is not there
           */
           if (!self.sowdatamodelAll.length) {
               self.lesslength = true;
           } else {
               self.SOW_TargetColorDefaultPercent = self.sowdatamodelAll[0].SOW_TargetColorDefaultPercent;
               self.SOWTargetColorBackup = angular.copy(self.SOW_TargetColorDefaultPercent);
               angular.forEach(self.sowdatamodelAll, function (model) {
                   model.id = self.sowdatamodelAll.indexOf(model);
                   model.editable = false;
                   if (model.SOW_TargetMonoVolume == 0 || model.SOW_TargetMonoVolume == "0" || model.SOW_TargetMonoVolume == "")
                       self.enableDataDesign = false;
                   else if (model.SOW_SupportColor && (model.SOW_TargetColorVolume == 0 || model.SOW_TargetColorVolume == "0" || model.SOW_TargetColorVolume == ""))
                       self.enableDataDesign = false;
               });
               console.log(self.sowdatamodelAll);
               $scope.totalItems = self.sowdatamodelAll.length;
           }
       }); 
       //Editing each table row if user need to update/change the specific row of table
       self.sowback = {};
       self.editSowRow = function (sow) {
           self.inputValidationError = false;
           angular.forEach(self.sowdatamodelAll, function (model) {
               model.editable = false;
           });
           sow.editable = true;
           self.sowback = angular.copy(sow);
           //console.log(self.sowdatamodelAll);
       }
       //Updating the data of each table row which are the given by user
       self.rowdata;
       self.textboxError = false;
       self.updateSowRow = function (sow, id) {
           if (angular.equals(angular.toJson(sow), angular.toJson(self.sowback))) {
               console.log("No changes in Edit");
               self.sowback.editable = false;
               self.sowdatamodelAll[id] = angular.copy(self.sowback);
               self.sowback = {};
               
           } else {
               //console.log("Changes are there");
               //Checking Minimum value is less then Maximumm value or not
               if (parseInt(self.sowback.SOW_MinimumVolume) != "" && parseInt(self.sowback.SOW_MaximumVolume) != "") {
                   if (parseInt(self.sowback.SOW_MinimumVolume) > parseInt(self.sowback.SOW_MaximumVolume)) {
                       //console.log("min val shoud be less then");
                       self.inputValidationError = true;
                       self.textboxError = true;
                       //Hiding error message after some time automatically
                       $timeout(function () {
                           self.textboxError = false;
                       }, 3000);
                   } else {
                       self.sowback.editable = false;
                       self.sowdatamodelAll[id] = angular.copy(self.sowback);
                       self.sowback = {};                       
                       $('#calculateModal').modal('show');
                   }
               }
           }
           self.rowdata = self.sowdatamodelAll[id];
       }
       //Taking input from user wether user need Auto calculations required or not 
       self.calculateTarget = function (calculate, val) {
           console.log(calculate);
           /****
             * Getting the value wether User need autocalculation or not
             * Manipulating 2 Static models values with if else condition
           */
           if (val === "YesYes" || val === "YesNo") {
               calculate.SOW_CalculateSingle = "Yes";
               if (val === "YesYes") {
                   calculate.SOW_AutoCalculationRequired = "Yes";
               } else {
                   calculate.SOW_AutoCalculationRequired = "No";
               }
               self.postSowData(calculate);
           } else if (val === "NoYes" || val === "NoNo") { 
               var SOW_AutoCalculationRequired = '';
               if (val === "NoYes") {
                   SOW_AutoCalculationRequired = "Yes";
               } else {
                   SOW_AutoCalculationRequired = "No";
               }
               angular.forEach(calculate, function (model) {
                   model.SOW_TargetColorDefaultPercent = self.SOW_TargetColorDefaultPercent;
                   model.SOW_CalculateSingle = "No";
                   model.SOW_AutoCalculationRequired = SOW_AutoCalculationRequired;
               });
               self.postSowAllData(calculate);
           }
           $('#calculateModal').modal('hide');
           $('#calculateModalAll').modal('hide');
       }
       //Updating selected row data to backend with  input of auto calculation required or not   
       self.postSowData = function (data) {
           var postSowDataParam = {};
           var param = {
               "SOWDevice": data
           }
           angular.merge(postSowDataParam, param, shareUser.get());
           sowServices.postCalculateSow(postSowDataParam)
             .then(function (response) {
                 if (response.data.SOW_RowID) {
                     var id = response.data.SOW_RowID;
                     self.enableDataDesign = true;
                     angular.forEach(self.sowdatamodelAll, function (model) {
                         if (id === model.SOW_RowID) {
                             var modelId = self.sowdatamodelAll.indexOf(model);
                             self.sowdatamodelAll[modelId] = response.data;
                             if (response.data.SOW_TargetMonoVolume == 0 || response.data.SOW_TargetMonoVolume == "0" || response.data.SOW_TargetMonoVolume == "")
                                 self.enableDataDesign = false;
                             else if (response.data.SOW_SupportColor && (response.data.SOW_TargetColorVolume == 0 || response.data.SOW_TargetColorVolume == "0" || response.data.SOW_TargetColorVolume == ""))
                                 self.enableDataDesign = false;
                         } else {
                             if (model.SOW_TargetMonoVolume == 0 || model.SOW_TargetMonoVolume == "0" || model.SOW_TargetMonoVolume == "")
                                 self.enableDataDesign = false;
                             else if (model.SOW_SupportColor && (model.SOW_TargetColorVolume == 0 || model.SOW_TargetColorVolume == "0" || model.SOW_TargetColorVolume == ""))
                                 self.enableDataDesign = false;
                         }
                     });
                 } else {
                     //self.sowdata = response.data;
                     //self.sowdatamodelAll = self.sowdata.Sow_DeviceModels;
                 }                 
             })
       }
       //Updating total table data to backend with input of auto calculation required or not 
       self.postSowAllData = function (data) {
           var postSowAllDataParam = {};
           var param = {
               "SOWDevices": data
           }
           angular.merge(postSowAllDataParam, param, shareUser.get());
           sowServices.postAllCalculateSow(postSowAllDataParam)
             .then(function (response) {
                 self.sowdata = response.data[0];
                 self.sowdatamodelAll = self.sowdata.Sow_DeviceModels;
                 if (!self.sowdatamodelAll.length) {
                     self.lesslength = true;
                 } else {
                     self.enableDataDesign = true;
                     self.SOW_TargetColorDefaultPercent = self.sowdatamodelAll[0].SOW_TargetColorDefaultPercent;
                     self.SOWTargetColorBackup = angular.copy(self.SOW_TargetColorDefaultPercent);
                     angular.forEach(self.sowdatamodelAll, function (model) {
                         model.id = self.sowdatamodelAll.indexOf(model);
                         model.editable = false;
                         if (model.SOW_TargetMonoVolume == 0 || model.SOW_TargetMonoVolume == "0" || model.SOW_TargetMonoVolume == "")
                             self.enableDataDesign = false;
                         else if (model.SOW_SupportColor && (model.SOW_TargetColorVolume == 0 || model.SOW_TargetColorVolume == "0" || model.SOW_TargetColorVolume == ""))
                             self.enableDataDesign = false;
                         
                     });
                     console.log(self.sowdatamodelAll);
                     $scope.totalItems = self.sowdatamodelAll.length;
                 } 
             });
       }
       //"Go to Data & Design" Code starts here       
		self.sowGetDesignDate = function (start, end) {
           $scope.errorMonth = false;
           if (self.monthData.length === 0) {
               sowServices.postGetDataDesignSow().then(function (response) {
                   self.monthData = response.data;
                   self.sowStartMonth = self.monthData[0];
                   self.sowLastMonth = self.monthData[self.monthData.length -1];
                   $('#dataDesignModel').modal('show');
                   //Data & design nav link has to edit here
                   $rootScope.disableNavLinksDOP = false;
                });
           } else {
               $('#dataDesignModel').modal('show');
               self.sowStartMonth = self.monthData[0];
               self.sowLastMonth = self.monthData[self.monthData.length - 1];
           }
		}      
       //"Generate SBR" Code Starts here        
       self.sowGenerateSbr = function (generSbr) {
           $scope.zipFile = "";
           self.downloadSBRbtn = false;
           sowServices.postGenerateSbrSow(generSbr).then(function (response) {
               var splitData = response.data.split(";");
               if (splitData.length === 2) {
                   $scope.zipFile = splitData[0].split(":")[1].trim();
                   self.downloadSBRbtn = true;
                   $scope.msgSBR = splitData[1];
                   alert("SBR Report is generated successfully, Please click on download button.");
               } else {
                   self.downloadSBRbtn = false;
                   alert(response.data);
               }               
           });
       }
       //Downloading SBR document
       self.sowDownloadSbr = function () {
           if (self.downloadSBRbtn) {
               var url = Constants.API_URL + $scope.zipFile;
               window.open(url);
               alert($scope.msgSBR);
           }
       }
       //Delete Design Data
       self.sowDeleteDesignDate = function (start, end) {
           if(self.monthData.indexOf(start) > self.monthData.indexOf(end)){
               $scope.errorMonth = true;
           }else{
                var param = {
                    "StartMonthIndex": self.monthData.indexOf(start),
                    "EndMonthIndex": self.monthData.indexOf(end),
                    "InvoiceCount": (self.monthData.indexOf(end) - self.monthData.indexOf(start) + 1)
                }
                $rootScope.sowStartEndData = param;
                //sowServices.postGotoDataDesignSow(param).then(function (response) {
                //    $rootScope.dataDesignData = response;
                //    self.generateSBRbtn = true;
                //    $('#dataDesignModel').modal('hide');
                //    $state.go('main.datadesign');
                //});
                self.generateSBRbtn = true;
                $('#dataDesignModel').modal('hide').on('hidden.bs.modal', function () {
                    $state.go('main.datadesign');
                });
           }
       }

       //Resetting row data when click on cancel
       self.resetSowRow = function (sow) {
           sow.editable = false;
       }
       //Showing model when user changing "Target color %" in table header
       self.changeAllPercent = function (percent) {
           if (self.SOW_TargetColorDefaultPercent) {
               if (self.SOWTargetColorBackup !== self.SOW_TargetColorDefaultPercent) {
                   self.SOWTargetColorBackup = angular.copy(self.SOW_TargetColorDefaultPercent);
                   $('#calculateModalAll').modal('show');
               }
           }           
       }
       //SOW Pagination code
       $scope.viewby = 5;
       $scope.currentPage = 4;
       $scope.itemsPerPage = $scope.viewby;
       $scope.maxSize = 5; //Number of pager buttons to show
       $scope.setPage = function (pageNo) {
           $scope.currentPage = pageNo;
       };
       $scope.setItemsPerPage = function (num) {
           $scope.itemsPerPage = num;
           $scope.currentPage = 1; //reset to first page
       }
       //Updating Top Row Data in SOW View
       self.topSowInfoData = {};
       self.topSowinfoBackup = {};
       self.billingModel = ['Base Plus Click', 'Utility', 'Utility with Minimum', 'Utility with Variance', 'Level Pay', 'Base + Actuals'];
       self.billingModelType = ['Non-Coterminus', 'Coterminus'];       
       self.createTopSowinfo = function (parentSow) {           
           angular.forEach(parentSow, function (value, kay) {
               if (!angular.isArray(value)) {
                   self.topSowInfoData[kay] = value;
               }
           });
           self.topSowInfoData.billingModel = self.billingModel;
           self.topSowInfoData.billingModelType = self.billingModelType;
           console.log(self.topSowInfoData);
           self.topSowinfoBackup = angular.copy(self.topSowInfoData); 
       }
       self.topSowInfoError = false;
       self.updateSowTopRowInfo = function (sowInfo) {
           //console.log(sowInfo);
           if (angular.equals(angular.toJson(sowInfo), angular.toJson(self.topSowinfoBackup))) {
               //alert("No changes done");
               self.topSowInfoErrorTxt = "No Changes Found";
               self.topSowInfoError = true;
               $timeout(function () {
                   self.topSowInfoError = false;
               }, 3000);
           } else {
               var sowCnfrm = confirm("Click on 'OK' to update your changes");
               if (sowCnfrm == true) {
                   delete sowInfo.Sow_DeviceModels;
                   console.log(sowInfo);
                   //var toprowparam = sowInfo;
                   var postSowTopRowDataParam = {};
                   angular.merge(postSowTopRowDataParam, sowInfo, shareUser.get());
                   sowServices.postSowTopRowData(postSowTopRowDataParam).then(function (response) {
                       console.log(response);
                       self.topSowInfoError = true;
                       if (response.data === "Completed") {
                           self.topSowInfoErrorTxt = "Updated changes Successfully!!!";
                           self.topSowinfoBackup = angular.copy(self.topSowInfoData);
                       } else {
                           self.topSowInfoData = {};
                           self.topSowInfoData = angular.copy(self.topSowinfoBackup);
                           self.topSowInfoErrorTxt = "An internal error occured!, Please contact the Performance Dashboard Support Team";
                       }
                       $timeout(function () {
                            self.topSowInfoError = false;
                       }, 3000);
                   });
               }
           }           
       }
   }])

}());