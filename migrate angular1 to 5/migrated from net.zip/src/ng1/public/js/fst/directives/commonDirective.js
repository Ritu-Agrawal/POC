﻿angular.module('PerformanceDashboard')
.directive('loading', ['$http', function ($http) {
    return {
        restrict: 'A',
        link: function (scope, element, attrs) {
            scope.isLoading = function () {
                return $http.pendingRequests.length > 0;
            };
            scope.$watch(scope.isLoading, function (value) {
                if (value)
                    element.show();
                else
                    element.hide();
            });
        }
    };
}])
.directive('ngFiles', ['$parse', function ($parse) {
    return {
        //scope: {
        //    usageUploadFiles: '@',
        //    disableBtns: '@'
        //},
        //controller: 'usageController',
        //controllerAs: 'usageCtrl',
        //bindToController: true,
        link: function (scope, element, attrs) {
            var onChange = $parse(attrs.ngFiles);
            element.on('change', function (event) {
                onChange(scope, { $files: event.target.files });
                files = event.target.files;
                fileName = event.target.value;
                if (files.length == 1) {
                    pieces = fileName.split(/[\s.]+/);
                    alowFormtedFile = pieces[pieces.length - 1];
                    alowFormt = alowFormtedFile.toLowerCase();
                    if (alowFormt == "xlsx" || alowFormt == "xls") {
                        file_name = files[0].name;
                        if (event.target.name === "uploaderUsageFiles") {
                            scope.usageUploadFiles();
                            $('#usageProcessBtn').prop('disabled', false);
                        }
                        else
                            $('#uploadInvoiceFile').prop('disabled', false);
                    }
                    else {
                        alert("The selected file is not formatted properly for use with the Performance Dashboard. Please select a different file or correct the file format.");
                        if (event.target.name === "uploaderInvoiceFiles")
                            $('#uploadInvoiceFile').prop('disabled', true);
                        else
                            $('#usageProcessBtn').prop('disabled', true);
                    }
                }
                else {
                    if (event.target.name === "uploaderInvoiceFiles")
                        $('#uploadInvoiceFile').prop('disabled', true);
                    else
                        $('#usageProcessBtn').prop('disabled', true);
                }
            });
        }
    }
}])
.directive('droppableColumns', [function () {
    return {
        restrict: 'A',
        scope: {
            validateProcessBtn: '='
        },
        controller: 'invoiceController',
        controllerAs: 'invoiceCtrl',
        bindToController: true,
        link: function (scope, elem, attrs) {
            $(elem).bind('mouseover', function () {
                scope.$apply(function () {
                    $('.droppable').droppable({  //def-col data's id                       
                        classes: {
                            "ui-droppable-hover": "ui-state-hover"
                        },
                        over: function (event, ui) {
                            $("#" + this.id).addClass('ui-droppable-hover', 'ui-state-hover');
                        },
                        out: function (event, ui) {
                            $("#" + this.id).removeClass('ui-state-hover', 'ui-droppable-hover');
                        },
                        drop: function (event, ui) {
                            var $drag = $(ui.draggable)
                            $drop = $(this)
                            id = this.id
                            //if ($('#src-col li').text().match("[0-9]+")) {
                            //    alert("Source columns could not be verified. ")
                            //}
                            if ($drag.text().match("[0-9]+")) {
                                alert("Source columns could not be verified. ")
                            }
                            else if ($drop.text().indexOf(" - ") == -1 && !($('#def-col').text().indexOf("- " + $drag.text()) > 0)) {
                                lastpair = $('#' + id).html($drop.text() + " - " + $drag.text()).addClass('paired');
                                var dragId = $drag[0].id;
                                $("#" + dragId).addClass('paired');
                                var pairedElement = '<li id="i' + id + '"><span id="' + dragId + '">' + $drop.text() + '</span><span class="delete" id="paired-' + pairedIndex + '">×</span></li>';
                                pairedElementText = $(pairedElement).text().split('×')[0];
                                pairedArray.push(pairedElement);
                                $('#paired').html(pairedArray);
                                scope.validateProcessBtn();

                                $('#paired li span').click(function () {
                                    event.preventDefault();
                                    var parentUL = $(this).closest('li')[0].outerHTML;
                                    var getElementId = $(this).closest('li').attr('id');
                                    var idElement = getElementId.substr(1, getElementId.length);
                                    var unPairInnerText = $('#' + idElement).text().trim().split("-")[0].trim();
                                    var unPair = $('#' + idElement).html(unPairInnerText).removeClass('paired');
                                    var unpairSourceId = $(this).closest('li').children()[0].id;
                                    $('#' + unpairSourceId).removeClass('paired');
                                    $(this).closest('li').remove();
                                    var index = pairedArray.indexOf(parentUL);
                                    if (index > -1) {
                                        pairedArray.splice(index, 1);
                                    }
                                    scope.validateProcessBtn();
                                });
                            } pairedIndex++;
                            //}
                        }
                    })
                })
            })
        }
    };
}])
.directive('decimalDigit', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            function inputValue(val) {
                //console.log(attr.maxlength);
                var oldVal = ctrl.$modelValue;
                if (val) {
                    var digits = val.replace(/[^0-9]/g, '');
                    if (digits.length > attr.maxlength) {
                        digits = digits.substring(0, digits.length - 1);
                        //console.log(digits.substring(0, digits.length - 1));
                    } else if (attr.percentage && val > 100) {
                        digits = digits.substring(0, digits.length - 1);
                    }
                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
})
.directive('onlyDigit', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attr, ctrl) {
            //console.log("scope- " + scope + ", elem-" + element + ", attr-" + attr + ", ctrl-" + ctrl);
            function inputValue(val) {
                //console.log(val);
                if (val) {
                    var digits = val.replace(/[^0-9]/g , '');

                    if (digits.length > attr.maxlength) {
                        digits = digits.substring(0, digits.length - 1);
                    }
                    if (digits !== val) {
                        ctrl.$setViewValue(digits);
                        ctrl.$render();
                    }
                    return parseFloat(digits);
                }
                return undefined;
            }
            ctrl.$parsers.push(inputValue);
        }
    };
})
.directive('noSpclChar', function () {
    return {
        require: 'ngModel',
        restrict: 'A',
        link: function (scope, element, attrs, modelCtrl) {
            modelCtrl.$parsers.push(function (inputValue) {
                if (inputValue == null)
                    return ''
                cleanInputValue = inputValue.replace(/[^\w\s]/gi, '');
                if (cleanInputValue != inputValue) {
                    modelCtrl.$setViewValue(cleanInputValue);
                    modelCtrl.$render();
                }
                return cleanInputValue;
            });
        }
    }
})
.directive('confirmOnExit', function () {
    return {
        link: function ($scope, elem, attrs) {
            $scope.$on('$stateChangeStart', function (event) {
                if ($scope.modified && confirm("You have unsaved changes. Click 'OK' to stay on this page or click 'Cancel' to leave the page"))
                    event.preventDefault();
            })
        }
    };
})
.directive('ngDropdownMultiselect', ['$filter', '$document', '$compile', '$parse',

function ($filter, $document, $compile, $parse) {

    return {
        restrict: 'AE',
        scope: {
            selectedModel: '=',
            options: '=',
            extraSettings: '=',
            translationTexts: '=',
            displayProp: '=',
            filterInvoiceData:'&'
        },
        template: function (element, attrs) {
            var checkboxes = true;
            var template = '<div class="multiselect-parent btn-group dropdown-multiselect">';
            template += '<button type="button" class="dropdown-toggle btnDropdown" ng-class="settings.buttonClasses" ng-click="toggleDropdown()">{{getButtonText()}}&nbsp;</button>';
            template += '<div class="dropdown-menu dropdown-menu-form" ng-style="{display: open ? \'block\' : \'none\', height : settings.scrollable ? settings.scrollableHeight : \'auto\' }">';
            template += '<div class="dropdown-header"><input type="text" class="form-control" style="width: 100%;" ng-model="searchFilter" placeholder="{{texts.searchPlaceholder}}" /></p>';
            template += '<div class="row">';
            template += '<div class="col-md-6" ng-hide="!settings.showCheckAll || settings.selectionLimit > 0"><a data-ng-click="selectAll()"><span class="glyphicon glyphicon-ok"></span>  {{texts.checkAll}}</a></div>';
            template += '<div class="col-md-6" ng-show="settings.showUncheckAll"><a data-ng-click="deselectAll();"><span class="glyphicon glyphicon-remove"></span>   {{texts.uncheckAll}}</a></div>';
            template += '</div>';
            template += '<p ng-hide="(!settings.showCheckAll || settings.selectionLimit > 0) && !settings.showUncheckAll" class="divider"></p>';
            template += '<ul class="dropdown-list filter-body">';
            template += '<li role="presentation" ng-repeat="option in options |  unique: settings.displayProp | customfilter: searchFilter:settings.displayProp">';
            template += '<a role="menuitem" tabindex="-1">';
            template += '<div class="checkbox" ng-if="(getPropertyForObject(option,settings.displayProp) !==\'\')"><label><input class="checkboxInput" type="checkbox"  ng-click="checkboxClick($event, getPropertyForObject(option,settings.displayProp))" ng-checked="isChecked(getPropertyForObject(option,settings.displayProp))" /> {{getPropertyForObject(option, settings.displayProp)}}</label></div>';
            template += '<div class="checkbox" ng-if="getPropertyForObject(option,settings.displayProp) ===\'\'"><label><input class="checkboxInput" type="checkbox" ng-click="checkboxClick($event, getPropertyForObject(option,settings.displayProp))" ng-checked="isChecked(getPropertyForObject(option,settings.displayProp))" /> Blank</label></div>';
            template += '</a></li>';
            template += '<li class="divider" ng-show="settings.selectionLimit > 1"></li>';
            template += '<li role="presentation" ng-show="settings.selectionLimit > 1"><a role="menuitem">{{selectedModel.length}} {{texts.selectionOf}} {{settings.selectionLimit}} {{texts.selectionCount}}</a></li>';
            template += '</ul>';
            template += '<div class="filter-btn-group"><button type="button" class="btn btn-blue" style="margin-right: 10px;" ng-click="applyFilter()">OK</button>';
            template += '<button type="button" class="btn btn-gray" ng-click="close()">Cancel</button></div>';
            template += '</div>';            
            template += '</div>';
            element.html(template);
        },
        link: function ($scope, $element, $attrs) {
            var $dropdownTrigger = $element.children()[0];
            //$scope.filterInvoiceData();
            $scope.toggleDropdown = function () {
                $scope.open = !$scope.open;
            };

            $scope.checkboxClick = function ($event, id) {
                $scope.setSelectedItem(id,false,'check');
                $event.stopImmediatePropagation();
            };

            $scope.externalEvents = {
                onItemSelect: angular.noop,
                onItemDeselect: angular.noop,
                onSelectAll: angular.noop,
                onDeselectAll: angular.noop,
                onInitDone: angular.noop,
                onMaxSelectionReached: angular.noop
            };

            $scope.settings = {
                dynamicTitle: true,
                scrollable: false,
                scrollableHeight: '300px',
                closeOnBlur: false,
                displayProp: $scope.displayProp,
                idProp: 'Loc_DeviceID',
                enableSearch: false,
                selectionLimit: 0,
                showCheckAll: true,
                showUncheckAll: true,
                closeOnSelect: false,
                buttonClasses: 'btn btn-default',
                closeOnDeselect: false,
                smartButtonMaxItems: 0,
                smartButtonTextConverter: angular.noop
            };

            $scope.texts = {
                checkAll: 'Check All',	
                uncheckAll: 'Uncheck All',
                buttonDefaultText: 'All',
                dynamicButtonTextSuffix: 'Selected',
                searchPlaceholder: 'Search...',
            };


            angular.extend($scope.settings, $scope.extraSettings || []);
            angular.extend($scope.texts, $scope.translationTexts);

            if ($scope.settings.closeOnBlur) {
                $document.on('click', function (e) {
                    var target = e.target.parentElement;
                    var parentFound = false;

                    while (angular.isDefined(target) && target !== null && !parentFound) {
                        if (_.contains(target.className.split(' '), 'multiselect-parent') && !parentFound) {
                            if (target === $dropdownTrigger) {
                                parentFound = true;
                            }
                        }
                        target = target.parentElement;
                    }

                    if (!parentFound) {
                        $scope.$apply(function () {
                            $scope.open = false;
                        });
                    }
                });
            }
            $scope.close = function () {
                $scope.open = false;
            }
            $scope.applyFilter = function () {
                $scope.filterInvoiceData();
                $scope.open = false;
            }
            $scope.getButtonText = function () {
                if ($scope.settings.dynamicTitle && (($scope.selectedModel !== undefined && $scope.selectedModel.length > 0) || (angular.isObject($scope.selectedModel) && _.keys($scope.selectedModel).length > 0))) {
                    if ($scope.settings.smartButtonMaxItems > 0) {
                        var itemsText = [];

                        angular.forEach($scope.options, function (optionItem) {
                            if ($scope.isChecked($scope.getPropertyForObject(optionItem, $scope.settings.displayProp))) {
                                var displayText = $scope.getPropertyForObject(optionItem, $scope.settings.displayProp);
                                var converterResponse = $scope.settings.smartButtonTextConverter(displayText, optionItem);

                                itemsText.push(converterResponse ? converterResponse : displayText);
                            }
                        });

                        if ($scope.selectedModel.length > $scope.settings.smartButtonMaxItems) {
                            itemsText = itemsText.slice(0, $scope.settings.smartButtonMaxItems);
                            itemsText.push('...');
                        }

                        return itemsText.join(', ');
                    } else {
                        var totalSelected;
                            totalSelected = angular.isDefined($scope.selectedModel) ? $scope.selectedModel.length : 0;
                        if (totalSelected === 0) {
                            return $scope.texts.buttonDefaultText;
                        } else {
                            return totalSelected + ' ' + $scope.texts.dynamicButtonTextSuffix;
                        }
                    }
                } else {
                    return $scope.texts.buttonDefaultText;
                }
            };

            $scope.getPropertyForObject = function (object, property) {
                if (angular.isDefined(object) && object.hasOwnProperty(property)) {
                    return object[property];
                }

                return '';
            };
            $scope.selectAll = function () {
                $scope.deselectAll(false);
                $scope.externalEvents.onSelectAll();
                var exists = [];
                angular.forEach($scope.options, function (value) {
                    if (exists.indexOf(value[$scope.settings.displayProp]) === -1) {
                        if ($scope.searchFilter !== undefined && $scope.searchFilter !== '') {
                            if (value[$scope.settings.displayProp].toLowerCase().indexOf($scope.searchFilter.toLowerCase()) !== -1) {
                                exists.push(value[$scope.settings.displayProp]);
                                $scope.setSelectedItem(value[$scope.settings.displayProp], true);
                            }
                        } else {
                            exists.push(value[$scope.settings.displayProp]);
                            $scope.setSelectedItem(value[$scope.settings.displayProp], true);
                        }
                        
                    }
                });
            };

            $scope.deselectAll = function (sendEvent) {
                $scope.selectedModel.splice(0, $scope.selectedModel.length);
            };
            $scope.setSelectedItem = function (id, dontRemove,where) {
                dontRemove = dontRemove || false;
                var exists = $scope.selectedModel.indexOf(id) !==-1 

                if (!dontRemove && exists) {
                    $scope.selectedModel.splice($scope.selectedModel.indexOf(id), 1);
                } else if (!exists) {
                    $scope.selectedModel.push(id);
                }
            };

            $scope.isChecked = function (id) {
                return ($scope.selectedModel.indexOf(id) !==-1);
            };
            $scope.dateFilter = function (date) {
               return $filter('date')(new Date(date), "MM-dd-yyyy")
            }
            $scope.externalEvents.onInitDone();
        }
    };
}])
