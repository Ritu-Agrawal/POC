﻿$(function () {   
    $("#def-col div").droppable({
        classes: {
            "ui-droppable-hover": "ui-state-hover"
        }
    });
    
});

pairedArray = [];
pairedIndex = 0;
//drag col items enable/disable
        function getdragId(id) {
            var arrayPaired = $('#paired li');
            var mappedFlag = false;
            for (var i = 0; i < arrayPaired.length; i++) {                
                var scLi = $('#src-col li');
                var scText = arrayPaired[i].innerText.split('-')[1].split('×')[0].trim();
                for (var j = 0; j < scLi.length; j++) {
                    var scLiNode = $('#src-col li')[j];
                    if (scLiNode.textContent.trim().match(scText)) {
                        var scID = $('#src-col li')[j].id;
                        if (scID == id) {
                            mappedFlag = true;
                            break;
                        }
                    }
                }
            }
            if (!mappedFlag) {
                $('#' + id).draggable({
                    revert: true,
                    disabled: false
                })
            } else {
                $('#' + id).draggable({ disabled: true });
            }
        }

(function () {
    "use strict"; 
    angular.module('PerformanceDashboard')
        .controller('mainController', ['$scope', '$rootScope', '$http', '$state', 'Constants', '$window', 'BaseHTTPService',
    function ($scope, $rootScope, $http, $state, Constants, $window, BaseHTTPService) {

        $scope.clearallData = function () {
            var param = {};
            BaseHTTPService.httpPost(Constants.POST_CLEAR_ALL_DATA, param, true)
                .then(function successCallback(response) {
                    console.log(response);
                    $state.go('main.scrubber.compInfo', {}, {reload: true});
                });
            }
            $scope.navigate = function (url) {
                $state.go(url);
            }
            $scope.scrub = {
                loadReport: false,
                scrubSetting: true,
                compInfo: false,
                clearAll: false,
            }
            $rootScope.accountFiles = (JSON.parse($window.sessionStorage.getItem("accountFiles")) !== null) ? JSON.parse($window.sessionStorage.getItem("accountFiles")) : {};
            
            if ($rootScope.accountFiles.UserName !== undefined)
                $rootScope.userName = fileused.UserName;
            
            $scope.logout = function () {
                $window.sessionStorage.clear();
                $state.go('Login');
            }
            $rootScope.disableSOW = true;
            $rootScope.disableNavLinksDOP = true;
            $rootScope.disableScrubber = true;
           
        }]);
}());