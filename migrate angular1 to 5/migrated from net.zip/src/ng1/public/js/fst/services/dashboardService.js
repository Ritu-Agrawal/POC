﻿angular.module('PerformanceDashboard')
      .factory('dashboardService', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
          var loginServices = {
              createFile: function (param) {
                  return BaseHTTPService.httpPost(Constants.POST_SELECT_FILE, param)
                  .then(this.handleSuccess, this.handleError('Error while getting user details'));
              },
              wipeAllInformation: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_WIPE_ALL_INFORMATION, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting user details'));
              },
              handleSuccess: function (response) {
                  return response.data;
                  console.log(response);
                  //shareUser.store('PDFileName', response.config.data.UserAccFileName);
              },
              handleError: function (error) {
                  return function () {
                      console.log(error);
                      return { success: false, message: error };
                  };
              }
          };
          return loginServices;
      }])