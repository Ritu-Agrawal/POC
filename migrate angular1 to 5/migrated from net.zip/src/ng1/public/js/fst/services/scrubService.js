﻿angular.module('PerformanceDashboard')
      .factory('scrubServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
          var scrubServices = {
              postScrubReport: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.GET_SCRUB_REPORT, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting Scrub details'));
              },
              postPPUShare: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_PPU_SHARE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error while download Frm Network'));
              },
              PostProcessPPUFile: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_PPU_FILE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error while download Frm Network'));
              },
              postScrubData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.GET_SCRUBB_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting Scrub details'));
              },
              postSLAChange: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_SLA_CHANGE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error while download Frm Network'));
              },
              postServiceFlagChange: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_SERVICE_FLAG_CHANGE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Error while download Frm Network'));
              },
              postSLAData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_SLA_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting SLA details'));
              },
              postCCData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_CC_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting CC details'));
              },
              postSAData: function () {
                  var param = {};
                  return BaseHTTPService.httpPost(Constants.POST_SA_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting SA details'));
              },
              postUpdateSAData: function (jsonData) {
                  var param = {
                      "ServiceAnalysisData": jsonData
                  };
                  return BaseHTTPService.httpPost(Constants.POST_SA_UPDATE_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('save Service Analysis data error'));
              },
              postUpdateSLAData: function (jsonData) {
                  var param = {
                      "ServiceLevelAgreement": jsonData
                  };
                  return BaseHTTPService.httpPost(Constants.POST_UPDATE_SLA_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('save service level agreement data error'));
              },
              postUpdateCCData: function (jsonData) {
                  var param = {
                      "ContractCoverageData": jsonData
                  };
                  return BaseHTTPService.httpPost(Constants.POST_UPDATE_CC_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('save Contract Coverage data error'));
              },
              postSymptomCodeChange: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_SYMPTOMCODE_CHANGE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Symptom code change data error'));
              },
              postComponentCodeChange: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_COMPONENTCODE_CHANGE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Component code change data error'));
              },
              postfilterCase: function (jsonData) {
                  return BaseHTTPService.httpPost(Constants.POST_FILTER_CASE, jsonData, true)
                  .then(this.handleSuccess, this.handleError('Case Filter data error'));
              },

              handleSuccess: function (response) {
                  return response;
              },
              handleError: function (error) {                  
                  return function () {
                      console.log(error);
                      return { success: false, message: error };
                  };
              }
          };
          return scrubServices;
      }])