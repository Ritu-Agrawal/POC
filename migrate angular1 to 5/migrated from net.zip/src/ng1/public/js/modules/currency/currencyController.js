angular.module('SBRSecondPhase.dataDesign', ['ui.bootstrap'])
    .controller('currencyConversionController', ['$scope', '$http', '$uibModal',
        function ($scope, $http, $modal) {
            var self = this;
            //Currency Conversion Model Starts 
            self.currencyConversionData = [
                {
                    "CurrencyCode": "CAD",
                    "CurrencyUnit": "Canadian Dollar",
                    "UnitsPerCAD": 1,
                    "CADsperUnit": 1
                },
                {
                    "CurrencyCode": "USD",
                    "CurrencyUnit": "US Dollar",
                    "UnitsPerCAD": 0.764564,
                    "CADsperUnit": 1.3145646
                },
                {
                    "CurrencyCode": "EUR",
                    "CurrencyUnit": "EURO",
                    "UnitsPerCAD": 0.7145564,
                    "CADsperUnit": 1.464654
                },
                {
                    "CurrencyCode": "CAD",
                    "CurrencyUnit": "Canadian Dollar",
                    "UnitsPerCAD": 1,
                    "CADsperUnit": 1
                },
                {
                    "CurrencyCode": "GBP",
                    "CurrencyUnit": "British Pound",
                    "UnitsPerCAD": 0.6145664,
                    "CADsperUnit": 1.625646
                }
            ]

                               
    }]);
