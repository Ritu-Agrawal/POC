angular.module('SBRUI.test', ['ui.bootstrap'])
    .controller('testController', ['$scope', '$http', '$uibModal',
        function ($scope, $http, $modal) {
            var self = this;
                                            
    }]);
