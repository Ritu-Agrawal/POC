angular.module('SBRUI.SBR2ndPhase')
    .factory('visualDashboardServices', ['Constants', 'BaseHTTPService', function (Constants, BaseHTTPService) {
        var visualDashboardServices = {
            vdGetAllGraphsData: function (param) {
                return BaseHTTPService.httpPost(Constants.POST_GET_ALL_GRAPH_DATA, param, true)
                  .then(this.handleSuccess, this.handleError('Error while getting PD details'));
            }, 
            handleSuccess: function (response) {
                return response;
            },
            handleError: function (error) {
                return function () {
                    console.log(error);
                    return {
                        success: false,
                        message: error
                    };
                };
            }
        };
        return visualDashboardServices;
    }])

    .controller('visualDashboardController', ['$scope', '$http', '$filter', '$uibModal', 'Constants', 'shareUser', 'visualDashboardServices',
        function ($scope, $http, $filter, $modal, Constants, shareUser, visualDashboardServices) {
        var self = this; 
        //Getting all graphs Data
        self.vdparam = shareUser.get();
        self.vdExcutes = [];
        //self.totalDeviceCount = 0;
        /**
         * Calling API to get all the data on page load itself
         */

        visualDashboardServices.vdGetAllGraphsData(self.vdparam).then(function (response) {
            console.log(response);
            self.grpahdata = response.data;
            self.vdFleetu = self.grpahdata.fleetUtilization;
            self.vdUsages = self.grpahdata.usageSummary;
            self.vdServicep = self.grpahdata.servicePerformance;
            self.vdCurrentfm = self.grpahdata.currentFleetMix;
            //self.totalDeviceCount = self.vdCurrentfm.chartValue;
            self.vdDuplex = self.grpahdata.duplexEnviournment;
            self.vdExcuteObj = self.grpahdata.executiveSummary;
            self.vdNrdNids = self.grpahdata.NRDNIDs;
            self.vdtransite = self.grpahdata.transition;
            self.vdPotantail = self.grpahdata.potentialSavings;
            self.vdExcutes.push(self.vdExcuteObj);
            console.log(self.vdExcutes);
            //Fleet Utilization graph part
            var fleetGauge = gauge('#fleet-Utilization', {
                maxValue: 100,
            });
            fleetGauge.render();
            fleetGauge.update(self.vdFleetu.Utilization);
            //Duplex
            var fleetGauge2 = gauge('#fleet-Utilization2', {
                maxValue: 100,
            });
            fleetGauge2.render();
            fleetGauge2.update(self.vdDuplex.Utilization);
        });

        //$http({
        //    method: 'POST',
        //    url: Constants.POST_GET_ALL_GRAPH_DATA,
        //    data: self.vdparam
        //}).then(function successCallback(response) {
        //    console.log(response);
        //    self.grpahdata = response.data;
        //    self.vdFleetu = self.grpahdata.fleetUtilization;
        //    self.vdUsages = self.grpahdata.usageSummary;
        //    self.vdServicep = self.grpahdata.servicePerformance;
        //    self.vdCurrentfm = self.grpahdata.currentFleetMix;
        //    //self.totalDeviceCount = self.vdCurrentfm.chartValue;
        //    self.vdDuplex = self.grpahdata.duplexEnviournment;
        //    self.vdExcuteObj = self.grpahdata.executiveSummary;
        //    self.vdNrdNids = self.grpahdata.NRDNIDs;
        //    self.vdtransite = self.grpahdata.transition;
        //    self.vdPotantail = self.grpahdata.potentialSavings;            
        //    self.vdExcutes.push(self.vdExcuteObj);
        //    console.log(self.vdExcutes);
        //    //Fleet Utilization graph part
        //    var fleetGauge = gauge('#fleet-Utilization', {
        //        maxValue: 100,
        //    });
        //    fleetGauge.render();
        //    fleetGauge.update(self.vdFleetu.Utilization);
        //    //Duplex
        //    var fleetGauge2 = gauge('#fleet-Utilization2', {
        //        maxValue: 100,
        //    });
        //    fleetGauge2.render();
        //    fleetGauge2.update(self.vdDuplex.Utilization);
            
        //}, function errorCallback(response) {
        //    console.log(response);
        //});
        /**
         * Setting Usage Summary Graph Options
         */         
        $scope.optionsPie = {
            chart: {
                type: 'pieChart',
                //width:200,
                height: 180,
                x: function (d) { return d.y + "%"; },
                showLegend: false,
                showLabels: true,
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: false,
                labelsOutside: true,
                color: ['#D2D4D3', '#A47C00', "#F7BD2D"],                
                margin: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series 1 Point' + d.index + '\n<br> Value: ' + $filter('number')(d.data.y * self.vdUsages.chartValue / 100, 0) + "(" + $filter('number')(d.data.y, 0) + "%)";
                    }
                }
            }
        };
        /**
         * Setting Current Fleet Mix Graph Options
         */ 
        $scope.optionsDonut = {
            chart: {
                type: 'pieChart',
                height: 200,
                x: function (d) { return d.y + "%"; },
                showLegend: false,
                showLabels: true,
                duration: 500,
                //labelThreshold: 0.01,
                //labelSunbeamLayout: false,
                labelsOutside: true,
                donutRatio: 0.6,
                donut: true,
                title: false,
                //title: '19 \n Total Device Count',
                color: ['#D2D4D3', '#A47C00', "#F7BD2D", "#B9B8BB"],
                //callback: function () {
                //    //d3.selectAll('.nv-pie-title').style('font-size', '12'); 
                //    //d3.selectAll('.nv-pie-title').attr("class", "piechart-title-large");
                //    d3.selectAll('.nv-pie-title').text(self.totalDeviceCount +' Total Device Count');
                //},
                margin: {
                    top: 6,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series 1 Point' + d.index + '\n<br> Value: ' + $filter('number')(d.data.y * self.vdCurrentfm.chartValue / 100, 0) + "(" + $filter('number')(d.data.y, 0) + "%)";
                    }
                },
            }
        };
        /**
         * Setting Duplex Graph Options
         */ 
        $scope.optionsDuplex = {
            chart: {
                type: 'pieChart',
                height: 200,
                x: function (d) { return d.y + "%"; },
                showLegend: false,
                showLabels: false,
                duration: 500,
                labelThreshold: 0.01,
                labelSunbeamLayout: false,
                labelsOutside: true,
                donutRatio: 0.6,
                donut: true,
                title: false,
                color: ['#D2D4D3', '#E74A2E'],
                margin: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 0
                },
            }
        };
        /**
         * Setting Executive Summary Graph Options
         */ 
        $scope.ExecutiveOptions = {
            chart: {
                type: 'discreteBarChart',
                height: 150,
                //width: 200,
                x: function (d) { return d.label; },
                y: function (d) { return d.value; },
                showValues: false,
                valueFormat: function (d) {
                    return (d3.format(',.1f')(d));
                },
                color: ['#098805', '#F7BA2B', '#E94B2D'],
                duration: 500,
                yDomain: [0, 1],
                xAxis: {
                    fontSize: 14
                },
                yAxis: {
                    tickFormat: function (d) {
                        return d3.format(',.2f')(d);
                    },
                    ticks: 2
                },
                showXAxis: true,
                showYAxis: true,
                tooltip: {
                    contentGenerator: function (d) {
                        return 'Series 1 Point "' + d.data.label + '"\n<br> Value: ' +(d.data.value);
                    }
                }
            },
            title: {
                enable: true,
                text: "Blended Cost Per Page",
                className: "bar-chart-titlte",
                css: {
                    "textAlign": "center"
                }
            }
        }; 
    }]);